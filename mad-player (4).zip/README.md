# Mad Player — Reproductor de Música

Proyecto completo de **Mad Player**, reproductor de música offline con motor de audio en tiempo real basado en **Tone.js (`Tone.Player` + `Tone.PitchShift`)**, ecualizador de 5 bandas, refuerzo de graves, virtualizador, temas dinámicos con color adaptativo por portada, editor de etiquetas ID3, recortador de tonos y gestión de biblioteca.

## Requisitos previos
- **Node.js** (v18 o superior recomendado)
- **npm** o **bun**

## Instalación y ejecución local

1. Descomprime el archivo `.zip` en una carpeta de tu computadora.
2. Abre una terminal dentro de la carpeta del proyecto e instala las dependencias:
   ```bash
   npm install
   ```
3. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```
4. Abre en tu navegador la dirección `http://localhost:3000`.

## Compilar para producción
Para generar la carpeta `dist/` lista para subir a cualquier hosting estático o empaquetar en Capacitor (APK):
```bash
npm run build
```

## Generar APK para Android con Capacitor

### Requisitos adicionales para Android
- **Android Studio** instalado (incluye Android SDK y herramientas de compilación Gradle).
- **JDK 17** (o el JDK incluido dentro de Android Studio).

### Pasos para generar el APK

1. **Instalar las dependencias del proyecto** (si aún no lo has hecho):
   ```bash
   npm install
   ```

2. **Agregar la plataforma Android** (solo la primera vez, si no existe la carpeta `android/`):
   ```bash
   npx cap add android
   ```

3. **Compilar la aplicación web y sincronizar con Capacitor**:
   ```bash
   npm run cap:sync
   ```
   *(Este script ejecuta `npm run build` para generar `dist/` y luego `npx cap sync android` para copiar los recursos web y actualizar plugins en el proyecto nativo).*

4. **Abrir el proyecto en Android Studio**:
   ```bash
   npm run cap:android
   ```
   *(Equivalente a `npx cap open android`).*

5. **Construir el archivo APK desde Android Studio**:
   - Espera a que termine la sincronización de **Gradle**.
   - En el menú superior, ve a **Build → Build Bundle(s) / APK(s) → Build APK(s)** para generar un APK de prueba (`app-debug.apk`), o selecciona **Build → Generate Signed Bundle / APK...** para crear un APK firmado de producción.
   - Una vez finalizado, haz clic en **locate** en la notificación o busca el archivo en:
     `android/app/build/outputs/apk/debug/app-debug.apk`

### Alternativa por línea de comandos (sin abrir la interfaz de Android Studio)
Una vez ejecutado `npm run cap:sync`, puedes compilar el APK de depuración directamente desde la terminal:
```bash
cd android
./gradlew assembleDebug
```
El APK generado estará disponible en `android/app/build/outputs/apk/debug/app-debug.apk`.
