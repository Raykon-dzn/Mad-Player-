import * as Tone from 'tone';
import { EqualizerState, Track } from '../types/music';

type TimeUpdateCallback = (currentTime: number, duration: number) => void;
type TrackEndedCallback = () => void;

class WebAudioStudioEngine {
  private toneCtx: Tone.BaseContext | null = null;
  private tonePlayer: Tone.Player | null = null;
  private pitchShift: Tone.PitchShift | null = null;

  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private bassBoostFilter: BiquadFilterNode | null = null;
  private stereoPanner: StereoPannerNode | null = null;
  private eqFilters: BiquadFilterNode[] = [];

  // Playback, Speed & Pitch State
  private isPlaying = false;
  private isBufferLoaded = false;
  private loadRequestId = 0;
  private currentTrack: Track | null = null;
  private currentTime = 0;
  private loadedTrackDuration = 0;
  private playbackRate = 1.0; // Connected directly to Tone.Player.playbackRate
  private pitchRate = 1.0; // Connected directly to Tone.PitchShift.pitch
  private volume = 0.85;
  private isMuted = false;
  private replayGainLinear = 1.0;
  private sleepFadeMultiplier = 1.0;

  // Transition & Fade Settings (Muzio style)
  private playPauseFadeEnabled = true;
  private playPauseFadeMs = 505;
  private crossfadeEnabled = false;
  private gaplessEnabled = true;
  private pauseTimeoutId: number | null = null;

  // A-B Loop markers
  private loopStart: number | null = null;
  private loopEnd: number | null = null;

  private progressRafId: number | null = null;
  private lastFrameTimestamp = 0;

  private onTimeUpdate: TimeUpdateCallback | null = null;
  private onTrackEnded: TrackEndedCallback | null = null;

  private ensureToneEngine() {
    if (Tone.getContext().state !== 'running') {
      Tone.start().catch(() => {
        // Ignore if awaiting user gesture
      });
    }

    if (!this.toneCtx) {
      const ctx = Tone.getContext();
      this.toneCtx = ctx;

      // 1. Configure Tone.PitchShift (windowSize: 0.1 for smooth, non-robotic real-time pitch shifting)
      this.pitchShift = new Tone.PitchShift({
        pitch: this.getCompensatedPitchSemitones(),
        windowSize: 0.1,
        delayTime: 0,
        feedback: 0
      });

      // 2. Configure Tone.Player connected to Tone.PitchShift
      this.tonePlayer = new Tone.Player({
        loop: false,
        autostart: false
      }).connect(this.pitchShift);

      this.syncToneSpeedAndPitch();

      // 3. Configure EQ, Bass Boost, Stereo Panner, Master Volume & Visualizer Analyser on Tone's AudioContext
      try {
        this.masterGain = ctx.createGain();
        this.masterGain.gain.value = this.getTargetMasterGain();

        this.bassBoostFilter = ctx.createBiquadFilter();
        this.bassBoostFilter.type = 'lowshelf';
        this.bassBoostFilter.frequency.value = 100;
        this.bassBoostFilter.gain.value = 2;

        this.stereoPanner = ctx.createStereoPanner();
        this.stereoPanner.pan.value = 0;

        const frequencies = [60, 230, 910, 3600, 14000];
        this.eqFilters = frequencies.map((freq, idx) => {
          const filter = ctx.createBiquadFilter();
          filter.type =
            idx === 0 ? 'lowshelf' : idx === frequencies.length - 1 ? 'highshelf' : 'peaking';
          filter.frequency.value = freq;
          filter.Q.value = 1.1;
          filter.gain.value = 0;
          return filter;
        });

        this.analyser = ctx.createAnalyser();
        this.analyser.fftSize = 256;
        this.analyser.smoothingTimeConstant = 0.82;

        // Connect Tone.PitchShift -> BassBoost -> 5-Band EQ -> StereoPanner -> MasterGain -> Analyser -> Destination
        this.pitchShift.connect(this.bassBoostFilter);

        let prevNode: AudioNode = this.bassBoostFilter;
        for (const eqNode of this.eqFilters) {
          prevNode.connect(eqNode);
          prevNode = eqNode;
        }
        prevNode.connect(this.stereoPanner);
        this.stereoPanner.connect(this.masterGain);
        this.masterGain.connect(this.analyser);
        Tone.connect(this.analyser, ctx.destination);
      } catch {
        // Fallback direct connection if custom filter nodes fail on any browser wrapper
        this.pitchShift.toDestination();
      }
    }
  }

  /**
   * Convierte un multiplicador/ratio (ej. 0.9x, 1.5x) a semitonos usando:
   * 12 * Math.log2(ratio)
   */
  public getPitchSemitones(ratio: number = this.pitchRate): number {
    const parsed = parseFloat(String(ratio));
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return 0;
    }
    return 12 * Math.log2(parsed);
  }

  /**
   * Calcula los semitonos netos para Tone.PitchShift compensando el cambio de tono
   * que introduce Tone.Player.playbackRate al variar la velocidad:
   * pitchSemitones = 12 * Math.log2(tono) - 12 * Math.log2(velocidad)
   */
  private getCompensatedPitchSemitones(): number {
    const tono = parseFloat(String(this.pitchRate));
    const velocidad = Math.max(0.5, Math.min(2.0, parseFloat(String(this.playbackRate)) || 1.0));
    if (!Number.isFinite(tono) || tono <= 0) {
      return 0;
    }
    const pitchSemitones = 12 * Math.log2(tono) - 12 * Math.log2(velocidad);
    return pitchSemitones;
  }

  /**
   * Synchronizes Tone.Player.playbackRate and Tone.PitchShift.pitch in real time
   * so speed does NOT alter pitch unless pitchRate != 1.0
   */
  private syncToneSpeedAndPitch() {
    const velocidad = Math.max(0.5, Math.min(2.0, this.playbackRate));
    if (this.tonePlayer) {
      this.tonePlayer.playbackRate = velocidad;
    }
    if (this.pitchShift) {
      const pitchSemitones = this.getCompensatedPitchSemitones();
      this.pitchShift.pitch = pitchSemitones;
      if (this.pitchShift.wet && typeof this.pitchShift.wet.value === 'number') {
        this.pitchShift.wet.value = Math.abs(pitchSemitones) < 0.001 ? 0 : 1;
      }
    }
  }

  public setCallbacks(onTimeUpdate: TimeUpdateCallback, onTrackEnded: TrackEndedCallback) {
    this.onTimeUpdate = onTimeUpdate;
    this.onTrackEnded = onTrackEnded;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  private stopTonePlayerSafe() {
    if (this.tonePlayer && this.tonePlayer.state === 'started') {
      try {
        this.tonePlayer.stop();
      } catch {
        // Ignore stop errors if buffer not yet ready
      }
    }
  }

  private startTonePlayerAtCurrentTime() {
    if (!this.tonePlayer || !this.isBufferLoaded || !this.currentTrack) return;
    this.stopTonePlayerSafe();
    this.syncToneSpeedAndPitch();

    const bufDur = this.tonePlayer.buffer.duration;
    if (bufDur <= 0) return;

    const offset = Math.max(0, Math.min(this.currentTime, Math.max(0, bufDur - 0.05)));

    try {
      this.tonePlayer.start(undefined, offset);
    } catch {
      // Ignore start race
    }
  }

  private startProgressLoop() {
    this.stopProgressLoop();
    this.lastFrameTimestamp = performance.now();

    const updateProgress = (now: number) => {
      if (!this.isPlaying || !this.currentTrack) return;
      const dt = ((now - this.lastFrameTimestamp) / 1000) * this.playbackRate;
      this.lastFrameTimestamp = now;
      this.currentTime += dt;

      const effectiveDuration = this.loadedTrackDuration || this.currentTrack.duration;

      if (this.loopEnd !== null && this.currentTime >= this.loopEnd) {
        const restartAt = this.loopStart ?? 0;
        this.currentTime = restartAt;
        this.startTonePlayerAtCurrentTime();
      }

      if (this.currentTime >= effectiveDuration) {
        this.currentTime = 0;
        this.isPlaying = false;
        this.stopTonePlayerSafe();
        this.stopProgressLoop();
        this.onTrackEnded?.();
        return;
      }

      this.onTimeUpdate?.(this.currentTime, effectiveDuration);
      this.progressRafId = window.requestAnimationFrame(updateProgress);
    };

    this.progressRafId = window.requestAnimationFrame(updateProgress);
  }

  private stopProgressLoop() {
    if (this.progressRafId !== null) {
      window.cancelAnimationFrame(this.progressRafId);
      this.progressRafId = null;
    }
  }

  public loadTrack(track: Track, autoPlay = true) {
    const isSameTrack = this.currentTrack?.id === track.id;
    const reqId = ++this.loadRequestId;

    this.stopProgressLoop();
    this.stopTonePlayerSafe();
    this.currentTrack = track;
    this.loadedTrackDuration = track.duration;

    if (!isSameTrack) {
      this.currentTime = 0;
      this.loopStart = null;
      this.loopEnd = null;
    }

    this.ensureToneEngine();

    if (!this.tonePlayer || !track.audioUrl) {
      this.isBufferLoaded = false;
      this.isPlaying = false;
      this.onTimeUpdate?.(this.currentTime, track.duration);
      return;
    }

    this.isBufferLoaded = false;
    this.isPlaying = autoPlay;

    this.tonePlayer
      .load(track.audioUrl)
      .then(() => {
        if (reqId !== this.loadRequestId || !this.tonePlayer) return;
        this.isBufferLoaded = true;
        this.tonePlayer.loop = false;
        if (this.tonePlayer.buffer.duration > 0) {
          this.loadedTrackDuration = this.tonePlayer.buffer.duration;
        }
        this.syncToneSpeedAndPitch();

        if (this.isPlaying) {
          this.applyFadeInGain();
          this.startTonePlayerAtCurrentTime();
          this.startProgressLoop();
        } else {
          this.onTimeUpdate?.(this.currentTime, this.loadedTrackDuration);
        }
      })
      .catch(() => {
        if (reqId !== this.loadRequestId) return;
        this.isBufferLoaded = false;
        this.isPlaying = false;
      });
  }

  public setTransitionConfig(config: {
    playPauseFadeEnabled: boolean;
    playPauseFadeMs: number;
    crossfadeEnabled: boolean;
    gaplessEnabled: boolean;
  }) {
    this.playPauseFadeEnabled = config.playPauseFadeEnabled;
    this.playPauseFadeMs = config.playPauseFadeMs;
    this.crossfadeEnabled = config.crossfadeEnabled;
    this.gaplessEnabled = config.gaplessEnabled;
  }

  private getTargetMasterGain(): number {
    if (this.isMuted) return 0;
    const baseGain = Math.min(1.5, this.volume * this.replayGainLinear);
    return Math.max(0, baseGain * this.sleepFadeMultiplier);
  }

  private applyFadeInGain() {
    if (this.masterGain && this.toneCtx) {
      const targetGain = this.getTargetMasterGain();
      const now = this.toneCtx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      if (this.playPauseFadeEnabled && targetGain > 0 && this.sleepFadeMultiplier >= 0.99) {
        this.masterGain.gain.setValueAtTime(0.001, now);
        this.masterGain.gain.linearRampToValueAtTime(
          targetGain,
          now + this.playPauseFadeMs / 1000
        );
      } else {
        this.masterGain.gain.setValueAtTime(targetGain, now);
      }
    }
  }

  public play() {
    if (!this.currentTrack) return;
    this.ensureToneEngine();

    if (this.pauseTimeoutId !== null) {
      window.clearTimeout(this.pauseTimeoutId);
      this.pauseTimeoutId = null;
    }

    this.isPlaying = true;
    this.applyFadeInGain();

    if (this.isBufferLoaded) {
      this.startTonePlayerAtCurrentTime();
      this.startProgressLoop();
    }
  }

  public pause() {
    if (this.pauseTimeoutId !== null) {
      window.clearTimeout(this.pauseTimeoutId);
      this.pauseTimeoutId = null;
    }

    if (this.playPauseFadeEnabled && this.masterGain && this.toneCtx && this.isPlaying) {
      const now = this.toneCtx.currentTime;
      const fadeSec = this.playPauseFadeMs / 1000;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
      this.masterGain.gain.linearRampToValueAtTime(0.0001, now + fadeSec);

      this.pauseTimeoutId = window.setTimeout(() => {
        this.isPlaying = false;
        this.stopTonePlayerSafe();
        this.stopProgressLoop();
        this.pauseTimeoutId = null;
      }, this.playPauseFadeMs);
      return;
    }

    this.isPlaying = false;
    this.stopTonePlayerSafe();
    this.stopProgressLoop();
  }

  public seek(seconds: number) {
    if (!this.currentTrack) return;
    const effectiveDur = this.loadedTrackDuration || this.currentTrack.duration;
    const clamped = Math.max(0, Math.min(seconds, effectiveDur));
    this.currentTime = clamped;

    if (this.isPlaying && this.isBufferLoaded) {
      this.startTonePlayerAtCurrentTime();
      this.lastFrameTimestamp = performance.now();
    }

    this.onTimeUpdate?.(this.currentTime, effectiveDur);
  }

  public setVolume(val: number) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.toneCtx) {
      this.masterGain.gain.setTargetAtTime(
        this.getTargetMasterGain(),
        this.toneCtx.currentTime,
        0.02
      );
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain && this.toneCtx) {
      this.masterGain.gain.setTargetAtTime(
        this.getTargetMasterGain(),
        this.toneCtx.currentTime,
        0.02
      );
    }
  }

  public setReplayGainDb(dbOffset: number) {
    this.replayGainLinear = Math.pow(10, dbOffset / 20);
    if (this.masterGain && this.toneCtx) {
      this.masterGain.gain.setTargetAtTime(
        this.getTargetMasterGain(),
        this.toneCtx.currentTime,
        0.03
      );
    }
  }

  /**
   * Adjusts the sleep timer fade-out gain multiplier (1.0 = normal volume, 0.0 = silent)
   * Used during the 10-second fade-out before the sleep timer pauses playback.
   */
  public setSleepFadeMultiplier(multiplier: number) {
    this.sleepFadeMultiplier = Math.max(0, Math.min(1, multiplier));
    if (this.masterGain && this.toneCtx) {
      const now = this.toneCtx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setTargetAtTime(this.getTargetMasterGain(), now, 0.08);
    }
  }

  /**
   * Immediately pauses playback when the sleep timer finishes and restores
   * the fade multiplier back to 1.0 for subsequent playback.
   */
  public completeSleepTimerPause() {
    if (this.pauseTimeoutId !== null) {
      window.clearTimeout(this.pauseTimeoutId);
      this.pauseTimeoutId = null;
    }
    this.isPlaying = false;
    this.stopTonePlayerSafe();
    this.stopProgressLoop();
    this.sleepFadeMultiplier = 1.0;
    if (this.masterGain && this.toneCtx) {
      const now = this.toneCtx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setValueAtTime(this.getTargetMasterGain(), now);
    }
  }

  public setLoopPoints(start: number | null, end: number | null) {
    this.loopStart = start;
    this.loopEnd = end;
  }

  /**
   * Real-time independent Speed (Tone.Player.playbackRate) & Pitch (Tone.PitchShift.pitch) update
   */
  public setSpeedAndPitch(rate: number, pitchRate: number) {
    this.playbackRate = Math.max(0.5, Math.min(2.0, rate));
    this.pitchRate = pitchRate;
    this.syncToneSpeedAndPitch();
  }

  public applyEqualizer(eqState: EqualizerState) {
    this.ensureToneEngine();
    this.setSpeedAndPitch(eqState.playbackRate, eqState.pitchRate ?? 1.0);

    if (this.bassBoostFilter && this.toneCtx) {
      const targetBass = eqState.enabled ? eqState.bassBoost : 0;
      this.bassBoostFilter.gain.setTargetAtTime(targetBass, this.toneCtx.currentTime, 0.03);
    }

    if (this.stereoPanner && this.toneCtx) {
      this.stereoPanner.pan.setTargetAtTime(eqState.stereoWidth, this.toneCtx.currentTime, 0.03);
    }

    eqState.bands.forEach((band, index) => {
      const node = this.eqFilters[index];
      if (node && this.toneCtx) {
        const gainVal = eqState.enabled ? band.gain : 0;
        node.gain.setTargetAtTime(gainVal, this.toneCtx.currentTime, 0.03);
      }
    });
  }
}

export const audioEngine = new WebAudioStudioEngine();
