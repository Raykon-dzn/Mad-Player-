import { Track, WebSystemFileHandle } from '../types/music';
import { parseAudioFileMetadata } from '../utils/audioMetadataParser';
import { extractDominantColorFromImage } from '../utils/colorExtractor';
import { revokeObjectUrlSafe, saveImportedTrackToDb, updateTrackMetaInDb } from './mediaStorageDb';

const AUDIO_EXTENSIONS = new Set([
  'mp3',
  'm4a',
  'flac',
  'wav',
  'ogg'
]);

const PALETTE_POOL = [
  { dom: '#3b4d5e', sec: '#1e293b' },
  { dom: '#0284c7', sec: '#082f49' },
  { dom: '#e11d48', sec: '#4c0519' },
  { dom: '#10b981', sec: '#064e3b' },
  { dom: '#f59e0b', sec: '#451a03' }
];

export interface FileWithFolder {
  file: File;
  folderPath: string;
  fromFolder?: boolean;
  fileHandle?: WebSystemFileHandle;
}

export interface ImportProgressUpdate {
  processed: number;
  total: number;
  currentFileName: string;
  importedCount: number;
  duplicatesSkipped: number;
}

export function isAudioFile(fileName: string, _mimeType?: string): boolean {
  const parts = fileName.toLowerCase().split('.');
  if (parts.length < 2) return false;
  const ext = parts.pop() || '';
  return AUDIO_EXTENSIONS.has(ext);
}

export function isCapacitorNative(): boolean {
  if (typeof window === 'undefined') return false;
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return Boolean(cap?.isNativePlatform?.());
}

export function supportsDirectoryPicker(): boolean {
  return typeof window !== 'undefined' && 'showDirectoryPicker' in window;
}

function probeAudioDurationSeconds(objectUrl: string, fallbackSeconds = 210): Promise<number> {
  return new Promise(resolve => {
    if (typeof Audio === 'undefined') {
      resolve(fallbackSeconds);
      return;
    }
    const tempAudio = new Audio();
    let settled = false;
    const finish = (val: number) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      tempAudio.src = '';
      resolve(val);
    };
    const timer = window.setTimeout(() => {
      finish(fallbackSeconds);
    }, 1500);

    tempAudio.preload = 'metadata';
    tempAudio.addEventListener(
      'loadedmetadata',
      () => {
        if (tempAudio.duration && Number.isFinite(tempAudio.duration) && tempAudio.duration > 0) {
          finish(Math.round(tempAudio.duration));
        } else {
          finish(fallbackSeconds);
        }
      },
      { once: true }
    );
    tempAudio.addEventListener(
      'error',
      () => {
        finish(fallbackSeconds);
      },
      { once: true }
    );
    tempAudio.src = objectUrl;
  });
}

/**
 * Checks whether a candidate audio file is a duplicate of any track in `existingTracks`
 * Criteria:
 * 1. Same title + artist + duration (rounded in seconds)
 * 2. OR same file size and file name
 */
export function isDuplicateTrack(
  candidate: {
    title: string;
    artist: string;
    duration: number;
    fileName: string;
    fileSizeBytes: number;
    fileSizeKB: number;
  },
  existingTracks: Track[]
): boolean {
  const normTitle = candidate.title.trim().toLowerCase();
  const normArtist = candidate.artist.trim().toLowerCase();
  const normFileName = candidate.fileName.trim().toLowerCase();
  const normBaseName = normFileName.replace(/\.[^/.]+$/, '').trim();

  return existingTracks.some(existing => {
    // 1. Mismo título + artista + duración
    const existingTitle = existing.title.trim().toLowerCase();
    const existingArtist = existing.artist.trim().toLowerCase();
    const sameTitleAndArtist =
      normTitle.length > 0 &&
      existingTitle === normTitle &&
      existingArtist === normArtist;
    const sameDuration = Math.round(existing.duration) === Math.round(candidate.duration);

    if (sameTitleAndArtist && sameDuration) {
      return true;
    }

    // 2. Mismo tamaño y nombre
    const existingFileName = (existing.fileName || '').trim().toLowerCase();
    const sameName =
      (existingFileName.length > 0 && existingFileName === normFileName) ||
      (existingFileName.length === 0 && existingTitle === normBaseName);

    const sameSize =
      existing.fileSizeBytes !== undefined
        ? existing.fileSizeBytes === candidate.fileSizeBytes
        : existing.fileSizeKB !== undefined && existing.fileSizeKB === candidate.fileSizeKB;

    if (sameName && sameSize) {
      return true;
    }

    return false;
  });
}

export interface ProcessImportedAudioOptions {
  existingTracks?: Track[];
  onDurationResolved?: (trackId: string, durationSec: number) => void;
  onProgress?: (update: ImportProgressUpdate) => void;
  shouldCancel?: () => boolean;
}

/**
 * Converts a batch of Files (from file selector, webkitdirectory folder input, or File System Access API)
 * into Track objects with embedded cover art, dominant color, folderPath, duplicate avoidance,
 * progress reporting, cancellation support, and IndexedDB persistence.
 */
export async function processImportedAudioFiles(
  entries: FileWithFolder[],
  optionsOrCallback?: ProcessImportedAudioOptions | ((trackId: string, durationSec: number) => void)
): Promise<{
  tracks: Track[];
  coversRecognized: number;
  foldersCount: number;
  duplicatesSkipped: number;
  cancelled: boolean;
}> {
  const opts: ProcessImportedAudioOptions =
    typeof optionsOrCallback === 'function'
      ? { onDurationResolved: optionsOrCallback }
      : optionsOrCallback || {};

  const existingTracks = opts.existingTracks || [];
  const audioEntries = entries.filter(({ file }) => isAudioFile(file.name, file.type));
  const total = audioEntries.length;
  const importedTracks: Track[] = [];
  const folderSet = new Set<string>();
  let coversRecognized = 0;
  let duplicatesSkipped = 0;
  let cancelled = false;

  for (let idx = 0; idx < total; idx++) {
    if (opts.shouldCancel?.()) {
      cancelled = true;
      break;
    }

    const { file, folderPath, fromFolder, fileHandle } = audioEntries[idx];
    const isFromFolder = Boolean(fromFolder);
    const fileSizeBytes = file.size;
    const fileSizeKB = Math.max(1, Math.round(fileSizeBytes / 1024));

    opts.onProgress?.({
      processed: idx,
      total,
      currentFileName: file.name,
      importedCount: importedTracks.length,
      duplicatesSkipped
    });

    // Yield briefly to allow UI progress bar to paint and cancel button clicks to register
    await new Promise<void>(resolve => window.setTimeout(resolve, 0));

    if (opts.shouldCancel?.()) {
      cancelled = true;
      break;
    }

    const rawName = file.name.replace(/\.[^/.]+$/, '');
    const parts = rawName.split(' - ');
    const fallbackArtist = parts.length > 1 ? parts[0].trim() : 'Unknown Artist';
    const fallbackTitle = parts.length > 1 ? parts.slice(1).join(' - ').trim() : rawName;
    const folderLeaf = folderPath.split('/').filter(Boolean).pop() || 'Memoria del Dispositivo';
    const colors = PALETTE_POOL[idx % PALETTE_POOL.length];

    // Fast pre-check by exact file name + file size before decoding binary tags
    const combinedExisting = [...existingTracks, ...importedTracks];
    if (
      isDuplicateTrack(
        {
          title: '',
          artist: '',
          duration: -1,
          fileName: file.name,
          fileSizeBytes,
          fileSizeKB
        },
        combinedExisting
      )
    ) {
      duplicatesSkipped++;
      opts.onProgress?.({
        processed: idx + 1,
        total,
        currentFileName: file.name,
        importedCount: importedTracks.length,
        duplicatesSkipped
      });
      continue;
    }

    const meta = await parseAudioFileMetadata(file);
    const objectUrl = URL.createObjectURL(file);
    const resolvedDuration = await probeAudioDurationSeconds(objectUrl, 210);

    if (opts.shouldCancel?.()) {
      revokeObjectUrlSafe(objectUrl);
      revokeObjectUrlSafe(meta.coverUrl);
      cancelled = true;
      break;
    }

    const candidateTitle = meta.title || fallbackTitle;
    const candidateArtist = meta.artist || fallbackArtist;

    // Full duplicate check: (same title + artist + duration) OR (same file size + file name)
    if (
      isDuplicateTrack(
        {
          title: candidateTitle,
          artist: candidateArtist,
          duration: resolvedDuration,
          fileName: file.name,
          fileSizeBytes,
          fileSizeKB
        },
        [...existingTracks, ...importedTracks]
      )
    ) {
      revokeObjectUrlSafe(objectUrl);
      revokeObjectUrlSafe(meta.coverUrl);
      duplicatesSkipped++;
      opts.onProgress?.({
        processed: idx + 1,
        total,
        currentFileName: file.name,
        importedCount: importedTracks.length,
        duplicatesSkipped
      });
      continue;
    }

    let domColor = colors.dom;
    if (meta.coverUrl) {
      coversRecognized++;
      domColor = await extractDominantColorFromImage(meta.coverUrl, colors.dom);
    }

    folderSet.add(folderPath);

    const newTrack: Track = {
      id: `local-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
      title: candidateTitle,
      artist: candidateArtist,
      album: meta.album || folderLeaf,
      genre: meta.genre || 'Audio Local',
      year: meta.year || new Date().getFullYear(),
      duration: resolvedDuration,
      bpm: meta.bpm || 120,
      coverUrl: meta.coverUrl || '',
      dominantColor: domColor,
      secondaryColor: colors.sec,
      isFavorite: false,
      playCount: 1,
      addedAt: new Date().toISOString().slice(0, 10),
      lastPlayedAt: Date.now(),
      audioUrl: objectUrl,
      folderPath,
      fileName: file.name,
      fileSizeBytes,
      fileSizeKB,
      importedFromFolder: isFromFolder,
      fileHandle,
      lyrics: ['Archivo de audio local cargado desde el dispositivo.']
    };

    const hasFileHandle = Boolean(fileHandle && typeof fileHandle.getFile === 'function');

    await saveImportedTrackToDb(newTrack, hasFileHandle ? undefined : file, meta.coverBlob, {
      fromFolder: isFromFolder,
      fileHandle
    });
    opts.onDurationResolved?.(newTrack.id, resolvedDuration);
    updateTrackMetaInDb(newTrack);

    importedTracks.push(newTrack);

    opts.onProgress?.({
      processed: idx + 1,
      total,
      currentFileName: file.name,
      importedCount: importedTracks.length,
      duplicatesSkipped
    });
  }

  return {
    tracks: importedTracks,
    coversRecognized,
    foldersCount: folderSet.size,
    duplicatesSkipped,
    cancelled
  };
}

/**
 * Extracts folderPath from standard FileList (including webkitRelativePath from folder selector)
 */
export function buildEntriesFromFileList(
  fileList: FileList,
  forceFromFolder = false
): FileWithFolder[] {
  const files = Array.from(fileList);
  return files.map(file => {
    const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || '';
    const hasRelativeFolder = Boolean(rel && rel.includes('/'));
    const fromFolder = forceFromFolder || hasRelativeFolder;
    if (hasRelativeFolder) {
      const segments = rel.split('/').filter(Boolean);
      segments.pop(); // remove filename
      if (segments.length > 0) {
        return {
          file,
          folderPath: `/storage/emulated/0/${segments.join('/')}`,
          fromFolder
        };
      }
    }
    return {
      file,
      folderPath: '/storage/emulated/0/Music/Local',
      fromFolder
    };
  });
}

interface DirectoryHandleLike {
  name: string;
  values: () => AsyncIterable<{
    kind: 'file' | 'directory';
    name: string;
    getFile?: () => Promise<File>;
    queryPermission?: (descriptor?: { mode?: 'read' | 'readwrite' }) => Promise<PermissionState>;
    requestPermission?: (descriptor?: { mode?: 'read' | 'readwrite' }) => Promise<PermissionState>;
    values?: () => AsyncIterable<unknown>;
  }>;
}

async function walkDirectoryHandle(
  dirHandle: DirectoryHandleLike,
  currentPath: string,
  results: FileWithFolder[]
): Promise<void> {
  for await (const entry of dirHandle.values()) {
    if (entry.kind === 'file' && entry.getFile) {
      if (isAudioFile(entry.name)) {
        const file = await entry.getFile();
        results.push({
          file,
          folderPath: currentPath,
          fromFolder: true,
          fileHandle: entry as WebSystemFileHandle
        });
      }
    } else if (entry.kind === 'directory' && entry.values) {
      await walkDirectoryHandle(
        entry as unknown as DirectoryHandleLike,
        `${currentPath}/${entry.name}`,
        results
      );
    }
  }
}

/**
 * Uses the Web File System Access API (window.showDirectoryPicker) to recursively scan a folder.
 * Returns null if unsupported, blocked by iframe permissions, or cancelled by the user.
 */
export async function pickDirectoryAndCollectAudioFiles(): Promise<FileWithFolder[] | null> {
  if (!supportsDirectoryPicker()) return null;
  try {
    const picker = (
      window as unknown as {
        showDirectoryPicker: (opts?: { mode?: 'read' }) => Promise<DirectoryHandleLike>;
      }
    ).showDirectoryPicker;
    const rootHandle = await picker({ mode: 'read' });
    const collected: FileWithFolder[] = [];
    await walkDirectoryHandle(rootHandle, `/storage/emulated/0/${rootHandle.name}`, collected);
    return collected;
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      return [];
    }
    return null;
  }
}

/**
 * Native Android library scanner when packaged as an APK with Capacitor (@capacitor/filesystem).
 * Automatically scans /storage/emulated/0/Music, /Download, and /Podcasts.
 */
export async function scanCapacitorDeviceLibrary(): Promise<FileWithFolder[] | null> {
  if (!isCapacitorNative()) return null;
  try {
    const cap = (
      window as unknown as {
        Capacitor?: {
          Plugins?: {
            Filesystem?: {
              readdir: (opts: { path: string; directory?: string }) => Promise<{
                files: { name: string; type: 'file' | 'directory'; uri?: string }[];
              }>;
              readFile: (opts: { path: string; directory?: string }) => Promise<{ data: string }>;
            };
          };
        };
      }
    ).Capacitor;

    const fs = cap?.Plugins?.Filesystem;
    if (!fs) return null;

    const targetFolders = ['Music', 'Download', 'Podcasts'];
    const entries: FileWithFolder[] = [];

    for (const dir of targetFolders) {
      try {
        const res = await fs.readdir({ path: dir, directory: 'EXTERNAL_STORAGE' });
        for (const item of res.files || []) {
          if (item.type === 'file' && isAudioFile(item.name)) {
            const fileData = await fs.readFile({
              path: `${dir}/${item.name}`,
              directory: 'EXTERNAL_STORAGE'
            });
            const byteCharacters = atob(fileData.data);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const blob = new Blob([new Uint8Array(byteNumbers)], { type: 'audio/mpeg' });
            const file = new File([blob], item.name, { type: 'audio/mpeg' });
            entries.push({
              file,
              folderPath: `/storage/emulated/0/${dir}`,
              fromFolder: true
            });
          }
        }
      } catch {
        // Skip inaccessible directory
      }
    }

    return entries;
  } catch {
    return null;
  }
}
