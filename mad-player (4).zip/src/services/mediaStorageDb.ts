import {
  Playlist,
  SmartPlaylist,
  ThemeConfig,
  Track,
  WebSystemFileHandle
} from '../types/music';

const DB_NAME = 'mad_player_media_db_v1';
const DB_VERSION = 2;
const STORE_TRACKS = 'imported_tracks';
const STORE_WALLPAPERS = 'custom_wallpapers';
const STORE_APP_STATE = 'app_state';

const LEGACY_LOCAL_STORAGE_KEYS = {
  tracks: ['mad_player_tracks_single_v1', 'mad_player_tracks_v1'],
  playlists: ['mad_player_playlists_single_v1', 'mad_player_playlists_v1'],
  smartPlaylists: ['mad_player_smart_playlists_single_v1', 'mad_player_smart_playlists_v1'],
  theme: ['mad_player_theme_v2', 'mad_player_theme_v1'],
  cloudEmail: ['mad_player_cloud_email_v1'],
  cloudBackup: ['mad_player_cloud_backup_v1']
} as const;

export interface StoredTrackRecord {
  id: string;
  trackMeta: Omit<Track, 'audioUrl' | 'coverUrl' | 'fileHandle'>;
  audioBlob?: Blob;
  fileHandle?: WebSystemFileHandle;
  coverBlob?: Blob;
  coverDataUrl?: string;
}

export interface StorageUsageEstimate {
  usageBytes: number;
  quotaBytes: number;
  persisted: boolean;
  supported: boolean;
}

export interface StoredWallpaperRecord {
  id: string;
  blob?: Blob;
  dataUrl?: string;
  alpha: number;
  blur: number;
  createdAt: number;
}

interface StoredAppStateRecord<T = unknown> {
  key: string;
  value: T;
  updatedAt: number;
}

export function revokeObjectUrlSafe(url?: string | null): void {
  if (url && url.startsWith('blob:')) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      // Ignore already revoked URLs
    }
  }
}

/**
 * Calls navigator.storage.persist() if supported by the browser.
 */
export async function requestPersistentStorage(): Promise<boolean> {
  try {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
      return await navigator.storage.persist();
    }
  } catch {
    // Ignore errors in restricted or iframe contexts
  }
  return false;
}

/**
 * Queries navigator.storage.estimate() and navigator.storage.persisted() for Settings UI.
 */
export async function getStorageUsageEstimate(): Promise<StorageUsageEstimate> {
  try {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.estimate) {
      const [estimate, persisted] = await Promise.all([
        navigator.storage.estimate(),
        navigator.storage.persisted ? navigator.storage.persisted() : Promise.resolve(false)
      ]);
      return {
        usageBytes: estimate.usage ?? 0,
        quotaBytes: estimate.quota ?? 0,
        persisted: Boolean(persisted),
        supported: true
      };
    }
  } catch {
    // Ignore errors
  }
  return {
    usageBytes: 0,
    quotaBytes: 0,
    persisted: false,
    supported: false
  };
}

/**
 * Reopens a Track's FileSystemFileHandle (if present) after a page reload.
 * Queries read permission first and requests permission when needed.
 */
export async function reopenTrackAudioFromHandle(
  track: Track,
  requestIfPrompt = true
): Promise<string | null> {
  if (track.audioUrl) return track.audioUrl;
  const handle = track.fileHandle;
  if (!handle || typeof handle.getFile !== 'function') return null;

  try {
    if (typeof handle.queryPermission === 'function') {
      let state = await handle.queryPermission({ mode: 'read' });
      if (state !== 'granted') {
        if (!requestIfPrompt || typeof handle.requestPermission !== 'function') {
          return null;
        }
        state = await handle.requestPermission({ mode: 'read' });
      }
      if (state !== 'granted') {
        return null;
      }
    }
    const file = await handle.getFile();
    return URL.createObjectURL(file);
  } catch {
    return null;
  }
}

function openMediaDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_TRACKS)) {
        db.createObjectStore(STORE_TRACKS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_WALLPAPERS)) {
        db.createObjectStore(STORE_WALLPAPERS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_APP_STATE)) {
        db.createObjectStore(STORE_APP_STATE, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function putAppStateRecord<T>(key: string, value: T): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_APP_STATE, 'readwrite');
    const store = tx.objectStore(STORE_APP_STATE);
    const record: StoredAppStateRecord<T> = {
      key,
      value,
      updatedAt: Date.now()
    };
    store.put(record);
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Ignore storage quota or private browsing errors
  }
}

async function getAppStateRecord<T>(key: string): Promise<T | null> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_APP_STATE, 'readonly');
    const store = tx.objectStore(STORE_APP_STATE);
    const req = store.get(key);
    const result = await new Promise<StoredAppStateRecord<T> | undefined>((resolve, reject) => {
      req.onsuccess = () => resolve(req.result as StoredAppStateRecord<T> | undefined);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return result ? result.value : null;
  } catch {
    return null;
  }
}

export async function saveImportedTrackToDb(
  track: Track,
  audioBlob?: Blob,
  coverBlob?: Blob,
  options?: {
    fromFolder?: boolean;
    fileHandle?: WebSystemFileHandle;
  }
): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    const store = tx.objectStore(STORE_TRACKS);

    const { audioUrl: _a, coverUrl, fileHandle: trackHandle, ...restMeta } = track;
    const isFromFolder = Boolean(options?.fromFolder ?? track.importedFromFolder);
    const resolvedHandle = options?.fileHandle ?? trackHandle;
    const hasFileHandle = Boolean(resolvedHandle && typeof resolvedHandle.getFile === 'function');

    // Rule: ONLY omit audioBlob when fileHandle exists.
    // If there is no fileHandle (e.g. webkitdirectory fallback or classic file selector),
    // save audioBlob as backup so the track is not silent after reload.
    const record: StoredTrackRecord = {
      id: track.id,
      trackMeta: {
        ...restMeta,
        importedFromFolder: isFromFolder,
        audioUnavailable: false
      },
      audioBlob: hasFileHandle ? undefined : audioBlob,
      fileHandle: resolvedHandle,
      coverBlob,
      coverDataUrl: coverUrl && !coverUrl.startsWith('blob:') ? coverUrl : undefined
    };

    store.put(record);
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // Ignore storage quota or private browsing errors
  }
}

export async function updateTrackMetaInDb(
  track: Track,
  newCoverBlob?: Blob | null
): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    const store = tx.objectStore(STORE_TRACKS);

    const getReq = store.get(track.id);
    await new Promise<void>(resolve => {
      getReq.onsuccess = () => {
        const existing = getReq.result as StoredTrackRecord | undefined;
        const { audioUrl: _a, coverUrl, fileHandle, ...restMeta } = track;
        if (existing) {
          existing.trackMeta = restMeta;
          if (fileHandle) {
            existing.fileHandle = fileHandle;
            existing.audioBlob = undefined;
          }
          if (newCoverBlob !== undefined) {
            if (newCoverBlob === null) {
              existing.coverBlob = undefined;
              existing.coverDataUrl = undefined;
            } else {
              existing.coverBlob = newCoverBlob;
              existing.coverDataUrl = undefined;
            }
          } else if (!coverUrl) {
            existing.coverBlob = undefined;
            existing.coverDataUrl = undefined;
          } else if (!coverUrl.startsWith('blob:')) {
            existing.coverDataUrl = coverUrl;
          }
          store.put(existing);
        } else {
          const created: StoredTrackRecord = {
            id: track.id,
            trackMeta: restMeta,
            fileHandle,
            coverBlob: newCoverBlob || undefined,
            coverDataUrl: coverUrl && !coverUrl.startsWith('blob:') ? coverUrl : undefined
          };
          store.put(created);
        }
        resolve();
      };
      getReq.onerror = () => resolve();
    });
    await new Promise<void>(resolve => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
    db.close();
  } catch {
    // Ignore errors
  }
}

export async function cloneTrackInDb(sourceTrackId: string, newTrack: Track): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    const store = tx.objectStore(STORE_TRACKS);

    const getReq = store.get(sourceTrackId);
    await new Promise<void>(resolve => {
      getReq.onsuccess = () => {
        const source = getReq.result as StoredTrackRecord | undefined;
        const { audioUrl: _a, coverUrl, fileHandle, ...restMeta } = newTrack;
        const resolvedHandle = fileHandle ?? source?.fileHandle;
        const hasHandle = Boolean(resolvedHandle && typeof resolvedHandle.getFile === 'function');
        const cloned: StoredTrackRecord = {
          id: newTrack.id,
          trackMeta: restMeta,
          audioBlob: hasHandle ? undefined : source?.audioBlob,
          fileHandle: resolvedHandle,
          coverBlob: source?.coverBlob,
          coverDataUrl:
            source?.coverDataUrl ||
            (coverUrl && !coverUrl.startsWith('blob:') ? coverUrl : undefined)
        };
        store.put(cloned);
        resolve();
      };
      getReq.onerror = () => resolve();
    });
    await new Promise<void>(resolve => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
    db.close();
  } catch {
    // Ignore errors
  }
}

export async function saveTracksListMetaToDb(tracks: Track[]): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    const store = tx.objectStore(STORE_TRACKS);

    for (const track of tracks) {
      await new Promise<void>(resolve => {
        const getReq = store.get(track.id);
        getReq.onsuccess = () => {
          const existing = getReq.result as StoredTrackRecord | undefined;
          const { audioUrl: _a, coverUrl, fileHandle, ...restMeta } = track;
          if (existing) {
            existing.trackMeta = restMeta;
            if (fileHandle) {
              existing.fileHandle = fileHandle;
              existing.audioBlob = undefined;
            }
            if (coverUrl && !coverUrl.startsWith('blob:')) {
              existing.coverDataUrl = coverUrl;
            }
            store.put(existing);
          } else {
            store.put({
              id: track.id,
              trackMeta: restMeta,
              fileHandle,
              coverDataUrl: coverUrl && !coverUrl.startsWith('blob:') ? coverUrl : undefined
            } satisfies StoredTrackRecord);
          }
          resolve();
        };
        getReq.onerror = () => resolve();
      });
    }

    await new Promise<void>(resolve => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
    db.close();
  } catch {
    // Ignore errors
  }
}

export async function deleteTrackFromDb(trackId: string): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    tx.objectStore(STORE_TRACKS).delete(trackId);
    await new Promise<void>(resolve => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
    db.close();
  } catch {
    // Ignore errors
  }
}

export async function loadImportedTracksFromDb(): Promise<Track[]> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_TRACKS, 'readonly');
    const store = tx.objectStore(STORE_TRACKS);
    const req = store.getAll();

    const records = await new Promise<StoredTrackRecord[]>((resolve, reject) => {
      req.onsuccess = () => resolve((req.result as StoredTrackRecord[]) || []);
      req.onerror = () => reject(req.error);
    });
    db.close();

    return await Promise.all(
      records.map(async rec => {
        let audioUrl: string | undefined;
        const hasAudioBlob = Boolean(rec.audioBlob);
        const hasFileHandle = Boolean(
          rec.fileHandle && typeof rec.fileHandle.getFile === 'function'
        );
        const audioUnavailable = !hasAudioBlob && !hasFileHandle;

        if (rec.audioBlob) {
          audioUrl = URL.createObjectURL(rec.audioBlob);
        } else if (rec.fileHandle && typeof rec.fileHandle.getFile === 'function') {
          // If permission is already granted after reload, reopen the file immediately;
          // otherwise keep fileHandle on the Track to request permission when played.
          try {
            const permState =
              typeof rec.fileHandle.queryPermission === 'function'
                ? await rec.fileHandle.queryPermission({ mode: 'read' })
                : 'granted';
            if (permState === 'granted') {
              const file = await rec.fileHandle.getFile();
              audioUrl = URL.createObjectURL(file);
            }
          } catch {
            // Permission requires user gesture on playback
          }
        }

        let coverUrl = rec.coverDataUrl || '';
        if (rec.coverBlob) {
          coverUrl = URL.createObjectURL(rec.coverBlob);
        }
        return {
          ...rec.trackMeta,
          audioUrl,
          coverUrl,
          fileHandle: rec.fileHandle,
          audioUnavailable
        };
      })
    );
  } catch {
    return [];
  }
}

export async function saveWallpaperToDb(
  id: string,
  blob: Blob,
  alpha: number,
  blur: number,
  replacePrevious = true
): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_WALLPAPERS, 'readwrite');
    const store = tx.objectStore(STORE_WALLPAPERS);
    if (replacePrevious) {
      store.clear();
    }
    const record: StoredWallpaperRecord = {
      id,
      blob,
      alpha,
      blur,
      createdAt: Date.now()
    };
    store.put(record);
    await new Promise<void>(resolve => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
    db.close();
  } catch {
    // Ignore errors
  }
}

export async function updateWallpaperMetaInDb(
  id: string,
  alpha: number,
  blur: number
): Promise<void> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_WALLPAPERS, 'readwrite');
    const store = tx.objectStore(STORE_WALLPAPERS);
    const req = store.get(id);
    await new Promise<void>(resolve => {
      req.onsuccess = () => {
        const existing = req.result as StoredWallpaperRecord | undefined;
        if (existing) {
          existing.alpha = alpha;
          existing.blur = blur;
          store.put(existing);
        }
        resolve();
      };
      req.onerror = () => resolve();
    });
    await new Promise<void>(resolve => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
    db.close();
  } catch {
    // Ignore errors
  }
}

export async function loadWallpapersFromDb(): Promise<
  { id: string; url: string; alpha: number; blur: number }[]
> {
  try {
    const db = await openMediaDb();
    const tx = db.transaction(STORE_WALLPAPERS, 'readonly');
    const store = tx.objectStore(STORE_WALLPAPERS);
    const req = store.getAll();

    const records = await new Promise<StoredWallpaperRecord[]>((resolve, reject) => {
      req.onsuccess = () => resolve((req.result as StoredWallpaperRecord[]) || []);
      req.onerror = () => reject(req.error);
    });
    db.close();

    return records
      .sort((a, b) => b.createdAt - a.createdAt)
      .map(rec => ({
        id: rec.id,
        url: rec.blob ? URL.createObjectURL(rec.blob) : rec.dataUrl || '',
        alpha: rec.alpha,
        blur: rec.blur
      }))
      .filter(item => Boolean(item.url));
  } catch {
    return [];
  }
}

export async function savePlaylistsToDb(playlists: Playlist[]): Promise<void> {
  await putAppStateRecord('playlists', playlists);
}

export async function loadPlaylistsFromDb(): Promise<Playlist[] | null> {
  return getAppStateRecord<Playlist[]>('playlists');
}

export async function saveSmartPlaylistsToDb(smartPlaylists: SmartPlaylist[]): Promise<void> {
  await putAppStateRecord('smartPlaylists', smartPlaylists);
}

export async function loadSmartPlaylistsFromDb(): Promise<SmartPlaylist[] | null> {
  return getAppStateRecord<SmartPlaylist[]>('smartPlaylists');
}

export async function saveThemeConfigToDb(themeConfig: ThemeConfig): Promise<void> {
  const sanitizedTheme: ThemeConfig = {
    ...themeConfig,
    bgImageUrl:
      themeConfig.bgImageUrl && themeConfig.bgImageUrl.startsWith('blob:')
        ? undefined
        : themeConfig.bgImageUrl,
    customUserImages: (themeConfig.customUserImages || []).filter(
      img => !img.url.startsWith('blob:')
    )
  };
  await putAppStateRecord('themeConfig', sanitizedTheme);
}

export async function loadThemeConfigFromDb(): Promise<ThemeConfig | null> {
  return getAppStateRecord<ThemeConfig>('themeConfig');
}

export async function saveCloudEmailToDb(email: string): Promise<void> {
  await putAppStateRecord('cloudEmail', email);
}

export async function loadCloudEmailFromDb(): Promise<string | null> {
  return getAppStateRecord<string>('cloudEmail');
}

export async function saveCloudBackupToDb(payload: unknown): Promise<void> {
  await putAppStateRecord('cloudBackup', payload);
}

export async function loadCloudBackupFromDb<T = unknown>(): Promise<T | null> {
  return getAppStateRecord<T>('cloudBackup');
}

let migrationPromise: Promise<void> | null = null;

/**
 * One-time migration that reads legacy localStorage keys (tracks, playlists,
 * smartPlaylists, themeConfig, cloud backup/email), saves them into IndexedDB,
 * and deletes the old keys from localStorage.
 */
export function migrateLocalStorageToIndexedDb(): Promise<void> {
  if (migrationPromise) return migrationPromise;

  migrationPromise = (async () => {
    if (typeof window === 'undefined' || !('localStorage' in window)) return;

    try {
      // 1. Migrate legacy tracks
      for (const key of LEGACY_LOCAL_STORAGE_KEYS.tracks) {
        const raw = window.localStorage.getItem(key);
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              const validTracks = parsed.filter(
                (t: Track) => t && typeof t.id === 'string' && t.id !== 'trk-01'
              );
              if (validTracks.length > 0) {
                await saveTracksListMetaToDb(validTracks);
              }
            }
          } catch {
            // Ignore malformed JSON
          }
          window.localStorage.removeItem(key);
        }
      }

      // 2. Migrate legacy playlists
      for (const key of LEGACY_LOCAL_STORAGE_KEYS.playlists) {
        const raw = window.localStorage.getItem(key);
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
              const existing = await loadPlaylistsFromDb();
              if (!existing) {
                const cleaned = parsed.filter((p: Playlist) => p && p.id !== 'pl-studio-night');
                await savePlaylistsToDb(cleaned);
              }
            }
          } catch {
            // Ignore malformed JSON
          }
          window.localStorage.removeItem(key);
        }
      }

      // 3. Migrate legacy smart playlists
      for (const key of LEGACY_LOCAL_STORAGE_KEYS.smartPlaylists) {
        const raw = window.localStorage.getItem(key);
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
              const existing = await loadSmartPlaylistsFromDb();
              if (!existing) {
                await saveSmartPlaylistsToDb(parsed);
              }
            }
          } catch {
            // Ignore malformed JSON
          }
          window.localStorage.removeItem(key);
        }
      }

      // 4. Migrate legacy themeConfig
      for (const key of LEGACY_LOCAL_STORAGE_KEYS.theme) {
        const raw = window.localStorage.getItem(key);
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            if (parsed && typeof parsed === 'object') {
              const existing = await loadThemeConfigFromDb();
              if (!existing) {
                await saveThemeConfigToDb(parsed as ThemeConfig);
              }
            }
          } catch {
            // Ignore malformed JSON
          }
          window.localStorage.removeItem(key);
        }
      }

      // 5. Migrate legacy cloud backup & email
      for (const key of LEGACY_LOCAL_STORAGE_KEYS.cloudEmail) {
        const raw = window.localStorage.getItem(key);
        if (raw) {
          const existing = await loadCloudEmailFromDb();
          if (!existing) {
            await saveCloudEmailToDb(raw);
          }
          window.localStorage.removeItem(key);
        }
      }

      for (const key of LEGACY_LOCAL_STORAGE_KEYS.cloudBackup) {
        const raw = window.localStorage.getItem(key);
        if (raw) {
          try {
            const parsed = JSON.parse(raw);
            const existing = await loadCloudBackupFromDb();
            if (!existing && parsed) {
              await saveCloudBackupToDb(parsed);
            }
          } catch {
            // Ignore malformed JSON
          }
          window.localStorage.removeItem(key);
        }
      }
    } catch {
      // Ignore storage access errors
    }
  })();

  return migrationPromise;
}

