export interface ParsedAudioMetadata {
  title?: string;
  artist?: string;
  album?: string;
  genre?: string;
  year?: number;
  bpm?: number;
  coverUrl?: string; // ObjectURL of embedded APIC/covr/FLAC picture, or undefined if none
  coverBlob?: Blob; // Raw Blob of embedded picture for IndexedDB persistence
}

function decodeText(bytes: Uint8Array, encodingByte: number): string {
  try {
    if (encodingByte === 0) {
      return new TextDecoder('iso-8859-1').decode(bytes).replace(/\0/g, '').trim();
    } else if (encodingByte === 1) {
      return new TextDecoder('utf-16').decode(bytes).replace(/\0/g, '').trim();
    } else if (encodingByte === 2) {
      return new TextDecoder('utf-16be').decode(bytes).replace(/\0/g, '').trim();
    } else {
      return new TextDecoder('utf-8').decode(bytes).replace(/\0/g, '').trim();
    }
  } catch {
    return new TextDecoder('utf-8', { fatal: false }).decode(bytes).replace(/\0/g, '').trim();
  }
}

function readSynchsafeInt(view: DataView, offset: number): number {
  return (
    ((view.getUint8(offset) & 0x7f) << 21) |
    ((view.getUint8(offset + 1) & 0x7f) << 14) |
    ((view.getUint8(offset + 2) & 0x7f) << 7) |
    (view.getUint8(offset + 3) & 0x7f)
  );
}

/**
 * Extracts a valid JPEG or PNG Blob from a byte slice by locating magic headers.
 */
function extractImageBlobFromBytes(
  data: Uint8Array,
  maxScanOffset = 256
): { url: string; blob: Blob } | undefined {
  const limit = Math.min(maxScanOffset, data.length - 8);
  for (let i = 0; i <= limit; i++) {
    // Check JPEG Magic Bytes: FF D8 FF
    if (data[i] === 0xff && data[i + 1] === 0xd8 && data[i + 2] === 0xff) {
      // Find JPEG EOI (FF D9) searching from end of slice backwards or take full slice
      let endIdx = data.length;
      for (let j = data.length - 2; j > i + 16; j--) {
        if (data[j] === 0xff && data[j + 1] === 0xd9) {
          endIdx = j + 2;
          break;
        }
      }
      const imgBytes = data.slice(i, endIdx);
      const blob = new Blob([imgBytes.buffer as ArrayBuffer], { type: 'image/jpeg' });
      return { url: URL.createObjectURL(blob), blob };
    }

    // Check PNG Magic Bytes: 89 50 4E 47 0D 0A 1A 0A
    if (
      data[i] === 0x89 &&
      data[i + 1] === 0x50 &&
      data[i + 2] === 0x4e &&
      data[i + 3] === 0x47
    ) {
      let endIdx = data.length;
      // Search for IEND chunk (49 45 4E 44 AE 42 60 82)
      for (let j = i + 16; j < data.length - 7; j++) {
        if (
          data[j] === 0x49 &&
          data[j + 1] === 0x45 &&
          data[j + 2] === 0x4e &&
          data[j + 3] === 0x44
        ) {
          endIdx = Math.min(data.length, j + 8);
          break;
        }
      }
      const imgBytes = data.slice(i, endIdx);
      const blob = new Blob([imgBytes.buffer as ArrayBuffer], { type: 'image/png' });
      return { url: URL.createObjectURL(blob), blob };
    }
  }
  return undefined;
}

/**
 * Parses ID3v2.2, ID3v2.3, ID3v2.4, MP4/M4A (covr), and FLAC tags from an audio file
 * to extract embedded Cover Art and Title/Artist/Album metadata.
 */
export async function parseAudioFileMetadata(file: File): Promise<ParsedAudioMetadata> {
  const result: ParsedAudioMetadata = {};

  try {
    // Read up to first 8MB to capture high-resolution embedded album art
    const slice = file.slice(0, Math.min(file.size, 8 * 1024 * 1024));
    const buffer = await slice.arrayBuffer();
    const view = new DataView(buffer);
    const bytes = new Uint8Array(buffer);

    // 1. Check for "ID3" header at offset 0 (MP3 / WAV / AIFF with ID3v2)
    if (
      bytes.length > 10 &&
      bytes[0] === 0x49 && // 'I'
      bytes[1] === 0x44 && // 'D'
      bytes[2] === 0x33 // '3'
    ) {
      const version = bytes[3]; // 2, 3, or 4
      const flags = bytes[5];
      const tagSize = readSynchsafeInt(view, 6);
      const limit = Math.min(bytes.length, 10 + tagSize);

      let offset = 10;
      if ((flags & 0x40) !== 0 && offset + 4 < limit) {
        const extSize =
          version === 4 ? readSynchsafeInt(view, offset) : view.getUint32(offset, false);
        offset += extSize;
      }

      while (offset < limit - 10) {
        if (bytes[offset] === 0) break;

        let frameId = '';
        let frameSize = 0;
        let headerLen = 10;

        if (version === 2) {
          frameId = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2]);
          frameSize =
            (bytes[offset + 3] << 16) | (bytes[offset + 4] << 8) | bytes[offset + 5];
          headerLen = 6;
        } else {
          frameId = String.fromCharCode(
            bytes[offset],
            bytes[offset + 1],
            bytes[offset + 2],
            bytes[offset + 3]
          );
          if (version === 4) {
            const synchSize = readSynchsafeInt(view, offset + 4);
            const rawSize = view.getUint32(offset + 4, false);
            // Handle encoders that write non-synchsafe sizes in v2.4
            if (
              rawSize > synchSize &&
              offset + 10 + rawSize <= limit &&
              frameId === 'APIC'
            ) {
              frameSize = rawSize;
            } else {
              frameSize = synchSize;
            }
          } else {
            frameSize = view.getUint32(offset + 4, false);
          }
          headerLen = 10;
        }

        if (frameSize <= 0 || offset + headerLen + frameSize > limit) {
          break;
        }

        const frameStart = offset + headerLen;
        const frameData = bytes.subarray(frameStart, frameStart + frameSize);

        // Text frames
        if (
          frameId === 'TIT2' ||
          frameId === 'TT2' ||
          frameId === 'TPE1' ||
          frameId === 'TP1' ||
          frameId === 'TALB' ||
          frameId === 'TAL' ||
          frameId === 'TCON' ||
          frameId === 'TCO' ||
          frameId === 'TYER' ||
          frameId === 'TDRC' ||
          frameId === 'TBPM'
        ) {
          const encoding = frameData[0];
          const text = decodeText(frameData.subarray(1), encoding);
          if (text) {
            if (frameId === 'TIT2' || frameId === 'TT2') result.title = text;
            else if (frameId === 'TPE1' || frameId === 'TP1') result.artist = text;
            else if (frameId === 'TALB' || frameId === 'TAL') result.album = text;
            else if (frameId === 'TCON' || frameId === 'TCO') result.genre = text;
            else if (frameId === 'TYER' || frameId === 'TDRC') {
              const yr = parseInt(text.slice(0, 4), 10);
              if (!Number.isNaN(yr)) result.year = yr;
            } else if (frameId === 'TBPM') {
              const b = parseInt(text, 10);
              if (!Number.isNaN(b)) result.bpm = b;
            }
          }
        }

        // Attached Picture Frame (APIC for v2.3/v2.4, PIC for v2.2)
        if ((frameId === 'APIC' || frameId === 'PIC') && !result.coverUrl) {
          const extracted = extractImageBlobFromBytes(frameData, 512);
          if (extracted) {
            result.coverUrl = extracted.url;
            result.coverBlob = extracted.blob;
          }
        }

        offset += headerLen + frameSize;
      }
    }

    // 2. Parse Vorbis Comments for FLAC ("fLaC") and Ogg ("OggS") if title/artist not yet found
    if (!result.title || !result.artist) {
      const asciiScanLimit = Math.min(bytes.length, 256 * 1024);
      const headerText = new TextDecoder('utf-8', { fatal: false }).decode(
        bytes.subarray(0, asciiScanLimit)
      );
      const vorbisMatch = (key: string): string | undefined => {
        const regex = new RegExp(`(?:^|[\\x00-\\x1f])${key}=([^\\x00-\\x1f]+)`, 'i');
        const m = headerText.match(regex);
        return m?.[1]?.trim();
      };

      if (!result.title) result.title = vorbisMatch('TITLE');
      if (!result.artist) result.artist = vorbisMatch('ARTIST');
      if (!result.album) result.album = vorbisMatch('ALBUM');
      if (!result.genre) result.genre = vorbisMatch('GENRE');
      if (!result.year) {
        const dateStr = vorbisMatch('DATE') || vorbisMatch('YEAR');
        if (dateStr) {
          const yr = parseInt(dateStr.slice(0, 4), 10);
          if (!Number.isNaN(yr)) result.year = yr;
        }
      }
      if (!result.bpm) {
        const bpmStr = vorbisMatch('BPM') || vorbisMatch('TEMPO');
        if (bpmStr) {
          const b = parseInt(bpmStr, 10);
          if (!Number.isNaN(b)) result.bpm = b;
        }
      }
    }

    // 3. Fallback deep scan for APIC / M4A 'covr' / FLAC embedded JPEG or PNG if not yet found
    if (!result.coverUrl) {
      // Search for 'APIC' or 'covr' or 'image/jpeg' or 'image/png' marker in first 2MB
      const searchLimit = Math.min(bytes.length - 64, 2 * 1024 * 1024);
      for (let i = 0; i < searchLimit; i++) {
        const isApic =
          bytes[i] === 0x41 &&
          bytes[i + 1] === 0x50 &&
          bytes[i + 2] === 0x49 &&
          bytes[i + 3] === 0x43; // 'APIC'
        const isCovr =
          bytes[i] === 0x63 &&
          bytes[i + 1] === 0x6f &&
          bytes[i + 2] === 0x76 &&
          bytes[i + 3] === 0x72; // 'covr'

        if (isApic || isCovr) {
          const sub = bytes.subarray(i, Math.min(bytes.length, i + 4 * 1024 * 1024));
          const extracted = extractImageBlobFromBytes(sub, 512);
          if (extracted) {
            result.coverUrl = extracted.url;
            result.coverBlob = extracted.blob;
            break;
          }
        }
      }
    }
  } catch {
    // Fallback to filename parsing if binary header is non-standard
  }

  return result;
}
