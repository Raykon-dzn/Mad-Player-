import { ThemeBaseId, ThemeConfig } from '../types/music';

export interface ComputedPalette {
  bg: string;
  surface: string;
  surfaceHover: string;
  border: string;
  text: string;
  muted: string;
  accent: string;
  accentSoft: string;
  accentFg: string;
  isLight: boolean;
}

const STATIC_THEMES: Record<Exclude<ThemeBaseId, 'dynamic-cover'>, Omit<ComputedPalette, 'accent' | 'accentSoft' | 'accentFg'> & { defaultAccent: string }> = {
  'obsidian-studio': {
    bg: '#0b0f17',
    surface: '#131924',
    surfaceHover: '#1c2536',
    border: 'rgba(255, 255, 255, 0.12)',
    text: '#ffffff',
    muted: '#cbd5e1',
    defaultAccent: '#f59e0b',
    isLight: false
  },
  'nordic-slate': {
    bg: '#0f172a',
    surface: '#1e293b',
    surfaceHover: '#283548',
    border: 'rgba(255, 255, 255, 0.12)',
    text: '#ffffff',
    muted: '#cbd5e1',
    defaultAccent: '#38bdf8',
    isLight: false
  },
  'velvet-crimson': {
    bg: '#140a0e',
    surface: '#211117',
    surfaceHover: '#2e1820',
    border: 'rgba(255, 255, 255, 0.12)',
    text: '#ffffff',
    muted: '#e5c1cd',
    defaultAccent: '#f43f5e',
    isLight: false
  },
  'solar-concrete': {
    bg: '#161311',
    surface: '#241f1c',
    surfaceHover: '#302925',
    border: 'rgba(255, 255, 255, 0.12)',
    text: '#ffffff',
    muted: '#d6d3d1',
    defaultAccent: '#f97316',
    isLight: false
  },
  'editorial-paper': {
    bg: '#f8fafc',
    surface: '#ffffff',
    surfaceHover: '#f1f5f9',
    border: 'rgba(15, 23, 42, 0.14)',
    text: '#0f172a',
    muted: '#334155',
    defaultAccent: '#0284c7',
    isLight: true
  }
};

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const clean = hex.replace('#', '');
  const num = parseInt(clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
}

function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (n: number) => Math.max(0, Math.min(255, Math.round(n)));
  return '#' + [clamp(r), clamp(g), clamp(b)].map(x => x.toString(16).padStart(2, '0')).join('');
}

function mixColors(hex1: string, hex2: string, weight1: number): string {
  const c1 = hexToRgb(hex1);
  const c2 = hexToRgb(hex2);
  const w2 = 1 - weight1;
  return rgbToHex(
    c1.r * weight1 + c2.r * w2,
    c1.g * weight1 + c2.g * w2,
    c1.b * weight1 + c2.b * w2
  );
}

function getRelativeLuminance(hex: string): number {
  const { r, g, b } = hexToRgb(hex);
  const [rs, gs, bs] = [r / 255, g / 255, b / 255].map(c =>
    c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
  );
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

export async function extractDominantColorFromImage(imageUrl: string, fallbackHex: string): Promise<string> {
  return new Promise(resolve => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const size = 32;
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(fallbackHex);
          return;
        }
        ctx.drawImage(img, 0, 0, size, size);
        const data = ctx.getImageData(0, 0, size, size).data;

        let bestR = 0;
        let bestG = 0;
        let bestB = 0;
        let maxWeight = -1;

        for (let i = 0; i < data.length; i += 16) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const max = Math.max(r, g, b);
          const min = Math.min(r, g, b);
          const chroma = max - min;
          const luma = 0.299 * r + 0.587 * g + 0.114 * b;
          // Prefer vibrant, visible mid-to-bright tones for the dynamic accent
          if (luma > 35 && luma < 235) {
            const weight = chroma * 1.6 + (120 - Math.abs(luma - 140));
            if (weight > maxWeight) {
              maxWeight = weight;
              bestR = r;
              bestG = g;
              bestB = b;
            }
          }
        }

        if (maxWeight <= 15) {
          resolve(fallbackHex);
          return;
        }
        resolve(rgbToHex(bestR, bestG, bestB));
      } catch {
        resolve(fallbackHex);
      }
    };
    img.onerror = () => resolve(fallbackHex);
    img.src = imageUrl;
  });
}

export function buildThemePalette(
  config: ThemeConfig,
  trackAccentHex: string
): ComputedPalette {
  const effectiveAccent = config.useCustomAccent
    ? config.customAccentHex
    : config.adaptToCoverArt || config.baseId === 'dynamic-cover'
      ? trackAccentHex
      : STATIC_THEMES[config.baseId].defaultAccent;

  const { r, g, b } = hexToRgb(effectiveAccent);
  const accentSoft = `rgba(${r}, ${g}, ${b}, 0.15)`;
  const accentLum = getRelativeLuminance(effectiveAccent);
  const accentFg = accentLum > 0.36 ? '#090d16' : '#ffffff';

  if (config.baseId === 'editorial-paper' && !config.adaptToCoverArt) {
    const base = STATIC_THEMES['editorial-paper'];
    return {
      bg: base.bg,
      surface: base.surface,
      surfaceHover: base.surfaceHover,
      border: base.border,
      text: base.text,
      muted: base.muted,
      accent: effectiveAccent,
      accentSoft,
      accentFg,
      isLight: true
    };
  }

  // Dark / Dynamic Cover Art surface tinting (<5% saturation discipline)
  const baseDarkBg = '#0a0e17';
  const baseDarkSurface = '#121826';

  if (config.appBgMode === 'color' && config.bgColorHex) {
    const bgLum = getRelativeLuminance(config.bgColorHex);
    const isLightBg = bgLum > 0.42;
    const tintedSurface = mixColors(effectiveAccent, config.bgColorHex, 0.14);
    const tintedHover = mixColors(effectiveAccent, config.bgColorHex, 0.2);
    return {
      bg: config.bgColorHex,
      surface: tintedSurface,
      surfaceHover: tintedHover,
      border: isLightBg ? 'rgba(15, 23, 42, 0.14)' : `rgba(${r}, ${g}, ${b}, 0.22)`,
      text: isLightBg ? '#0f172a' : '#ffffff',
      muted: isLightBg ? '#334155' : '#cbd5e1',
      accent: effectiveAccent,
      accentSoft,
      accentFg,
      isLight: isLightBg
    };
  }

  if (config.adaptToCoverArt || config.baseId === 'dynamic-cover') {
    const tintedBg = mixColors(effectiveAccent, baseDarkBg, 0.08);
    const tintedSurface = mixColors(effectiveAccent, baseDarkSurface, 0.11);
    const tintedHover = mixColors(effectiveAccent, '#1e2738', 0.15);
    return {
      bg: tintedBg,
      surface: tintedSurface,
      surfaceHover: tintedHover,
      border: `rgba(${r}, ${g}, ${b}, 0.18)`,
      text: '#ffffff',
      muted: '#cbd5e1',
      accent: effectiveAccent,
      accentSoft,
      accentFg,
      isLight: false
    };
  }

  const preset = STATIC_THEMES[config.baseId];
  return {
    bg: preset.bg,
    surface: preset.surface,
    surfaceHover: preset.surfaceHover,
    border: preset.border,
    text: preset.text,
    muted: preset.muted,
    accent: effectiveAccent,
    accentSoft,
    accentFg,
    isLight: preset.isLight
  };
}

export function applyPaletteToDocument(palette: ComputedPalette): void {
  const root = document.documentElement;
  root.style.setProperty('--theme-bg', palette.bg);
  root.style.setProperty('--theme-surface', palette.surface);
  root.style.setProperty('--theme-surface-hover', palette.surfaceHover);
  root.style.setProperty('--theme-border', palette.border);
  root.style.setProperty('--theme-text', palette.text);
  root.style.setProperty('--theme-muted', palette.muted);
  root.style.setProperty('--theme-accent', palette.accent);
  root.style.setProperty('--theme-accent-soft', palette.accentSoft);
  root.style.setProperty('--theme-accent-fg', palette.accentFg);
}
