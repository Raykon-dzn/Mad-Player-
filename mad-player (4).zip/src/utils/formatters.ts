import { SmartPlaylist, SmartRule, Track } from '../types/music';

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function formatDaysAgo(isoDate: string): string {
  const added = new Date(isoDate).getTime();
  if (Number.isNaN(added)) return 'Hace 1 Día';
  const diffDays = Math.max(0, Math.floor((Date.now() - added) / (1000 * 60 * 60 * 24)));
  if (diffDays === 0) return 'Hoy';
  if (diffDays === 1) return 'Hace 1 Día';
  return `Hace ${diffDays} Días`;
}

export function evaluateSmartPlaylist(smart: SmartPlaylist, allTracks: Track[]): Track[] {
  const visibleTracks = allTracks.filter(t => !t.isHidden);
  const filtered = visibleTracks.filter(track => {
    if (smart.rules.length === 0) return true;

    const evalRule = (rule: SmartRule): boolean => {
      const trackVal = track[rule.field];
      if (rule.field === 'isFavorite') {
        return Boolean(trackVal) === Boolean(rule.value);
      }
      if (typeof trackVal === 'number') {
        const target = Number(rule.value);
        if (rule.operator === 'equals') return trackVal === target;
        if (rule.operator === 'gte') return trackVal >= target;
        if (rule.operator === 'lte') return trackVal <= target;
        return false;
      }
      if (typeof trackVal === 'string') {
        const targetStr = String(rule.value).toLowerCase();
        const actualStr = trackVal.toLowerCase();
        if (rule.operator === 'equals') return actualStr === targetStr;
        if (rule.operator === 'contains') return actualStr.includes(targetStr);
      }
      return false;
    };

    return smart.matchMode === 'all'
      ? smart.rules.every(evalRule)
      : smart.rules.some(evalRule);
  });

  const sorted = [...filtered].sort((a, b) => {
    const dir = smart.sortOrder === 'asc' ? 1 : -1;
    if (smart.sortBy === 'title') return a.title.localeCompare(b.title) * dir;
    if (smart.sortBy === 'addedAt') return a.addedAt.localeCompare(b.addedAt) * dir;
    return ((a[smart.sortBy] as number) - (b[smart.sortBy] as number)) * dir;
  });

  return smart.limit ? sorted.slice(0, smart.limit) : sorted;
}

export function safeCopyToClipboard(text: string) {
  const fallbackCopy = () => {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    } catch {
      // Ignore fallback failure
    }
  };

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).catch(() => {
      fallbackCopy();
    });
  } else {
    fallbackCopy();
  }
}
