import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Track,
  Playlist,
  SmartPlaylist,
  SmartRule
} from '../types/music';
import {
  INITIAL_TRACKS,
  INITIAL_PLAYLISTS,
  INITIAL_SMART_PLAYLISTS
} from '../data/initialLibrary';
import { extractDominantColorFromImage } from '../utils/colorExtractor';
import { evaluateSmartPlaylist } from '../utils/formatters';
import {
  loadImportedTracksFromDb,
  updateTrackMetaInDb,
  deleteTrackFromDb,
  loadPlaylistsFromDb,
  savePlaylistsToDb,
  loadSmartPlaylistsFromDb,
  saveSmartPlaylistsToDb,
  migrateLocalStorageToIndexedDb,
  requestPersistentStorage,
  revokeObjectUrlSafe
} from '../services/mediaStorageDb';
import {
  buildEntriesFromFileList,
  FileWithFolder,
  ImportProgressUpdate,
  isCapacitorNative,
  pickDirectoryAndCollectAudioFiles,
  processImportedAudioFiles,
  scanCapacitorDeviceLibrary,
  supportsDirectoryPicker
} from '../services/folderScanner';
import { HiddenFolderItem } from './useSettings';

export interface ImportProgressState extends ImportProgressUpdate {
  active: boolean;
}

interface UseLibraryOptions {
  activeAccentColor: string;
  showToast: (msg: string) => void;
  onTracksImported?: (newTracks: Track[]) => void;
  onTracksRestored?: (restoredTracks: Track[]) => void;
  onTrackDeleted?: (deletedId: string, remainingTracks: Track[]) => void;
}

export function useLibrary({
  activeAccentColor,
  showToast,
  onTracksImported,
  onTracksRestored,
  onTrackDeleted
}: UseLibraryOptions) {
  const [tracks, setTracks] = useState<Track[]>(INITIAL_TRACKS);
  const [isScanningFolder, setIsScanningFolder] = useState<boolean>(false);
  const [importProgress, setImportProgress] = useState<ImportProgressState>({
    active: false,
    processed: 0,
    total: 0,
    currentFileName: '',
    importedCount: 0,
    duplicatesSkipped: 0
  });
  const cancelImportRef = useRef<boolean>(false);
  const isLibraryHydratedRef = useRef<boolean>(false);

  const [playlists, setPlaylists] = useState<Playlist[]>(INITIAL_PLAYLISTS);
  const [smartPlaylists, setSmartPlaylists] = useState<SmartPlaylist[]>(INITIAL_SMART_PLAYLISTS);

  // Hidden Files Filters & Folders
  const [minDurationFilterSeconds, setMinDurationFilterSeconds] = useState<number>(5);
  const [minSizeFilterKB, setMinSizeFilterKB] = useState<number>(5);
  const [hiddenFolders, setHiddenFolders] = useState<HiddenFolderItem[]>([
    { id: 'hf-1', name: 'Alarms', path: '/storage/emulated/0/Alarms' },
    { id: 'hf-2', name: 'Notifications', path: '/storage/emulated/0/Notifications' },
    { id: 'hf-3', name: 'Ringtones', path: '/storage/emulated/0/Ringtones' },
    { id: 'hf-4', name: 'voz-del-narrador', path: '/storage/emulated/0/Music/voz-del-narrador' }
  ]);
  const [lastAddedInterval, setLastAddedInterval] = useState<string>('Por siempre');
  const [duplicatePlaylistPolicy, setDuplicatePlaylistPolicy] = useState<'ask' | 'allow' | 'skip'>(
    'ask'
  );

  // Library Filter, Sort & Batch Selection
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [onlyFavorites, setOnlyFavorites] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'title' | 'artist' | 'bpm' | 'playCount' | 'duration'>(
    'title'
  );
  const [selectedTrackIds, setSelectedTrackIds] = useState<string[]>([]);

  // Playlist Management UI State
  const [activePlaylistId, setActivePlaylistId] = useState<string>(INITIAL_PLAYLISTS[0]?.id || '');
  const [newPlaylistName, setNewPlaylistName] = useState<string>('');
  const [newPlaylistDesc, setNewPlaylistDesc] = useState<string>('');
  const [showCreatePlaylistForm, setShowCreatePlaylistForm] = useState<boolean>(false);
  const [mergeTargetId, setMergeTargetId] = useState<string>('');

  // Smart Playlist Builder State
  const [activeSmartId, setActiveSmartId] = useState<string>(INITIAL_SMART_PLAYLISTS[0]?.id || '');
  const [showSmartBuilder, setShowSmartBuilder] = useState<boolean>(false);
  const [smartName, setSmartName] = useState<string>('');
  const [smartDesc, setSmartDesc] = useState<string>('');
  const [smartMatchMode, setSmartMatchMode] = useState<'all' | 'any'>('all');
  const [smartRules, setSmartRules] = useState<SmartRule[]>([
    { id: 'rule-init', field: 'bpm', operator: 'gte', value: 110 }
  ]);

  // Tag Editor Modal State
  const [editingTrack, setEditingTrack] = useState<Track | null>(null);

  // Hidden DOM file & folder inputs
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const coverInputRef = useRef<HTMLInputElement | null>(null);

  // Migrate legacy localStorage data once, request persistent storage, then load tracks, playlists, and smartPlaylists from IndexedDB
  useEffect(() => {
    let active = true;
    (async () => {
      await requestPersistentStorage();
      await migrateLocalStorageToIndexedDb();
      const [dbTracks, dbPlaylists, dbSmartPlaylists] = await Promise.all([
        loadImportedTracksFromDb(),
        loadPlaylistsFromDb(),
        loadSmartPlaylistsFromDb()
      ]);

      if (!active) {
        dbTracks.forEach(t => {
          revokeObjectUrlSafe(t.audioUrl);
          revokeObjectUrlSafe(t.coverUrl);
        });
        return;
      }

      if (dbPlaylists && Array.isArray(dbPlaylists)) {
        const validPlaylists = dbPlaylists.filter((p: Playlist) => p && p.id !== 'pl-studio-night');
        setPlaylists(validPlaylists);
        if (validPlaylists[0]?.id) {
          setActivePlaylistId(validPlaylists[0].id);
        }
      }

      if (dbSmartPlaylists && Array.isArray(dbSmartPlaylists) && dbSmartPlaylists.length > 0) {
        setSmartPlaylists(dbSmartPlaylists);
        if (dbSmartPlaylists[0]?.id) {
          setActiveSmartId(dbSmartPlaylists[0].id);
        }
      }

      isLibraryHydratedRef.current = true;

      if (dbTracks.length > 0) {
        setTracks(prev => {
          prev.forEach(old => {
            if (!dbTracks.some(n => n.audioUrl === old.audioUrl)) {
              revokeObjectUrlSafe(old.audioUrl);
            }
            if (!dbTracks.some(n => n.coverUrl === old.coverUrl)) {
              revokeObjectUrlSafe(old.coverUrl);
            }
          });
          return dbTracks;
        });
        if (onTracksRestored) {
          onTracksRestored(dbTracks);
        } else {
          onTracksImported?.(dbTracks);
        }
        return;
      }

      // If library is empty and running inside Capacitor APK, automatically scan device folders
      if (isCapacitorNative()) {
        const capEntries = await scanCapacitorDeviceLibrary();
        if (active && capEntries && capEntries.length > 0) {
          await ingestFileEntries(capEntries);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!isLibraryHydratedRef.current) return;
    savePlaylistsToDb(playlists);
  }, [playlists]);

  useEffect(() => {
    if (!isLibraryHydratedRef.current) return;
    saveSmartPlaylistsToDb(smartPlaylists);
  }, [smartPlaylists]);

  const visibleTracks = useMemo(
    () =>
      tracks.filter(
        t =>
          !t.isHidden &&
          t.duration >= minDurationFilterSeconds &&
          (t.fileSizeKB === undefined || t.fileSizeKB >= minSizeFilterKB)
      ),
    [tracks, minDurationFilterSeconds, minSizeFilterKB]
  );

  const hiddenTracks = useMemo(
    () =>
      tracks.filter(
        t =>
          t.isHidden ||
          t.duration < minDurationFilterSeconds ||
          (t.fileSizeKB !== undefined && t.fileSizeKB < minSizeFilterKB)
      ),
    [tracks, minDurationFilterSeconds, minSizeFilterKB]
  );

  const filteredTracks = useMemo(() => {
    return visibleTracks
      .filter(t => {
        const trackFolder =
          t.folderPath ||
          (t.audioUrl
            ? '/storage/emulated/0/Music/Local'
            : '/storage/emulated/0/MadPlayer/Muestreo');
        const isInHiddenFolder = hiddenFolders.some(
          hf =>
            trackFolder.toLowerCase().includes(hf.path.toLowerCase()) ||
            t.album.toLowerCase().includes(hf.name.toLowerCase())
        );
        if (isInHiddenFolder) return false;
        if (onlyFavorites && !t.isFavorite) return false;
        if (selectedGenre !== 'all' && t.genre !== selectedGenre) return false;
        if (searchQuery.trim() !== '') {
          const q = searchQuery.toLowerCase();
          return (
            t.title.toLowerCase().includes(q) ||
            t.artist.toLowerCase().includes(q) ||
            t.album.toLowerCase().includes(q) ||
            t.genre.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'title') return a.title.localeCompare(b.title);
        if (sortBy === 'artist') return a.artist.localeCompare(b.artist);
        if (sortBy === 'bpm') return b.bpm - a.bpm;
        if (sortBy === 'duration') return b.duration - a.duration;
        return b.playCount - a.playCount;
      });
  }, [visibleTracks, hiddenFolders, onlyFavorites, selectedGenre, searchQuery, sortBy]);

  const recentlyPlayedTracks = useMemo(() => {
    return [...visibleTracks].sort(
      (a, b) => (b.lastPlayedAt || 0) - (a.lastPlayedAt || 0) || b.playCount - a.playCount
    );
  }, [visibleTracks]);

  const mostPlayedTracks = useMemo(() => {
    return [...visibleTracks].sort((a, b) => b.playCount - a.playCount);
  }, [visibleTracks]);

  const favoriteTracks = useMemo(() => {
    return visibleTracks.filter(t => t.isFavorite);
  }, [visibleTracks]);

  const recentlyAddedTracks = useMemo(() => {
    const nowMs = Date.now();
    const maxDaysMap: Record<string, number> = {
      'Últimos 7 días': 7,
      'Últimos 30 días': 30,
      'Últimos 3 meses': 90,
      'Últimos 6 meses': 180,
      'Último año': 365
    };
    const maxDays = maxDaysMap[lastAddedInterval];
    const pool = maxDays
      ? visibleTracks.filter(t => {
          const addedMs = new Date(t.addedAt).getTime();
          if (Number.isNaN(addedMs)) return true;
          const diffDays = (nowMs - addedMs) / (1000 * 60 * 60 * 24);
          return diffDays <= maxDays;
        })
      : visibleTracks;
    const finalPool = pool.length > 0 ? pool : visibleTracks;
    return [...finalPool].sort((a, b) => b.addedAt.localeCompare(a.addedAt));
  }, [visibleTracks, lastAddedInterval]);

  const groupedFolders = useMemo(() => {
    const map = new Map<string, Track[]>();
    visibleTracks.forEach(t => {
      const folderName =
        t.folderPath ||
        (t.audioUrl
          ? '/storage/emulated/0/Music/Local'
          : '/storage/emulated/0/MadPlayer/Muestreo');
      map.set(folderName, [...(map.get(folderName) || []), t]);
    });
    return Array.from(map.entries());
  }, [visibleTracks]);

  const groupedAlbums = useMemo(() => {
    const map = new Map<string, Track[]>();
    visibleTracks.forEach(t => {
      map.set(t.album, [...(map.get(t.album) || []), t]);
    });
    return Array.from(map.entries());
  }, [visibleTracks]);

  const groupedArtists = useMemo(() => {
    const map = new Map<string, Track[]>();
    visibleTracks.forEach(t => {
      map.set(t.artist, [...(map.get(t.artist) || []), t]);
    });
    return Array.from(map.entries());
  }, [visibleTracks]);

  const groupedGenres = useMemo(() => {
    const map = new Map<string, Track[]>();
    visibleTracks.forEach(t => {
      map.set(t.genre, [...(map.get(t.genre) || []), t]);
    });
    return Array.from(map.entries());
  }, [visibleTracks]);

  const handleCancelImport = () => {
    cancelImportRef.current = true;
  };

  const ingestFileEntries = async (entries: FileWithFolder[]) => {
    if (entries.length === 0) {
      showToast('No se encontraron archivos de audio compatibles en la selección');
      return;
    }
    cancelImportRef.current = false;
    setIsScanningFolder(true);
    setImportProgress({
      active: true,
      processed: 0,
      total: entries.length,
      currentFileName: entries[0]?.file.name || '',
      importedCount: 0,
      duplicatesSkipped: 0
    });

    try {
      const {
        tracks: importedTracks,
        coversRecognized,
        foldersCount,
        duplicatesSkipped,
        cancelled
      } = await processImportedAudioFiles(entries, {
        existingTracks: tracks,
        onDurationResolved: (trackId, durationSec) => {
          setTracks(prev =>
            prev.map(t => (t.id === trackId ? { ...t, duration: durationSec } : t))
          );
        },
        onProgress: update => {
          setImportProgress({
            active: true,
            ...update
          });
        },
        shouldCancel: () => cancelImportRef.current
      });

      if (importedTracks.length > 0) {
        setTracks(prev => [...importedTracks, ...prev]);
        onTracksImported?.(importedTracks);
      }

      if (cancelled) {
        showToast(
          importedTracks.length > 0
            ? `Importación cancelada · ${importedTracks.length} pista(s) guardada(s)`
            : 'Importación cancelada'
        );
        return;
      }

      if (importedTracks.length === 0) {
        if (duplicatesSkipped > 0) {
          showToast(
            `${duplicatesSkipped} canción(es) duplicada(s) omitida(s) · 0 nuevas agregadas`
          );
        } else {
          showToast('No se encontraron pistas mp3/m4a/flac/wav/ogg válidas');
        }
        return;
      }

      const dupSuffix =
        duplicatesSkipped > 0 ? ` · ${duplicatesSkipped} duplicada(s) omitida(s)` : '';

      if (foldersCount > 1) {
        showToast(
          `${importedTracks.length} pista(s) en ${foldersCount} carpetas · ${coversRecognized} portada(s)${dupSuffix}`
        );
      } else if (coversRecognized > 0) {
        showToast(
          `${importedTracks.length} canción(es) agregada(s) · ${coversRecognized} portada(s)${dupSuffix}`
        );
      } else {
        showToast(`${importedTracks.length} canción(es) agregada(s) a tu biblioteca${dupSuffix}`);
      }
    } finally {
      setIsScanningFolder(false);
      setImportProgress(prev => ({ ...prev, active: false }));
    }
  };

  const handleImportAudioFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const entries = buildEntriesFromFileList(fileList, false);
    e.target.value = '';
    await ingestFileEntries(entries);
  };

  const handleImportFolderFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const entries = buildEntriesFromFileList(fileList, true);
    e.target.value = '';
    await ingestFileEntries(entries);
  };

  /**
   * Triggers folder import:
   * - On web: attempts File System Access API (showDirectoryPicker) to retain FileSystemFileHandle
   *   so files can be reopened after reload without storing audioBlob in IndexedDB; falls back to
   *   <input type="file" webkitdirectory multiple /> when blocked or unsupported.
   * - On Capacitor native APK: scans device folders or falls back to folder input.
   */
  const handleScanFolderOrLibrary = () => {
    if (isCapacitorNative()) {
      (async () => {
        setIsScanningFolder(true);
        const capEntries = await scanCapacitorDeviceLibrary();
        setIsScanningFolder(false);
        if (capEntries && capEntries.length > 0) {
          await ingestFileEntries(capEntries);
        } else {
          folderInputRef.current?.click();
        }
      })();
      return;
    }

    if (supportsDirectoryPicker()) {
      (async () => {
        const picked = await pickDirectoryAndCollectAudioFiles();
        if (picked === null) {
          // Blocked by cross-origin iframe or unsupported -> fall back to webkitdirectory input
          folderInputRef.current?.click();
          return;
        }
        if (picked.length > 0) {
          await ingestFileEntries(picked);
        }
      })();
      return;
    }

    folderInputRef.current?.click();
  };

  const handleCustomCoverChange = async (
    e: React.ChangeEvent<HTMLInputElement>,
    currentTrackId?: string
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    const targetId = editingTrack ? editingTrack.id : currentTrackId;
    if (!targetId) return;

    const coverObjUrl = URL.createObjectURL(file);
    const extractedHex = await extractDominantColorFromImage(coverObjUrl, '#1cc8ee');

    const existingTrack = tracks.find(t => t.id === targetId);
    if (
      existingTrack?.coverUrl &&
      existingTrack.coverUrl.startsWith('blob:') &&
      existingTrack.coverUrl !== coverObjUrl &&
      !tracks.some(t => t.id !== targetId && t.coverUrl === existingTrack.coverUrl)
    ) {
      URL.revokeObjectURL(existingTrack.coverUrl);
    }

    if (
      editingTrack &&
      editingTrack.id === targetId &&
      editingTrack.coverUrl &&
      editingTrack.coverUrl.startsWith('blob:') &&
      editingTrack.coverUrl !== existingTrack?.coverUrl &&
      editingTrack.coverUrl !== coverObjUrl
    ) {
      URL.revokeObjectURL(editingTrack.coverUrl);
    }

    if (existingTrack) {
      const updatedTrack: Track = {
        ...existingTrack,
        coverUrl: coverObjUrl,
        dominantColor: extractedHex
      };
      await updateTrackMetaInDb(updatedTrack, file);
    }

    setTracks(prev =>
      prev.map(t =>
        t.id === targetId
          ? { ...t, coverUrl: coverObjUrl, dominantColor: extractedHex }
          : t
      )
    );

    if (editingTrack && editingTrack.id === targetId) {
      setEditingTrack(prev =>
        prev ? { ...prev, coverUrl: coverObjUrl, dominantColor: extractedHex } : null
      );
    }

    showToast('Portada de la canción actualizada');
  };

  const toggleFavorite = (trackId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setTracks(prev =>
      prev.map(t => {
        if (t.id !== trackId) return t;
        const updated = { ...t, isFavorite: !t.isFavorite };
        updateTrackMetaInDb(updated);
        return updated;
      })
    );
  };

  const handleHideTrack = (trackId: string) => {
    setTracks(prev =>
      prev.map(t => {
        if (t.id !== trackId) return t;
        const updated = { ...t, isHidden: true };
        updateTrackMetaInDb(updated);
        return updated;
      })
    );
    showToast('Pista ocultada (restáurala en Ajustes > Hidden Files)');
  };

  const handleRestoreHiddenTrack = (trackId: string) => {
    setTracks(prev =>
      prev.map(t => {
        if (t.id !== trackId) return t;
        const updated = { ...t, isHidden: false };
        updateTrackMetaInDb(updated);
        return updated;
      })
    );
    showToast('Pista restaurada a tu biblioteca');
  };

  const handleDeleteTrack = (trackId: string) => {
    const deletedTrack = tracks.find(t => t.id === trackId);
    const remaining = tracks.filter(t => t.id !== trackId);

    if (deletedTrack) {
      if (
        deletedTrack.audioUrl &&
        deletedTrack.audioUrl.startsWith('blob:') &&
        !remaining.some(t => t.audioUrl === deletedTrack.audioUrl)
      ) {
        URL.revokeObjectURL(deletedTrack.audioUrl);
      }
      if (
        deletedTrack.coverUrl &&
        deletedTrack.coverUrl.startsWith('blob:') &&
        !remaining.some(t => t.coverUrl === deletedTrack.coverUrl)
      ) {
        URL.revokeObjectURL(deletedTrack.coverUrl);
      }
    }

    deleteTrackFromDb(trackId);
    setTracks(remaining);
    onTrackDeleted?.(trackId, remaining);
    showToast('Pista eliminada de la biblioteca');
  };

  // Multi-select Batch Handlers
  const handleBatchAddToPlaylist = (playlistId: string) => {
    if (selectedTrackIds.length === 0) return;
    setPlaylists(prev =>
      prev.map(pl => {
        if (pl.id !== playlistId) return pl;
        const merged = Array.from(new Set([...pl.trackIds, ...selectedTrackIds]));
        return { ...pl, trackIds: merged, updatedAt: new Date().toISOString().slice(0, 10) };
      })
    );
    const targetPl = playlists.find(p => p.id === playlistId);
    showToast(`${selectedTrackIds.length} pistas añadidas a "${targetPl?.name}"`);
    setSelectedTrackIds([]);
  };

  const handleAddSingleTrackToPlaylist = (playlistId: string, trackId: string) => {
    const targetPl = playlists.find(p => p.id === playlistId);
    if (targetPl && targetPl.trackIds.includes(trackId)) {
      if (duplicatePlaylistPolicy === 'skip') {
        showToast(`Canción duplicada omitida en "${targetPl.name}"`);
        return;
      }
      if (duplicatePlaylistPolicy === 'ask') {
        showToast(`"${targetPl.name}" ya contiene esta canción`);
        return;
      }
    }
    setPlaylists(prev =>
      prev.map(pl => {
        if (pl.id !== playlistId) return pl;
        const merged =
          duplicatePlaylistPolicy === 'allow'
            ? [...pl.trackIds, trackId]
            : Array.from(new Set([...pl.trackIds, trackId]));
        return { ...pl, trackIds: merged, updatedAt: new Date().toISOString().slice(0, 10) };
      })
    );
    showToast(`Pista añadida a "${targetPl?.name}"`);
  };

  // Custom Playlist Actions
  const activePlaylist = useMemo(
    () => playlists.find(p => p.id === activePlaylistId) || playlists[0],
    [playlists, activePlaylistId]
  );

  const activePlaylistTracks = useMemo(() => {
    if (!activePlaylist) return [];
    return activePlaylist.trackIds
      .map(id => visibleTracks.find(t => t.id === id))
      .filter((t): t is Track => Boolean(t));
  }, [activePlaylist, visibleTracks]);

  const handleCreatePlaylist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      name: newPlaylistName.trim(),
      description: newPlaylistDesc.trim() || 'Lista personalizada creada en Mad Player.',
      trackIds:
        selectedTrackIds.length > 0
          ? [...selectedTrackIds]
          : visibleTracks[0]?.id
            ? [visibleTracks[0].id]
            : [],
      createdAt: new Date().toISOString().slice(0, 10),
      updatedAt: new Date().toISOString().slice(0, 10),
      customAccent: activeAccentColor
    };
    setPlaylists(prev => [newPl, ...prev]);
    setActivePlaylistId(newPl.id);
    setNewPlaylistName('');
    setNewPlaylistDesc('');
    setShowCreatePlaylistForm(false);
    setSelectedTrackIds([]);
    showToast(`Lista "${newPl.name}" creada`);
  };

  const handleMovePlaylistTrack = (index: number, direction: -1 | 1) => {
    if (!activePlaylist) return;
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= activePlaylist.trackIds.length) return;
    const updatedIds = [...activePlaylist.trackIds];
    const [moved] = updatedIds.splice(index, 1);
    updatedIds.splice(newIndex, 0, moved);

    setPlaylists(prev =>
      prev.map(p =>
        p.id === activePlaylist.id
          ? { ...p, trackIds: updatedIds, updatedAt: new Date().toISOString().slice(0, 10) }
          : p
      )
    );
  };

  const handleRemoveFromPlaylist = (trackId: string) => {
    if (!activePlaylist) return;
    setPlaylists(prev =>
      prev.map(p =>
        p.id === activePlaylist.id
          ? { ...p, trackIds: p.trackIds.filter(id => id !== trackId) }
          : p
      )
    );
    showToast('Pista eliminada de la lista');
  };

  const handleDuplicatePlaylist = () => {
    if (!activePlaylist) return;
    const copy: Playlist = {
      ...activePlaylist,
      id: `pl-${Date.now()}`,
      name: `${activePlaylist.name} (Copia)`,
      createdAt: new Date().toISOString().slice(0, 10),
      updatedAt: new Date().toISOString().slice(0, 10)
    };
    setPlaylists(prev => [copy, ...prev]);
    setActivePlaylistId(copy.id);
    showToast(`Lista duplicada como "${copy.name}"`);
  };

  const handleMergePlaylists = () => {
    if (!activePlaylist || !mergeTargetId || mergeTargetId === activePlaylist.id) return;
    const sourcePl = playlists.find(p => p.id === mergeTargetId);
    if (!sourcePl) return;
    const combinedTrackIds = Array.from(
      new Set([...activePlaylist.trackIds, ...sourcePl.trackIds])
    );
    setPlaylists(prev =>
      prev.map(p =>
        p.id === activePlaylist.id
          ? {
              ...p,
              trackIds: combinedTrackIds,
              updatedAt: new Date().toISOString().slice(0, 10)
            }
          : p
      )
    );
    setMergeTargetId('');
    showToast(`Fusionada con "${sourcePl.name}" (${combinedTrackIds.length} pistas en total)`);
  };

  const handleExportPlaylistJson = () => {
    if (!activePlaylist) return;
    const payload = {
      playlist: activePlaylist,
      tracks: activePlaylistTracks.map(t => ({
        title: t.title,
        artist: t.artist,
        album: t.album,
        bpm: t.bpm,
        duration: t.duration
      }))
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activePlaylist.name.toLowerCase().replace(/\s+/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Respaldo exportado en formato JSON');
  };

  // Smart Playlist Actions
  const activeSmartPlaylist = useMemo(
    () => smartPlaylists.find(s => s.id === activeSmartId) || smartPlaylists[0],
    [smartPlaylists, activeSmartId]
  );

  const activeSmartTracks = useMemo(() => {
    if (!activeSmartPlaylist) return [];
    return evaluateSmartPlaylist(activeSmartPlaylist, tracks);
  }, [activeSmartPlaylist, tracks]);

  const handleCreateSmartPlaylist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!smartName.trim() || smartRules.length === 0) return;
    const created: SmartPlaylist = {
      id: `smart-${Date.now()}`,
      name: smartName.trim(),
      description: smartDesc.trim() || 'Lista inteligente dinámica evaluada en tiempo real.',
      matchMode: smartMatchMode,
      rules: smartRules,
      sortBy: 'playCount',
      sortOrder: 'desc'
    };
    setSmartPlaylists(prev => [created, ...prev]);
    setActiveSmartId(created.id);
    setSmartName('');
    setSmartDesc('');
    setShowSmartBuilder(false);
    showToast(`Lista inteligente "${created.name}" activada`);
  };

  const handleSaveTrackTags = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTrack) return;
    const prevTrack = tracks.find(t => t.id === editingTrack.id);
    if (
      prevTrack?.coverUrl &&
      prevTrack.coverUrl.startsWith('blob:') &&
      prevTrack.coverUrl !== editingTrack.coverUrl &&
      !tracks.some(t => t.id !== editingTrack.id && t.coverUrl === prevTrack.coverUrl)
    ) {
      URL.revokeObjectURL(prevTrack.coverUrl);
    }
    updateTrackMetaInDb(editingTrack, editingTrack.coverUrl === '' ? null : undefined);
    setTracks(prev => prev.map(t => (t.id === editingTrack.id ? editingTrack : t)));
    setEditingTrack(null);
    showToast('Metadatos y portada de la pista actualizados');
  };

  return {
    tracks,
    setTracks,
    visibleTracks,
    hiddenTracks,
    filteredTracks,
    recentlyPlayedTracks,
    mostPlayedTracks,
    favoriteTracks,
    recentlyAddedTracks,
    groupedFolders,
    groupedAlbums,
    groupedArtists,
    groupedGenres,
    playlists,
    setPlaylists,
    smartPlaylists,
    setSmartPlaylists,
    minDurationFilterSeconds,
    setMinDurationFilterSeconds,
    minSizeFilterKB,
    setMinSizeFilterKB,
    hiddenFolders,
    setHiddenFolders,
    lastAddedInterval,
    setLastAddedInterval,
    duplicatePlaylistPolicy,
    setDuplicatePlaylistPolicy,
    searchQuery,
    setSearchQuery,
    selectedGenre,
    setSelectedGenre,
    onlyFavorites,
    setOnlyFavorites,
    sortBy,
    setSortBy,
    selectedTrackIds,
    setSelectedTrackIds,
    activePlaylistId,
    setActivePlaylistId,
    activePlaylist,
    activePlaylistTracks,
    newPlaylistName,
    setNewPlaylistName,
    newPlaylistDesc,
    setNewPlaylistDesc,
    showCreatePlaylistForm,
    setShowCreatePlaylistForm,
    mergeTargetId,
    setMergeTargetId,
    activeSmartId,
    setActiveSmartId,
    activeSmartPlaylist,
    activeSmartTracks,
    showSmartBuilder,
    setShowSmartBuilder,
    smartName,
    setSmartName,
    smartDesc,
    setSmartDesc,
    smartMatchMode,
    setSmartMatchMode,
    smartRules,
    setSmartRules,
    editingTrack,
    setEditingTrack,
    isScanningFolder,
    importProgress,
    handleCancelImport,
    fileInputRef,
    folderInputRef,
    coverInputRef,
    handleImportAudioFiles,
    handleImportFolderFiles,
    handleScanFolderOrLibrary,
    handleCustomCoverChange,
    toggleFavorite,
    handleHideTrack,
    handleRestoreHiddenTrack,
    handleDeleteTrack,
    handleBatchAddToPlaylist,
    handleAddSingleTrackToPlaylist,
    handleCreatePlaylist,
    handleMovePlaylistTrack,
    handleRemoveFromPlaylist,
    handleDuplicatePlaylist,
    handleMergePlaylists,
    handleExportPlaylistJson,
    handleCreateSmartPlaylist,
    handleSaveTrackTags
  };
}
