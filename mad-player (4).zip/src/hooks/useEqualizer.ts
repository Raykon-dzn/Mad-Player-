import { useState, useEffect } from 'react';
import { EqualizerState } from '../types/music';
import { DEFAULT_EQ_BANDS } from '../data/initialLibrary';
import { audioEngine } from '../services/audioEngine';

export function useEqualizer() {
  // Speed & Pitch both use 0.5 to 1.5 scale centered at 1.0 = Normal
  const [eqState, setEqState] = useState<EqualizerState>({
    enabled: true,
    presetName: 'Estudio Cálido',
    bands: DEFAULT_EQ_BANDS,
    bassBoost: 2.5,
    stereoWidth: 0,
    playbackRate: 1.0,
    pitchRate: 1.0
  });

  useEffect(() => {
    audioEngine.applyEqualizer(eqState);
  }, [eqState]);

  const handleInstantSpeedAndPitchChange = (rate: number, pitchRate: number) => {
    const cleanRate = Number(Math.max(0.5, Math.min(1.5, rate)).toFixed(1));
    const cleanPitch = Number(Math.max(0.5, Math.min(1.5, pitchRate)).toFixed(1));
    audioEngine.setSpeedAndPitch(cleanRate, cleanPitch);
    setEqState(prev => ({
      ...prev,
      playbackRate: cleanRate,
      pitchRate: cleanPitch
    }));
  };

  return {
    eqState,
    setEqState,
    handleInstantSpeedAndPitchChange
  };
}
