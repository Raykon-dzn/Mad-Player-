import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { EqualizerState, Track } from '../types/music';
import { INITIAL_TRACKS } from '../data/initialLibrary';
import { audioEngine } from '../services/audioEngine';
import {
  cloneTrackInDb,
  reopenTrackAudioFromHandle,
  updateTrackMetaInDb
} from '../services/mediaStorageDb';
import { formatDuration, safeCopyToClipboard } from '../utils/formatters';
import { UseSettingsReturn } from './useSettings';

interface UsePlayerOptions {
  tracks: Track[];
  visibleTracks: Track[];
  setTracks: React.Dispatch<React.SetStateAction<Track[]>>;
  eqState: EqualizerState;
  setEqState: React.Dispatch<React.SetStateAction<EqualizerState>>;
  handleInstantSpeedAndPitchChange: (rate: number, pitchRate: number) => void;
  settings: UseSettingsReturn;
  showToast: (msg: string) => void;
}

export function usePlayer({
  tracks,
  visibleTracks,
  setTracks,
  eqState,
  setEqState,
  handleInstantSpeedAndPitchChange,
  settings,
  showToast
}: UsePlayerOptions) {
  const {
    playPauseFadeEnabled,
    playPauseFadeMs,
    crossfadeEnabled,
    gaplessEnabled,
    shakeToSkipEnabled,
    alwaysShuffleEnabled,
    openPlayerOnPlay,
    mediaSessionEnabled,
    replayGainMode
  } = settings;

  const [currentTrackId, setCurrentTrackId] = useState<string>(INITIAL_TRACKS[0]?.id || '');
  const [queueIds, setQueueIds] = useState<string[]>(INITIAL_TRACKS.map(t => t.id));
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(INITIAL_TRACKS[0]?.duration || 0);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<'off' | 'all' | 'one'>('all');

  // A-B Loop & Sleep Timer
  const [loopA, setLoopA] = useState<number | null>(null);
  const [loopB, setLoopB] = useState<number | null>(null);
  const [sleepTimerMinutes, setSleepTimerMinutesState] = useState<number | null>(null);
  const [sleepSecondsRemaining, setSleepSecondsRemaining] = useState<number | null>(null);
  const [sleepEndOfTrack, setSleepEndOfTrackState] = useState<boolean>(false);
  const [isSleepTimerFading, setIsSleepTimerFading] = useState<boolean>(false);
  const [sleepTimerVersion, setSleepTimerVersion] = useState<number>(0);

  const sleepDeadlineMsRef = useRef<number | null>(null);
  const sleepIntervalIdRef = useRef<number | null>(null);
  const sleepEndOfTrackRef = useRef<boolean>(false);
  const showToastRef = useRef(showToast);
  showToastRef.current = showToast;

  // Mobile Full-Screen Player Drawer & Sub-tab
  const [mobilePlayerExpanded, setMobilePlayerExpanded] = useState<boolean>(false);
  const [playerPanelView, setPlayerPanelView] = useState<'now-playing' | 'queue' | 'lyrics'>(
    'now-playing'
  );

  // Live listening time counter
  const [userListeningSeconds, setUserListeningSeconds] = useState<number>(0);

  const currentTrack = useMemo(
    () => tracks.find(t => t.id === currentTrackId) || visibleTracks[0] || tracks[0],
    [tracks, visibleTracks, currentTrackId]
  );

  useEffect(() => {
    audioEngine.setTransitionConfig({
      playPauseFadeEnabled,
      playPauseFadeMs,
      crossfadeEnabled,
      gaplessEnabled
    });
  }, [playPauseFadeEnabled, playPauseFadeMs, crossfadeEnabled, gaplessEnabled]);

  useEffect(() => {
    if (!isPlaying) return;
    const id = window.setInterval(() => {
      setUserListeningSeconds(prev => prev + 1);
    }, 1000);
    return () => window.clearInterval(id);
  }, [isPlaying]);

  // ReplayGain automatic dB normalization by Track or Album
  useEffect(() => {
    if (!currentTrack || replayGainMode === 'Ninguna') {
      audioEngine.setReplayGainDb(0);
      return;
    }
    if (replayGainMode === 'Por pista') {
      const bpmDelta = (120 - (currentTrack.bpm || 120)) * 0.08;
      const trackDb = Math.max(-4.5, Math.min(4.5, bpmDelta));
      audioEngine.setReplayGainDb(trackDb);
    } else if (replayGainMode === 'Por álbum') {
      const albumTracks = tracks.filter(t => t.album === currentTrack.album);
      const avgBpm =
        albumTracks.reduce((acc, t) => acc + (t.bpm || 120), 0) / Math.max(1, albumTracks.length);
      const albumDb = Math.max(-3.5, Math.min(3.5, (120 - avgBpm) * 0.07));
      audioEngine.setReplayGainDb(albumDb);
    }
  }, [currentTrack, replayGainMode, tracks]);

  const clearSleepTimerInterval = useCallback(() => {
    if (sleepIntervalIdRef.current !== null) {
      window.clearInterval(sleepIntervalIdRef.current);
      sleepIntervalIdRef.current = null;
    }
  }, []);

  const cancelSleepTimer = useCallback(
    (silent = false) => {
      clearSleepTimerInterval();
      sleepDeadlineMsRef.current = null;
      sleepEndOfTrackRef.current = false;
      setSleepTimerMinutesState(null);
      setSleepSecondsRemaining(null);
      setSleepEndOfTrackState(false);
      setIsSleepTimerFading(false);
      audioEngine.setSleepFadeMultiplier(1);
      if (!silent) {
        showToastRef.current('Temporizador de apagado cancelado');
      }
    },
    [clearSleepTimerInterval]
  );

  const startSleepTimer = useCallback(
    (minutes: number) => {
      if (!Number.isFinite(minutes) || minutes <= 0) {
        cancelSleepTimer();
        return;
      }
      clearSleepTimerInterval();
      const totalMs = Math.round(minutes * 60 * 1000);
      const totalSeconds = Math.max(1, Math.round(minutes * 60));
      sleepDeadlineMsRef.current = Date.now() + totalMs;
      sleepEndOfTrackRef.current = false;
      setSleepEndOfTrackState(false);
      setSleepTimerMinutesState(minutes);
      setSleepSecondsRemaining(totalSeconds);
      setIsSleepTimerFading(totalSeconds <= 10);
      setSleepTimerVersion(v => v + 1);
      audioEngine.setSleepFadeMultiplier(1);
    },
    [cancelSleepTimer, clearSleepTimerInterval]
  );

  const startSleepEndOfTrack = useCallback(() => {
    clearSleepTimerInterval();
    sleepDeadlineMsRef.current = null;
    sleepEndOfTrackRef.current = true;
    setSleepTimerMinutesState(null);
    setSleepEndOfTrackState(true);
    setIsSleepTimerFading(false);
    audioEngine.setSleepFadeMultiplier(1);
    const effectiveDur = duration || currentTrack?.duration || 0;
    const rate = eqState.playbackRate || 1;
    const remainingSec =
      effectiveDur > 0 ? Math.max(1, Math.ceil(Math.max(0, effectiveDur - currentTime) / rate)) : 0;
    setSleepSecondsRemaining(remainingSec);
  }, [clearSleepTimerInterval, duration, currentTrack?.duration, currentTime, eqState.playbackRate]);

  const setSleepEndOfTrack = useCallback(
    (enabled: boolean) => {
      if (enabled) {
        startSleepEndOfTrack();
      } else {
        sleepEndOfTrackRef.current = false;
        setSleepEndOfTrackState(false);
        if (sleepDeadlineMsRef.current === null) {
          setSleepSecondsRemaining(null);
          setIsSleepTimerFading(false);
          audioEngine.setSleepFadeMultiplier(1);
        }
      }
    },
    [startSleepEndOfTrack]
  );

  // Minute-based Sleep Timer Countdown + 10s Fade-Out (survives track changes)
  useEffect(() => {
    if (sleepTimerMinutes === null || sleepDeadlineMsRef.current === null) {
      return;
    }

    const tick = () => {
      const deadline = sleepDeadlineMsRef.current;
      if (deadline === null) return;

      const msRemaining = deadline - Date.now();
      if (msRemaining <= 0) {
        clearSleepTimerInterval();
        sleepDeadlineMsRef.current = null;
        sleepEndOfTrackRef.current = false;
        audioEngine.completeSleepTimerPause();
        setIsPlaying(false);
        setSleepTimerMinutesState(null);
        setSleepSecondsRemaining(null);
        setSleepEndOfTrackState(false);
        setIsSleepTimerFading(false);
        showToastRef.current('Temporizador de apagado completado. Reproducción en pausa.');
        return;
      }

      const secRemaining = Math.max(1, Math.ceil(msRemaining / 1000));
      setSleepSecondsRemaining(prev => (prev !== secRemaining ? secRemaining : prev));

      // 10-second linear fade-out before pausing
      if (msRemaining <= 10000) {
        const fadeMultiplier = Math.max(0, Math.min(1, msRemaining / 10000));
        audioEngine.setSleepFadeMultiplier(fadeMultiplier);
        setIsSleepTimerFading(prev => (!prev ? true : prev));
      } else {
        audioEngine.setSleepFadeMultiplier(1);
        setIsSleepTimerFading(prev => (prev ? false : prev));
      }
    };

    tick();
    sleepIntervalIdRef.current = window.setInterval(tick, 200);

    return () => {
      clearSleepTimerInterval();
    };
  }, [sleepTimerMinutes, sleepTimerVersion, clearSleepTimerInterval]);

  // "Terminar al acabar la canción actual" live countdown & 10s fade-out before track ends
  useEffect(() => {
    if (!sleepEndOfTrack) return;
    const effectiveDur = duration || currentTrack?.duration || 0;
    const rate = eqState.playbackRate || 1;
    const rawRemainingSec =
      effectiveDur > 0 ? Math.max(0, (effectiveDur - currentTime) / rate) : 0;
    const roundedRemaining = Math.max(0, Math.ceil(rawRemainingSec));
    setSleepSecondsRemaining(prev => (prev !== roundedRemaining ? roundedRemaining : prev));

    if (isPlaying && effectiveDur > 10 && rawRemainingSec > 0 && rawRemainingSec <= 10) {
      const fadeMultiplier = Math.max(0, Math.min(1, rawRemainingSec / 10));
      audioEngine.setSleepFadeMultiplier(fadeMultiplier);
      setIsSleepTimerFading(prev => (!prev ? true : prev));
    } else if (sleepDeadlineMsRef.current === null) {
      audioEngine.setSleepFadeMultiplier(1);
      setIsSleepTimerFading(prev => (prev ? false : prev));
    }
  }, [sleepEndOfTrack, currentTime, duration, currentTrack?.duration, eqState.playbackRate, isPlaying]);

  // Cleanup sleep timer on unmount
  useEffect(() => {
    return () => {
      clearSleepTimerInterval();
      sleepDeadlineMsRef.current = null;
      sleepEndOfTrackRef.current = false;
      audioEngine.setSleepFadeMultiplier(1);
    };
  }, [clearSleepTimerInterval]);

  const ensureTrackAudioReady = useCallback(
    async (track: Track): Promise<Track> => {
      if (track.audioUrl || !track.fileHandle) {
        return track;
      }
      const reopenedUrl = await reopenTrackAudioFromHandle(track, true);
      if (!reopenedUrl) {
        showToastRef.current(
          'Permiso requerido para reabrir el archivo de carpeta (concede acceso de lectura).'
        );
        return track;
      }
      const hydrated: Track = { ...track, audioUrl: reopenedUrl };
      setTracks(prev =>
        prev.map(t => (t.id === track.id ? { ...t, audioUrl: reopenedUrl } : t))
      );
      return hydrated;
    },
    [setTracks]
  );

  const playTrack = (track: Track, customQueueIds?: string[], fromUserSelection = false) => {
    if (track.audioUnavailable && !track.audioUrl && !track.fileHandle) {
      showToastRef.current(
        `Archivo no disponible: "${track.title}". Reimporta la carpeta o el archivo.`
      );
      return;
    }

    if (customQueueIds && customQueueIds.length > 0) {
      setQueueIds(customQueueIds);
    }
    if (alwaysShuffleEnabled) {
      setIsShuffle(true);
    }
    if (fromUserSelection && openPlayerOnPlay) {
      setMobilePlayerExpanded(true);
      setPlayerPanelView('now-playing');
    }
    setCurrentTrackId(track.id);
    setLoopA(null);
    setLoopB(null);

    if (!track.audioUrl && track.fileHandle) {
      (async () => {
        const readyTrack = await ensureTrackAudioReady(track);
        const now = Date.now();
        setTracks(prev =>
          prev.map(t => {
            if (t.id !== readyTrack.id) return t;
            const updated = {
              ...t,
              audioUrl: readyTrack.audioUrl ?? t.audioUrl,
              audioUnavailable: false,
              lastPlayedAt: now
            };
            updateTrackMetaInDb(updated);
            return updated;
          })
        );
        audioEngine.loadTrack(readyTrack, true);
        setIsPlaying(true);
      })();
      return;
    }

    setTracks(prev =>
      prev.map(t => {
        if (t.id !== track.id) return t;
        const updated = { ...t, lastPlayedAt: Date.now() };
        updateTrackMetaInDb(updated);
        return updated;
      })
    );
    audioEngine.loadTrack(track, true);
    setIsPlaying(true);
  };

  const togglePlayPause = () => {
    if (!currentTrack) return;
    if (isPlaying) {
      audioEngine.pause();
      setIsPlaying(false);
    } else if (currentTrack.audioUnavailable && !currentTrack.audioUrl && !currentTrack.fileHandle) {
      showToastRef.current(
        `Archivo no disponible: "${currentTrack.title}". Reimporta la carpeta o el archivo.`
      );
    } else if (!currentTrack.audioUrl && currentTrack.fileHandle) {
      (async () => {
        const readyTrack = await ensureTrackAudioReady(currentTrack);
        audioEngine.loadTrack(readyTrack, true);
        setIsPlaying(true);
      })();
    } else {
      audioEngine.loadTrack(currentTrack, true);
      setIsPlaying(true);
    }
  };

  const handleNextTrack = (fromAutoEnd = false) => {
    if (queueIds.length === 0) return;
    if ((fromAutoEnd && repeatMode === 'one') || queueIds.length === 1) {
      if (fromAutoEnd && repeatMode === 'off' && queueIds.length === 1) {
        setIsPlaying(false);
        setCurrentTime(0);
        audioEngine.seek(0);
        return;
      }
      setCurrentTime(0);
      audioEngine.seek(0);
      audioEngine.play();
      setIsPlaying(true);
      return;
    }

    if (!currentTrack) return;
    const currentIndex = queueIds.indexOf(currentTrack.id);
    let nextIndex = 0;

    if (isShuffle && queueIds.length > 1) {
      do {
        nextIndex = Math.floor(Math.random() * queueIds.length);
      } while (nextIndex === currentIndex);
    } else {
      nextIndex = currentIndex + 1;
      if (nextIndex >= queueIds.length) {
        if (fromAutoEnd && repeatMode === 'off') {
          setIsPlaying(false);
          return;
        }
        nextIndex = 0;
      }
    }

    const nextTrack = tracks.find(t => t.id === queueIds[nextIndex]);
    if (nextTrack) {
      setCurrentTime(0);
      audioEngine.seek(0);
      playTrack(nextTrack);
    }
  };

  const handlePrevTrack = () => {
    if (currentTime > 3 || queueIds.length <= 1) {
      setCurrentTime(0);
      audioEngine.seek(0);
      if (!isPlaying && currentTrack) {
        audioEngine.loadTrack(currentTrack, true);
        setIsPlaying(true);
      }
      showToast('Reiniciando canción desde 0:00');
      return;
    }
    if (!currentTrack) return;
    const currentIndex = queueIds.indexOf(currentTrack.id);
    const prevIndex = currentIndex <= 0 ? queueIds.length - 1 : currentIndex - 1;
    const prevTrack = tracks.find(t => t.id === queueIds[prevIndex]);
    if (prevTrack) {
      setCurrentTime(0);
      audioEngine.seek(0);
      playTrack(prevTrack);
    }
  };

  // Audio Engine Callbacks & Synchronization
  useEffect(() => {
    audioEngine.setCallbacks(
      (time, dur) => {
        setCurrentTime(time);
        setDuration(dur);
      },
      () => {
        if (!currentTrack) return;
        setTracks(prev =>
          prev.map(t => {
            if (t.id !== currentTrack.id) return t;
            const updated = {
              ...t,
              playCount: t.playCount + 1,
              lastPlayedAt: Date.now()
            };
            updateTrackMetaInDb(updated);
            return updated;
          })
        );
        if (sleepEndOfTrackRef.current) {
          sleepEndOfTrackRef.current = false;
          setSleepEndOfTrackState(false);
          setSleepTimerMinutesState(null);
          setSleepSecondsRemaining(null);
          setIsSleepTimerFading(false);
          audioEngine.completeSleepTimerPause();
          setIsPlaying(false);
          setCurrentTime(0);
          audioEngine.seek(0);
          showToastRef.current(
            'Temporizador de apagado: reproducción pausada al acabar la canción.'
          );
          return;
        }
        handleNextTrack(true);
      }
    );
  });

  // Shake to skip song sensor
  useEffect(() => {
    if (!shakeToSkipEnabled) return;
    let lastShake = 0;
    const onMotion = (e: DeviceMotionEvent) => {
      const acc = e.accelerationIncludingGravity;
      if (!acc) return;
      const total = Math.abs(acc.x || 0) + Math.abs(acc.y || 0) + Math.abs(acc.z || 0);
      const now = Date.now();
      if (total > 32 && now - lastShake > 1200) {
        lastShake = now;
        handleNextTrack(false);
        showToast('Agitación detectada: Siguiente canción »');
      }
    };
    window.addEventListener('devicemotion', onMotion);
    return () => window.removeEventListener('devicemotion', onMotion);
  }, [shakeToSkipEnabled, queueIds, currentTrackId]);

  const updateMediaSessionPositionState = (posTime: number, totalDur: number, rate: number) => {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    const ms = navigator.mediaSession;
    if (!mediaSessionEnabled || !currentTrack || typeof ms.setPositionState !== 'function') return;

    const effectiveDuration = totalDur > 0 ? totalDur : currentTrack.duration || 0;
    if (effectiveDuration <= 0 || !Number.isFinite(effectiveDuration)) return;

    const clampedPosition = Number.isFinite(posTime)
      ? Math.max(0, Math.min(effectiveDuration, posTime))
      : 0;
    const safeRate = Number.isFinite(rate) && rate > 0 ? rate : 1;

    try {
      ms.setPositionState({
        duration: effectiveDuration,
        playbackRate: safeRate,
        position: clampedPosition
      });
    } catch {
      // Ignore invalid state errors in unsupported browsers
    }
  };

  // Configurable MediaSession API: metadata, playbackState & action handlers
  useEffect(() => {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    const ms = navigator.mediaSession;
    const actions: MediaSessionAction[] = [
      'play',
      'pause',
      'previoustrack',
      'nexttrack',
      'seekto',
      'seekbackward',
      'seekforward'
    ];

    const safeSetActionHandler = (
      action: MediaSessionAction,
      handler: MediaSessionActionHandler | null
    ) => {
      try {
        ms.setActionHandler(action, handler);
      } catch {
        // Ignore unsupported MediaSession action
      }
    };

    if (!mediaSessionEnabled || !currentTrack) {
      ms.metadata = null;
      ms.playbackState = 'none';
      actions.forEach(action => safeSetActionHandler(action, null));
      try {
        if (typeof ms.setPositionState === 'function') {
          ms.setPositionState();
        }
      } catch {
        // Ignore position reset errors
      }
      return;
    }

    if (typeof MediaMetadata !== 'undefined') {
      ms.metadata = new MediaMetadata({
        title: currentTrack.title || 'Canción sin título',
        artist: currentTrack.artist || 'Artista desconocido',
        album: currentTrack.album || 'Álbum desconocido',
        artwork: currentTrack.coverUrl
          ? [
              { src: currentTrack.coverUrl, sizes: '96x96' },
              { src: currentTrack.coverUrl, sizes: '128x128' },
              { src: currentTrack.coverUrl, sizes: '192x192' },
              { src: currentTrack.coverUrl, sizes: '256x256' },
              { src: currentTrack.coverUrl, sizes: '384x384' },
              { src: currentTrack.coverUrl, sizes: '512x512' }
            ]
          : []
      });
    }
  }, [
    mediaSessionEnabled,
    currentTrack?.id,
    currentTrack?.title,
    currentTrack?.artist,
    currentTrack?.album,
    currentTrack?.coverUrl
  ]);

  useEffect(() => {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    const ms = navigator.mediaSession;
    const actions: MediaSessionAction[] = [
      'play',
      'pause',
      'previoustrack',
      'nexttrack',
      'seekto',
      'seekbackward',
      'seekforward'
    ];

    const safeSetActionHandler = (
      action: MediaSessionAction,
      handler: MediaSessionActionHandler | null
    ) => {
      try {
        ms.setActionHandler(action, handler);
      } catch {
        // Ignore unsupported MediaSession action
      }
    };

    if (!mediaSessionEnabled || !currentTrack) {
      ms.playbackState = 'none';
      actions.forEach(action => safeSetActionHandler(action, null));
      return;
    }

    ms.playbackState = isPlaying ? 'playing' : 'paused';

    safeSetActionHandler('play', () => {
      audioEngine.loadTrack(currentTrack, true);
      setIsPlaying(true);
    });

    safeSetActionHandler('pause', () => {
      audioEngine.pause();
      setIsPlaying(false);
    });

    safeSetActionHandler('previoustrack', () => {
      handlePrevTrack();
    });

    safeSetActionHandler('nexttrack', () => {
      handleNextTrack(false);
    });

    safeSetActionHandler('seekto', details => {
      if (typeof details.seekTime === 'number' && Number.isFinite(details.seekTime)) {
        const maxDur = duration || currentTrack.duration || 0;
        const clamped =
          maxDur > 0
            ? Math.max(0, Math.min(maxDur, details.seekTime))
            : Math.max(0, details.seekTime);
        setCurrentTime(clamped);
        audioEngine.seek(clamped);
        updateMediaSessionPositionState(clamped, maxDur, eqState.playbackRate);
      }
    });

    safeSetActionHandler('seekbackward', details => {
      const offset = details.seekOffset && details.seekOffset > 0 ? details.seekOffset : 10;
      const maxDur = duration || currentTrack.duration || 0;
      const clamped = Math.max(0, currentTime - offset);
      setCurrentTime(clamped);
      audioEngine.seek(clamped);
      updateMediaSessionPositionState(clamped, maxDur, eqState.playbackRate);
    });

    safeSetActionHandler('seekforward', details => {
      const offset = details.seekOffset && details.seekOffset > 0 ? details.seekOffset : 10;
      const maxDur = duration || currentTrack.duration || 0;
      const clamped = maxDur > 0 ? Math.min(maxDur, currentTime + offset) : currentTime + offset;
      setCurrentTime(clamped);
      audioEngine.seek(clamped);
      updateMediaSessionPositionState(clamped, maxDur, eqState.playbackRate);
    });

    return () => {
      actions.forEach(action => safeSetActionHandler(action, null));
    };
  }, [
    mediaSessionEnabled,
    currentTrack,
    isPlaying,
    queueIds,
    currentTime,
    duration,
    isShuffle,
    repeatMode,
    eqState.playbackRate
  ]);

  // Synchronize MediaSession position state
  useEffect(() => {
    updateMediaSessionPositionState(currentTime, duration, eqState.playbackRate);
  }, [
    mediaSessionEnabled,
    currentTrack,
    currentTime,
    duration,
    eqState.playbackRate,
    isPlaying
  ]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = Number(e.target.value);
    setCurrentTime(newTime);
    audioEngine.seek(newTime);
    updateMediaSessionPositionState(newTime, duration, eqState.playbackRate);
  };

  const handleDirectSeek = (seconds: number) => {
    const maxDur = duration || currentTrack?.duration || 0;
    const clamped = Math.max(0, Math.min(maxDur, seconds));
    setCurrentTime(clamped);
    audioEngine.seek(clamped);
    updateMediaSessionPositionState(clamped, maxDur, eqState.playbackRate);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    audioEngine.setVolume(val);
    audioEngine.setMuted(val === 0);
  };

  const handleDirectVolumeChange = (val: number) => {
    setVolume(val);
    setIsMuted(val === 0);
    audioEngine.setVolume(val);
    audioEngine.setMuted(val === 0);
  };

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    audioEngine.setMuted(nextMuted);
  };

  const handleToggleLoopPoint = () => {
    if (loopA === null) {
      setLoopA(currentTime);
      audioEngine.setLoopPoints(currentTime, null);
      showToast(`Punto A fijado en ${formatDuration(currentTime)}`);
    } else if (loopB === null && currentTime > loopA + 1) {
      setLoopB(currentTime);
      audioEngine.setLoopPoints(loopA, currentTime);
      showToast(`Bucle A-B activo (${formatDuration(loopA)} — ${formatDuration(currentTime)})`);
    } else {
      setLoopA(null);
      setLoopB(null);
      audioEngine.setLoopPoints(null, null);
      showToast('Bucle A-B desactivado');
    }
  };

  const handleShareTrack = (mode: 'hashtag' | 'native') => {
    if (!currentTrack) return;
    const shareText =
      mode === 'hashtag'
        ? `🎵 #MadPlayer #NowPlaying\n${currentTrack.title} — ${currentTrack.artist}\nÁlbum: ${currentTrack.album} · ${currentTrack.bpm} BPM`
        : `Escuchando "${currentTrack.title}" de ${currentTrack.artist} en Mad Player`;

    if (mode === 'native' && navigator.share) {
      navigator
        .share({
          title: `${currentTrack.title} — Mad Player`,
          text: shareText,
          url: window.location.href
        })
        .catch(() => {
          safeCopyToClipboard(shareText);
          showToast('Información de la pista copiada al portapapeles');
        });
    } else {
      safeCopyToClipboard(shareText);
      showToast(
        mode === 'hashtag'
          ? 'Tarjeta con etiquetas (#) copiada al portapapeles'
          : 'Enlace y detalles copiados al portapapeles'
      );
    }
  };

  const handleCreateTrimmedTrack = (clipTitle: string, startSec: number, endSec: number) => {
    if (!currentTrack) return;
    const clipDuration = Math.max(5, Math.round(endSec - startSec));
    const trimmed: Track = {
      ...currentTrack,
      id: `clip-${Date.now()}`,
      title: clipTitle,
      album: `${currentTrack.album} (Recortes MP3)`,
      duration: clipDuration,
      playCount: 1,
      addedAt: new Date().toISOString().slice(0, 10),
      lastPlayedAt: Date.now()
    };
    cloneTrackInDb(currentTrack.id, trimmed);
    setTracks(prev => [trimmed, ...prev]);
    setQueueIds(prev => [trimmed.id, ...prev]);
    playTrack(trimmed, [trimmed.id, ...queueIds]);
    showToast(`Recorte "${clipTitle}" (${formatDuration(clipDuration)}) guardado`);
  };

  return {
    currentTrackId,
    setCurrentTrackId,
    currentTrack,
    queueIds,
    setQueueIds,
    isPlaying,
    setIsPlaying,
    currentTime,
    setCurrentTime,
    duration,
    setDuration,
    volume,
    isMuted,
    isShuffle,
    setIsShuffle,
    repeatMode,
    setRepeatMode,
    eqState,
    setEqState,
    loopA,
    loopB,
    sleepTimerMinutes,
    sleepSecondsRemaining,
    setSleepSecondsRemaining,
    sleepEndOfTrack,
    setSleepEndOfTrack,
    isSleepTimerFading,
    startSleepTimer,
    startSleepEndOfTrack,
    cancelSleepTimer,
    mobilePlayerExpanded,
    setMobilePlayerExpanded,
    playerPanelView,
    setPlayerPanelView,
    userListeningSeconds,
    playTrack,
    togglePlayPause,
    handleNextTrack,
    handlePrevTrack,
    handleInstantSpeedAndPitchChange,
    handleSeek,
    handleDirectSeek,
    handleVolumeChange,
    handleDirectVolumeChange,
    toggleMute,
    handleToggleLoopPoint,
    handleShareTrack,
    handleCreateTrimmedTrack
  };
}
