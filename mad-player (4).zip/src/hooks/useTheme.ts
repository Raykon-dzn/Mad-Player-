import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { ThemeConfig, Track } from '../types/music';
import { INITIAL_TRACKS } from '../data/initialLibrary';
import {
  extractDominantColorFromImage,
  buildThemePalette,
  applyPaletteToDocument
} from '../utils/colorExtractor';
import {
  loadThemeConfigFromDb,
  loadWallpapersFromDb,
  migrateLocalStorageToIndexedDb,
  revokeObjectUrlSafe,
  saveThemeConfigToDb
} from '../services/mediaStorageDb';

export function useTheme() {
  const isThemeHydratedRef = useRef<boolean>(false);

  const [themeConfig, setThemeConfig] = useState<ThemeConfig>({
    baseId: 'nordic-slate',
    adaptToCoverArt: true,
    customAccentHex: '#1cc8ee',
    useCustomAccent: false,
    coverShape: 'rounded',
    playerSkin: 'muzio-classic',
    visualizerStyle: 'spectrum-bars',
    compactDensity: false
  });

  // Dynamic Color Extraction
  const [extractedTrackColor, setExtractedTrackColor] = useState<string>(
    INITIAL_TRACKS[0]?.dominantColor || '#1cc8ee'
  );

  useEffect(() => {
    let active = true;
    (async () => {
      await migrateLocalStorageToIndexedDb();
      const [savedTheme, savedWallpapers] = await Promise.all([
        loadThemeConfigFromDb(),
        loadWallpapersFromDb()
      ]);

      if (!active) {
        savedWallpapers.forEach(w => revokeObjectUrlSafe(w.url));
        return;
      }

      if (savedTheme) {
        const hydratedTheme: ThemeConfig = { ...savedTheme };
        if (savedWallpapers.length > 0) {
          hydratedTheme.customUserImages = savedWallpapers;
          const matchingWp =
            savedWallpapers.find(w => w.id === savedTheme.bgImageId) || savedWallpapers[0];
          if (
            savedTheme.bgImageId &&
            savedTheme.bgImageId.startsWith('custom-wp-') &&
            matchingWp
          ) {
            hydratedTheme.bgImageUrl = matchingWp.url;
          }
        }
        setThemeConfig(prev => {
          if (prev.bgImageUrl && prev.bgImageUrl !== hydratedTheme.bgImageUrl) {
            revokeObjectUrlSafe(prev.bgImageUrl);
          }
          return hydratedTheme;
        });
      } else if (savedWallpapers.length > 0) {
        setThemeConfig(prev => ({
          ...prev,
          customUserImages: savedWallpapers
        }));
      }

      isThemeHydratedRef.current = true;
    })();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!isThemeHydratedRef.current) return;
    saveThemeConfigToDb(themeConfig);
  }, [themeConfig]);

  const activePalette = useMemo(
    () => buildThemePalette(themeConfig, extractedTrackColor),
    [themeConfig, extractedTrackColor]
  );

  useEffect(() => {
    applyPaletteToDocument(activePalette);
  }, [activePalette]);

  const syncTrackDominantColor = useCallback((current?: Track) => {
    let cancelled = false;
    if (current) {
      if (current.coverUrl) {
        extractDominantColorFromImage(current.coverUrl, current.dominantColor).then(hex => {
          if (!cancelled) {
            setExtractedTrackColor(hex);
          }
        });
      } else {
        setExtractedTrackColor(current.dominantColor);
      }
    }
    return () => {
      cancelled = true;
    };
  }, []);

  return {
    themeConfig,
    setThemeConfig,
    extractedTrackColor,
    setExtractedTrackColor,
    activePalette,
    syncTrackDominantColor
  };
}
