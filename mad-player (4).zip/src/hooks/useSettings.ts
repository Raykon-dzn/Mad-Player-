import React, { createContext, useContext, useState } from 'react';

export type SettingsSubPage =
  | 'main'
  | 'profile'
  | 'app'
  | 'audio'
  | 'elegir-tema'
  | 'player-skins'
  | 'hidden-files'
  | 'backup'
  | 'about';

export interface HiddenFolderItem {
  id: string;
  name: string;
  path: string;
}

export interface NavTabConfigItem {
  id: string;
  label: string;
  enabled: boolean;
}

export interface BackupSelectionState {
  covers: boolean;
  tags: boolean;
  lyrics: boolean;
  playlists: boolean;
  hiddenFiles: boolean;
}

export type SettingsDialogType =
  | null
  | 'edit-profile'
  | 'edit-tabs'
  | 'last-added-interval'
  | 'duplicate-policy'
  | 'save-tags-to-files'
  | 'player-theme'
  | 'default-eq'
  | 'play-pause-fade'
  | 'crossfade'
  | 'background-play-help'
  | 'muzio-lockscreen-bg'
  | 'system-lockscreen-bg'
  | 'replaygain'
  | 'filter-duration'
  | 'filter-size'
  | 'add-hidden-folder'
  | 'add-hidden-song'
  | 'cloud-email'
  | 'cloud-backup-items'
  | 'local-backup-items'
  | 'about-intro'
  | 'about-changelog'
  | 'about-faq'
  | 'about-translate'
  | 'about-web'
  | 'about-privacy'
  | 'about-licenses';

interface UseSettingsOptions {
  showToast: (msg: string) => void;
}

export function useSettings({ showToast }: UseSettingsOptions) {
  // User Profile
  const [userProfileName, setUserProfileName] = useState<string>('DaikiMad');
  const [userProfileAvatar, setUserProfileAvatar] = useState<string>('');

  // Customizable Home Tabs Order & Visibility
  const [navTabsConfig, setNavTabsConfig] = useState<NavTabConfigItem[]>([
    { id: 'suggested', label: 'Sugirió', enabled: true },
    { id: 'library', label: 'Canciones', enabled: true },
    { id: 'albums', label: 'Álbumes', enabled: true },
    { id: 'artists', label: 'Artistas', enabled: true },
    { id: 'playlists', label: 'Lista de reproducción', enabled: true },
    { id: 'folders', label: 'Carpetas', enabled: true },
    { id: 'genres', label: 'Géneros', enabled: true },
    { id: 'smart-lists', label: 'Inteligentes', enabled: true },
    { id: 'equalizer', label: 'Ecualizador', enabled: true },
    { id: 'themes', label: 'Temas', enabled: true }
  ]);

  // Interface, Display & Lockscreen Preferences (moved out of usePlayer)
  const [openPlayerOnPlay, setOpenPlayerOnPlay] = useState<boolean>(true);
  const [volumeGestureEnabled, setVolumeGestureEnabled] = useState<boolean>(true);
  const [mediaSessionEnabled, setMediaSessionEnabled] = useState<boolean>(true);
  const [parallelPlayEnabled, setParallelPlayEnabled] = useState<boolean>(true);
  const [hdCoverEnabled, setHdCoverEnabled] = useState<boolean>(false);
  const [syncDeviceTags, setSyncDeviceTags] = useState<boolean>(false);
  const [updateDeviceTags, setUpdateDeviceTags] = useState<boolean>(false);
  const [lockscreenPlayerEnabled, setLockscreenPlayerEnabled] = useState<boolean>(false);
  const [use24HourFormat, setUse24HourFormat] = useState<boolean>(false);
  const [muzioLockscreenBg, setMuzioLockscreenBg] = useState<string>('Diseño');
  const [systemLockscreenBg, setSystemLockscreenBg] = useState<string>('Portada del álbum');

  // Audio Transition & Playback Preferences
  const [playPauseFadeEnabled, setPlayPauseFadeEnabled] = useState<boolean>(true);
  const [playPauseFadeMs, setPlayPauseFadeMs] = useState<number>(505);
  const [crossfadeEnabled, setCrossfadeEnabled] = useState<boolean>(false);
  const [crossfadeSeconds, setCrossfadeSeconds] = useState<number>(4);
  const [gaplessEnabled, setGaplessEnabled] = useState<boolean>(false);
  const [shakeToSkipEnabled, setShakeToSkipEnabled] = useState<boolean>(false);
  const [alwaysShuffleEnabled, setAlwaysShuffleEnabled] = useState<boolean>(false);
  const [replayGainMode, setReplayGainMode] = useState<string>('Ninguna');

  const updateUserProfile = (name: string, avatar: string) => {
    if (
      userProfileAvatar &&
      userProfileAvatar.startsWith('blob:') &&
      userProfileAvatar !== avatar
    ) {
      URL.revokeObjectURL(userProfileAvatar);
    }
    setUserProfileName(name);
    setUserProfileAvatar(avatar);
  };

  const updatePlayPauseFade = (enabled: boolean, ms: number) => {
    setPlayPauseFadeEnabled(enabled);
    setPlayPauseFadeMs(ms);
  };

  const togglePlayPauseFade = () => {
    const next = !playPauseFadeEnabled;
    setPlayPauseFadeEnabled(next);
    showToast(
      next
        ? `Desvanecimiento al reproducir/pausar activo (${playPauseFadeMs} ms)`
        : 'Desvanecimiento al reproducir/pausar desactivado'
    );
  };

  const updateCrossfade = (enabled: boolean, seconds: number) => {
    setCrossfadeEnabled(enabled);
    setCrossfadeSeconds(seconds);
  };

  const toggleCrossfade = () => {
    const next = !crossfadeEnabled;
    setCrossfadeEnabled(next);
    showToast(
      next
        ? 'Desvanecimiento entre pistas (Crossfade) activo'
        : 'Desvanecimiento desactivado'
    );
  };

  const toggleGapless = () => {
    const next = !gaplessEnabled;
    setGaplessEnabled(next);
    showToast(
      next ? 'Reproducción sin pausas activada' : 'Reproducción sin pausas desactivada'
    );
  };

  const toggleShakeToSkip = () => {
    const next = !shakeToSkipEnabled;
    setShakeToSkipEnabled(next);
    showToast(
      next
        ? 'Agitar para cambiar de canción activado'
        : 'Agitar para cambiar desactivado'
    );
  };

  const toggleOpenPlayerOnPlay = () => {
    const next = !openPlayerOnPlay;
    setOpenPlayerOnPlay(next);
    showToast(
      next
        ? 'Abrir reproductor al iniciar canción activo'
        : 'Abrir reproductor desactivado'
    );
  };

  const toggleVolumeGesture = () => {
    const next = !volumeGestureEnabled;
    setVolumeGestureEnabled(next);
    showToast(
      next
        ? 'Gesto de volumen en reproductor activado'
        : 'Gesto de volumen desactivado'
    );
  };

  const toggleMediaSession = () => {
    const next = !mediaSessionEnabled;
    setMediaSessionEnabled(next);
    showToast(
      next
        ? 'Controles en notificación y Bluetooth activados'
        : 'Controles en notificación y Bluetooth desactivados'
    );
  };

  const toggleParallelPlay = () => {
    const next = !parallelPlayEnabled;
    setParallelPlayEnabled(next);
    showToast(
      next ? 'Reproducción paralela activada' : 'Reproducción paralela desactivada'
    );
  };

  const toggleHdCover = () => {
    const next = !hdCoverEnabled;
    setHdCoverEnabled(next);
    showToast(next ? 'Carátulas HD activadas' : 'Carátulas HD desactivadas');
  };

  const toggleSyncDeviceTags = () => {
    const next = !syncDeviceTags;
    setSyncDeviceTags(next);
    showToast(
      next ? 'Sincronización de etiquetas activada' : 'Sincronización desactivada'
    );
  };

  const toggleUpdateDeviceTags = () => {
    const next = !updateDeviceTags;
    setUpdateDeviceTags(next);
    showToast(
      next
        ? 'Permiso de actualización de etiquetas activo'
        : 'Actualización desactivada'
    );
  };

  const toggleLockscreenPlayer = () => {
    const next = !lockscreenPlayerEnabled;
    setLockscreenPlayerEnabled(next);
    showToast(
      next
        ? 'Reproductor de pantalla de bloqueo activo'
        : 'Pantalla de bloqueo desactivada'
    );
  };

  const toggle24HourFormat = () => {
    const next = !use24HourFormat;
    setUse24HourFormat(next);
    showToast(
      next ? 'Formato de 24 horas activado' : 'Formato de 12 horas activado'
    );
  };

  return {
    userProfileName,
    setUserProfileName,
    userProfileAvatar,
    setUserProfileAvatar,
    updateUserProfile,
    navTabsConfig,
    setNavTabsConfig,
    openPlayerOnPlay,
    setOpenPlayerOnPlay,
    toggleOpenPlayerOnPlay,
    volumeGestureEnabled,
    setVolumeGestureEnabled,
    toggleVolumeGesture,
    mediaSessionEnabled,
    setMediaSessionEnabled,
    toggleMediaSession,
    parallelPlayEnabled,
    setParallelPlayEnabled,
    toggleParallelPlay,
    hdCoverEnabled,
    setHdCoverEnabled,
    toggleHdCover,
    syncDeviceTags,
    setSyncDeviceTags,
    toggleSyncDeviceTags,
    updateDeviceTags,
    setUpdateDeviceTags,
    toggleUpdateDeviceTags,
    lockscreenPlayerEnabled,
    setLockscreenPlayerEnabled,
    toggleLockscreenPlayer,
    use24HourFormat,
    setUse24HourFormat,
    toggle24HourFormat,
    muzioLockscreenBg,
    setMuzioLockscreenBg,
    systemLockscreenBg,
    setSystemLockscreenBg,
    playPauseFadeEnabled,
    setPlayPauseFadeEnabled,
    playPauseFadeMs,
    setPlayPauseFadeMs,
    updatePlayPauseFade,
    togglePlayPauseFade,
    crossfadeEnabled,
    setCrossfadeEnabled,
    crossfadeSeconds,
    setCrossfadeSeconds,
    updateCrossfade,
    toggleCrossfade,
    gaplessEnabled,
    setGaplessEnabled,
    toggleGapless,
    shakeToSkipEnabled,
    setShakeToSkipEnabled,
    toggleShakeToSkip,
    alwaysShuffleEnabled,
    setAlwaysShuffleEnabled,
    replayGainMode,
    setReplayGainMode
  };
}

export type UseSettingsReturn = ReturnType<typeof useSettings>;

const SettingsContext = createContext<UseSettingsReturn | null>(null);

export const SettingsProvider = SettingsContext.Provider;

export function useSettingsContext(): UseSettingsReturn {
  const ctx = useContext(SettingsContext);
  if (!ctx) {
    throw new Error('useSettingsContext debe usarse dentro de SettingsProvider');
  }
  return ctx;
}
