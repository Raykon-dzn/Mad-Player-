import React, { useEffect, useRef } from 'react';
import { VisualizerStyle } from '../types/music';
import { audioEngine } from '../services/audioEngine';

interface AudioVisualizerProps {
  isPlaying: boolean;
  style: VisualizerStyle;
  accentColor: string;
  height?: number;
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  isPlaying,
  style,
  accentColor,
  height = 56
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId: number;
    const bufferLength = 64;
    const dataArray = new Uint8Array(bufferLength);
    let phase = 0;

    const render = () => {
      const width = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, width, h);

      const analyser = audioEngine.getAnalyser();
      if (analyser && isPlaying) {
        if (style === 'oscilloscope-wave') {
          analyser.getByteTimeDomainData(dataArray);
        } else {
          analyser.getByteFrequencyData(dataArray);
        }
      } else {
        // Gentle idle baseline
        for (let i = 0; i < bufferLength; i++) {
          dataArray[i] = style === 'oscilloscope-wave' ? 128 : 8;
        }
      }

      phase += isPlaying ? 0.06 : 0.01;

      if (style === 'spectrum-bars') {
        const barCount = 32;
        const gap = 3;
        const barWidth = (width - gap * (barCount - 1)) / barCount;

        for (let i = 0; i < barCount; i++) {
          const raw = dataArray[i] || 0;
          const normalized = isPlaying
            ? Math.max(0.08, raw / 255)
            : 0.08 + Math.sin(phase + i * 0.3) * 0.03;
          const barHeight = Math.max(4, normalized * (h - 4));
          const x = i * (barWidth + gap);
          const y = h - barHeight;

          ctx.fillStyle = accentColor;
          ctx.globalAlpha = 0.35 + normalized * 0.65;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, 2);
          ctx.fill();
        }
        ctx.globalAlpha = 1;
      } else if (style === 'oscilloscope-wave') {
        ctx.lineWidth = 2;
        ctx.strokeStyle = accentColor;
        ctx.beginPath();

        const sliceWidth = width / (bufferLength - 1);
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const v = isPlaying
            ? dataArray[i] / 128.0
            : 1 + Math.sin(phase + i * 0.25) * 0.05;
          const y = (v * h) / 2;
          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
          x += sliceWidth;
        }
        ctx.stroke();
      } else {
        // harmonic-pulse (symmetric center waveform)
        const barCount = 28;
        const gap = 4;
        const barWidth = (width - gap * (barCount - 1)) / barCount;
        const centerY = h / 2;

        for (let i = 0; i < barCount; i++) {
          const mirrorIdx = Math.abs(i - barCount / 2);
          const raw = dataArray[Math.floor(mirrorIdx)] || 0;
          const normalized = isPlaying
            ? Math.max(0.1, raw / 255)
            : 0.1 + Math.cos(phase + mirrorIdx * 0.35) * 0.04;
          const halfHeight = Math.max(2, (normalized * (h - 6)) / 2);
          const x = i * (barWidth + gap);

          ctx.fillStyle = accentColor;
          ctx.globalAlpha = 0.4 + normalized * 0.6;
          ctx.beginPath();
          ctx.roundRect(x, centerY - halfHeight, barWidth, halfHeight * 2, 3);
          ctx.fill();
        }
        ctx.globalAlpha = 1;
      }

      rafId = window.requestAnimationFrame(render);
    };

    rafId = window.requestAnimationFrame(render);
    return () => {
      window.cancelAnimationFrame(rafId);
    };
  }, [isPlaying, style, accentColor]);

  return (
    <canvas
      ref={canvasRef}
      width={320}
      height={height}
      className="w-full block"
      style={{ height: `${height}px` }}
      aria-label="Visualizador de espectro de audio en tiempo real"
    />
  );
};
