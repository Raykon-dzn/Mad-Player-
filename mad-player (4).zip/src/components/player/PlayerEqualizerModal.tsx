import React from 'react';
import { ArrowLeft, ImagePlus, X } from 'lucide-react';
import { EqualizerState, Track } from '../../types/music';
import { EQ_PRESETS } from '../../data/initialLibrary';
import { CoverArt } from '../CoverArt';

interface PlayerEqualizerModalProps {
  showEqualizerModal: boolean;
  setShowEqualizerModal: React.Dispatch<React.SetStateAction<boolean>>;
  eqState: EqualizerState;
  setEqState: React.Dispatch<React.SetStateAction<EqualizerState>>;
}

export const PlayerEqualizerModal: React.FC<PlayerEqualizerModalProps> = ({
  showEqualizerModal,
  setShowEqualizerModal,
  eqState,
  setEqState
}) => {
  if (!showEqualizerModal) return null;

  return (
    <div
      onClick={() => setShowEqualizerModal(false)}
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 select-none"
    >
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-lg rounded-3xl border p-5 sm:p-6 flex flex-col gap-5 shadow-2xl max-h-[92vh] overflow-y-auto"
        style={{
          backgroundColor: '#071b2c',
          borderColor: 'rgba(255,255,255,0.12)',
          color: '#ffffff'
        }}
      >
        <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3.5">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowEqualizerModal(false)}
              aria-label="Cerrar ecualizador"
              className="w-9 h-9 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-lg font-extrabold font-display tracking-tight text-white">
                Ecualizador
              </h2>
              <p className="text-xs font-bold text-[#8da4ba]">
                Ajuste en tiempo real sobre la pista actual
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setEqState(prev => ({ ...prev, enabled: !prev.enabled }))}
              className="px-3.5 py-1.5 rounded-full text-xs font-extrabold transition-colors cursor-pointer"
              style={{
                backgroundColor: eqState.enabled
                  ? 'var(--theme-accent)'
                  : 'rgba(255,255,255,0.1)',
                color: eqState.enabled ? '#041019' : '#94a3b8'
              }}
            >
              {eqState.enabled ? 'ON' : 'OFF'}
            </button>
            <button
              type="button"
              onClick={() => setShowEqualizerModal(false)}
              aria-label="Cerrar"
              className="w-8 h-8 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {Object.entries(EQ_PRESETS).map(([name, gains]) => {
            const active = eqState.presetName === name;
            return (
              <button
                key={name}
                type="button"
                onClick={() =>
                  setEqState(prev => ({
                    ...prev,
                    enabled: true,
                    presetName: name,
                    bands: prev.bands.map((b, i) => ({ ...b, gain: gains[i] }))
                  }))
                }
                className="px-3.5 py-1.5 rounded-xl text-xs font-extrabold border whitespace-nowrap shrink-0 cursor-pointer transition-colors"
                style={{
                  backgroundColor: active ? 'var(--theme-accent)' : 'rgba(255,255,255,0.06)',
                  color: active ? '#041019' : '#ffffff',
                  borderColor: active ? 'var(--theme-accent)' : 'rgba(255,255,255,0.1)'
                }}
              >
                {name}
              </button>
            );
          })}
        </div>

        <div className="p-4 rounded-2xl bg-black/25 border border-white/10 grid grid-cols-5 gap-2 sm:gap-4">
          {eqState.bands.map((band, idx) => (
            <div key={band.frequency} className="flex flex-col items-center gap-2.5">
              <span
                className="text-xs font-mono-tabular font-extrabold"
                style={{ color: 'var(--theme-accent)' }}
              >
                {band.gain > 0 ? `+${band.gain}` : band.gain}dB
              </span>
              <div className="h-36 flex items-center justify-center">
                <input
                  type="range"
                  min={-12}
                  max={12}
                  step={0.5}
                  value={band.gain}
                  onChange={e => {
                    const val = Number(e.target.value);
                    setEqState(prev => ({
                      ...prev,
                      enabled: true,
                      presetName: 'Personalizado',
                      bands: prev.bands.map((b, i) => (i === idx ? { ...b, gain: val } : b))
                    }));
                  }}
                  className="w-28 -rotate-90 cursor-pointer"
                  style={{ accentColor: 'var(--theme-accent)' }}
                  aria-label={`Banda ${band.label}`}
                />
              </div>
              <span className="text-[11px] font-mono-tabular font-bold text-slate-300">
                {band.label}
              </span>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3.5 rounded-2xl bg-black/25 border border-white/10 flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-extrabold">
              <span className="text-white">Refuerzo de Graves (Bass)</span>
              <span className="font-mono-tabular" style={{ color: 'var(--theme-accent)' }}>
                +{eqState.bassBoost.toFixed(1)} dB
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={10}
              step={0.5}
              value={eqState.bassBoost}
              onChange={e =>
                setEqState(prev => ({
                  ...prev,
                  enabled: true,
                  bassBoost: Number(e.target.value)
                }))
              }
              className="w-full cursor-pointer"
              style={{ accentColor: 'var(--theme-accent)' }}
            />
          </div>

          <div className="p-3.5 rounded-2xl bg-black/25 border border-white/10 flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-extrabold">
              <span className="text-white">Efecto 3D / Virtualizador</span>
              <span className="font-mono-tabular" style={{ color: 'var(--theme-accent)' }}>
                {Math.round(eqState.stereoWidth * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={eqState.stereoWidth}
              onChange={e =>
                setEqState(prev => ({
                  ...prev,
                  enabled: true,
                  stereoWidth: Number(e.target.value)
                }))
              }
              className="w-full cursor-pointer"
              style={{ accentColor: 'var(--theme-accent)' }}
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-1">
          <button
            type="button"
            onClick={() =>
              setEqState(prev => ({
                ...prev,
                presetName: 'Plano (Referencia)',
                bassBoost: 0,
                stereoWidth: 0,
                bands: prev.bands.map(b => ({ ...b, gain: 0 }))
              }))
            }
            className="px-4 py-2 rounded-xl text-xs font-extrabold text-slate-300 hover:bg-white/10 cursor-pointer"
          >
            Restablecer
          </button>
          <button
            type="button"
            onClick={() => setShowEqualizerModal(false)}
            className="px-6 py-2.5 rounded-xl text-xs font-extrabold cursor-pointer shadow-lg"
            style={{
              backgroundColor: 'var(--theme-accent)',
              color: '#041019'
            }}
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};

interface PlayerTagEditorModalProps {
  editingTrack: Track | null;
  setEditingTrack: React.Dispatch<React.SetStateAction<Track | null>>;
  onSaveTrackTags: (e: React.FormEvent) => void;
  onTriggerCoverUpload: () => void;
}

export const PlayerTagEditorModal: React.FC<PlayerTagEditorModalProps> = ({
  editingTrack,
  setEditingTrack,
  onSaveTrackTags,
  onTriggerCoverUpload
}) => {
  if (!editingTrack) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <form
        onSubmit={onSaveTrackTags}
        className="w-full max-w-lg rounded-2xl border p-6 flex flex-col gap-4 max-h-[92vh] overflow-y-auto"
        style={{
          backgroundColor: 'var(--theme-surface)',
          borderColor: 'var(--theme-border)',
          color: 'var(--theme-text)'
        }}
      >
        <div
          className="flex items-center justify-between border-b pb-3"
          style={{ borderColor: 'var(--theme-border)' }}
        >
          <h2 className="text-lg font-bold font-display">
            Editor de Etiquetas ID3 y Portada
          </h2>
          <button
            type="button"
            onClick={() => setEditingTrack(null)}
            className="p-1 cursor-pointer"
            style={{ color: 'var(--theme-muted)' }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div
          className="flex items-center gap-4 p-3 rounded-xl border"
          style={{ borderColor: 'var(--theme-border)', backgroundColor: 'var(--theme-bg)' }}
        >
          <CoverArt
            src={editingTrack.coverUrl}
            alt={editingTrack.title}
            dominantColor={editingTrack.dominantColor}
            shape="rounded"
            sizeClass="w-16 h-16"
          />
          <div className="flex flex-col gap-2">
            <span className="text-xs font-bold">Portada de la canción</span>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={onTriggerCoverUpload}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                style={{
                  backgroundColor: 'var(--theme-accent)',
                  color: 'var(--theme-accent-fg)'
                }}
              >
                <ImagePlus className="w-3.5 h-3.5" />
                Cambiar imagen
              </button>
              {editingTrack.coverUrl && (
                <button
                  type="button"
                  onClick={() => setEditingTrack({ ...editingTrack, coverUrl: '' })}
                  className="px-2.5 py-1.5 rounded-lg text-xs border cursor-pointer"
                  style={{ borderColor: 'var(--theme-border)', color: 'var(--theme-muted)' }}
                >
                  Quitar portada
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label
              className="block text-xs font-medium mb-1"
              style={{ color: 'var(--theme-muted)' }}
            >
              Título
            </label>
            <input
              type="text"
              required
              value={editingTrack.title}
              onChange={e => setEditingTrack({ ...editingTrack, title: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border outline-none"
              style={{
                backgroundColor: 'var(--theme-bg)',
                borderColor: 'var(--theme-border)'
              }}
            />
          </div>
          <div>
            <label
              className="block text-xs font-medium mb-1"
              style={{ color: 'var(--theme-muted)' }}
            >
              Artista
            </label>
            <input
              type="text"
              required
              value={editingTrack.artist}
              onChange={e => setEditingTrack({ ...editingTrack, artist: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border outline-none"
              style={{
                backgroundColor: 'var(--theme-bg)',
                borderColor: 'var(--theme-border)'
              }}
            />
          </div>
          <div>
            <label
              className="block text-xs font-medium mb-1"
              style={{ color: 'var(--theme-muted)' }}
            >
              Álbum
            </label>
            <input
              type="text"
              value={editingTrack.album}
              onChange={e => setEditingTrack({ ...editingTrack, album: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border outline-none"
              style={{
                backgroundColor: 'var(--theme-bg)',
                borderColor: 'var(--theme-border)'
              }}
            />
          </div>
          <div>
            <label
              className="block text-xs font-medium mb-1"
              style={{ color: 'var(--theme-muted)' }}
            >
              Género
            </label>
            <input
              type="text"
              value={editingTrack.genre}
              onChange={e => setEditingTrack({ ...editingTrack, genre: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border outline-none"
              style={{
                backgroundColor: 'var(--theme-bg)',
                borderColor: 'var(--theme-border)'
              }}
            />
          </div>
        </div>

        <div>
          <label
            className="block text-xs font-medium mb-1"
            style={{ color: 'var(--theme-muted)' }}
          >
            Letra sincronizada (una línea por verso)
          </label>
          <textarea
            rows={4}
            value={(editingTrack.lyrics || []).join('\n')}
            onChange={e =>
              setEditingTrack({
                ...editingTrack,
                lyrics: e.target.value.split('\n').filter(Boolean)
              })
            }
            className="w-full px-3 py-2 text-xs rounded-lg border outline-none"
            style={{
              backgroundColor: 'var(--theme-bg)',
              borderColor: 'var(--theme-border)'
            }}
          />
        </div>

        <div className="flex items-center justify-end gap-2 pt-2">
          <button
            type="button"
            onClick={() => setEditingTrack(null)}
            className="px-4 py-2 rounded-lg text-xs font-medium border cursor-pointer"
            style={{ borderColor: 'var(--theme-border)', color: 'var(--theme-muted)' }}
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-accent)',
              color: 'var(--theme-accent-fg)'
            }}
          >
            Guardar Cambios
          </button>
        </div>
      </form>
    </div>
  );
};
