import React from 'react';
import {
  ChevronDown,
  FastForward,
  Heart,
  ImagePlus,
  ListMusic,
  MoreVertical,
  Music2,
  Rewind,
  Share2,
  Volume2,
  VolumeX
} from 'lucide-react';
import { EqualizerState, ThemeConfig, Track } from '../../types/music';
import { formatDuration } from '../../utils/formatters';
import { ActiveModal } from '../PlayerModals';

interface PlayerCoverSectionProps {
  currentTrack: Track;
  themeConfig: ThemeConfig;
  adaptiveColor: string;
  eqState: EqualizerState;
  currentTime: number;
  progressPercent: number;
  currentQueuePosition: number;
  queueLength: number;
  volume: number;
  isMuted: boolean;
  swipeOffsetPx: number;
  coverSeekBadge: '-10s' | '+10s' | null;
  coverHeartBurst: 'favorite' | 'unfavorite' | null;
  showCoverVolumeBar: boolean;
  onCoverPointerTap: (e: React.MouseEvent<HTMLDivElement>) => void;
  onCoverTouchStart: (e: React.TouchEvent<HTMLDivElement>) => void;
  onCoverTouchMove: (e: React.TouchEvent<HTMLDivElement>) => void;
  onCoverTouchEnd: (e: React.TouchEvent<HTMLDivElement>) => void;
  onCollapsePlayer: (e: React.MouseEvent) => void;
  onSpeakerMuteClick: (e: React.MouseEvent) => void;
  onFavoriteButtonClick: (e: React.MouseEvent) => void;
  onShareTrack: (mode: 'hashtag' | 'native') => void;
  onOpenQueue: () => void;
  onTriggerCoverUpload: () => void;
  setActiveModal: React.Dispatch<React.SetStateAction<ActiveModal>>;
}

export const PlayerCoverSection: React.FC<PlayerCoverSectionProps> = ({
  currentTrack,
  themeConfig,
  adaptiveColor,
  eqState,
  currentTime,
  progressPercent,
  currentQueuePosition,
  queueLength,
  volume,
  isMuted,
  swipeOffsetPx,
  coverSeekBadge,
  coverHeartBurst,
  showCoverVolumeBar,
  onCoverPointerTap,
  onCoverTouchStart,
  onCoverTouchMove,
  onCoverTouchEnd,
  onCollapsePlayer,
  onSpeakerMuteClick,
  onFavoriteButtonClick,
  onShareTrack,
  onOpenQueue,
  onTriggerCoverUpload,
  setActiveModal
}) => {
  return (
    <>
      {themeConfig.playerSkin === 'vinyl-circle' && (
        <div className="relative z-20 flex flex-col gap-2 px-4 pt-4 pb-1">
          <div className="flex items-center justify-between gap-3">
            <button
              onClick={onCollapsePlayer}
              aria-label="Contraer reproductor"
              className="w-10 h-10 rounded-full flex items-center justify-center text-white hover:bg-white/10 cursor-pointer shrink-0"
            >
              <ChevronDown className="w-6 h-6" />
            </button>
            <div className="min-w-0 flex-1">
              <h2 className="text-lg font-extrabold font-display text-white truncate">
                {currentTrack.title}
              </h2>
              <p className="text-xs font-bold text-white/80 truncate">
                {currentTrack.artist}
              </p>
            </div>
            <button
              onClick={() => setActiveModal('action-sheet')}
              aria-label="Abrir menú de herramientas"
              className="w-10 h-10 rounded-full flex items-center justify-center text-white hover:bg-white/10 cursor-pointer shrink-0"
            >
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center justify-between px-2 pt-1 text-white/90">
            <button
              onClick={onSpeakerMuteClick}
              aria-label={isMuted ? 'Activar sonido' : 'Silenciar'}
              className="p-2 rounded-full hover:bg-white/10 cursor-pointer"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-5 h-5 text-rose-300" />
              ) : (
                <Volume2 className="w-5 h-5" />
              )}
            </button>
            <button
              onClick={onFavoriteButtonClick}
              aria-label="Favorito"
              className="p-2 rounded-full hover:bg-white/10 cursor-pointer"
            >
              <Heart
                className={`w-5 h-5 ${
                  currentTrack.isFavorite ? 'fill-white text-white' : ''
                }`}
              />
            </button>
            <span className="px-3 py-1 rounded-lg bg-black/25 text-xs font-extrabold font-mono-tabular">
              {currentQueuePosition}/{queueLength}
            </span>
            <button
              onClick={() => onShareTrack('native')}
              aria-label="Compartir"
              className="p-2 rounded-full hover:bg-white/10 cursor-pointer"
            >
              <Share2 className="w-5 h-5" />
            </button>
            <button
              onClick={onOpenQueue}
              aria-label="Cola de reproducción"
              className="p-2 rounded-full hover:bg-white/10 cursor-pointer"
            >
              <ListMusic className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {themeConfig.playerSkin === 'framed-card' && (
        <div className="relative z-20 flex items-center justify-between px-5 pt-4 pb-1 text-white">
          <button
            onClick={onCollapsePlayer}
            aria-label="Contraer reproductor"
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 cursor-pointer"
          >
            <ChevronDown className="w-6 h-6" />
          </button>
          <button
            onClick={onSpeakerMuteClick}
            aria-label={isMuted ? 'Activar sonido' : 'Silenciar'}
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 cursor-pointer"
          >
            {isMuted || volume === 0 ? (
              <VolumeX className="w-5 h-5 text-rose-300" />
            ) : (
              <Volume2 className="w-5 h-5" />
            )}
          </button>
          <button
            onClick={() => onShareTrack('native')}
            aria-label="Compartir"
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 cursor-pointer"
          >
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setActiveModal('action-sheet')}
            aria-label="Abrir menú de herramientas"
            className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 cursor-pointer"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Top Half: Cover Art Area */}
      <div
        onClick={onCoverPointerTap}
        onTouchStart={onCoverTouchStart}
        onTouchMove={onCoverTouchMove}
        onTouchEnd={onCoverTouchEnd}
        className={`relative w-full overflow-hidden shrink-0 cursor-pointer ${
          themeConfig.playerSkin === 'vinyl-circle' ||
          themeConfig.playerSkin === 'circle-cobalt'
            ? 'aspect-square flex items-center justify-center p-6'
            : themeConfig.playerSkin === 'stacked-cards'
              ? 'aspect-square flex items-center justify-center px-6 pt-12 pb-3'
              : themeConfig.playerSkin === 'framed-card'
                ? 'aspect-square flex items-center justify-center px-5 py-2'
                : 'aspect-square'
        }`}
      >
        <div
          className={`transition-transform duration-150 ${
            themeConfig.playerSkin === 'vinyl-circle'
              ? 'w-64 h-64 sm:w-72 sm:h-72 rounded-full p-3 bg-white/10 border border-white/20 shadow-2xl relative flex items-center justify-center'
              : themeConfig.playerSkin === 'circle-cobalt'
                ? 'w-68 h-68 sm:w-72 sm:h-72 rounded-full relative flex items-center justify-center p-3'
                : themeConfig.playerSkin === 'stacked-cards'
                  ? 'w-full max-w-[290px] relative pt-4'
                  : themeConfig.playerSkin === 'framed-card'
                    ? 'w-full h-full rounded-2xl overflow-hidden shadow-2xl'
                    : 'w-full h-full'
          }`}
          style={{
            transform: `translateX(${swipeOffsetPx}px)`
          }}
        >
          {themeConfig.playerSkin === 'circle-cobalt' && (
            <svg
              className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none z-20"
              viewBox="0 0 100 100"
            >
              <circle
                cx="50"
                cy="50"
                r="47"
                fill="none"
                stroke="rgba(255,255,255,0.22)"
                strokeWidth="1.6"
              />
              <circle
                cx="50"
                cy="50"
                r="47"
                fill="none"
                stroke="#ffffff"
                strokeWidth="2"
                strokeDasharray={2 * Math.PI * 47}
                strokeDashoffset={
                  2 *
                  Math.PI *
                  47 *
                  (1 - Math.max(0, Math.min(100, progressPercent)) / 100)
                }
                strokeLinecap="round"
              />
            </svg>
          )}

          {themeConfig.playerSkin === 'stacked-cards' && (
            <>
              <div
                className="mx-7 h-2.5 rounded-t-lg opacity-55"
                style={{ backgroundColor: adaptiveColor }}
              />
              <div
                className="mx-3.5 h-2.5 rounded-t-lg opacity-80"
                style={{ backgroundColor: adaptiveColor }}
              />
            </>
          )}

          <div
            className={
              themeConfig.playerSkin === 'stacked-cards'
                ? 'w-full aspect-square rounded-2xl overflow-hidden shadow-2xl'
                : themeConfig.playerSkin === 'circle-cobalt'
                  ? 'w-full h-full rounded-full overflow-hidden shadow-2xl relative'
                  : 'w-full h-full'
            }
          >
            {currentTrack.coverUrl ? (
              <img
                src={currentTrack.coverUrl}
                alt={currentTrack.title}
                referrerPolicy="no-referrer"
                draggable={false}
                className={`w-full h-full object-cover pointer-events-none ${
                  themeConfig.playerSkin === 'vinyl-circle' ||
                  themeConfig.playerSkin === 'circle-cobalt'
                    ? 'rounded-full'
                    : ''
                }`}
              />
            ) : (
              <div
                className={`w-full h-full flex flex-col items-center justify-center gap-3 text-white/85 p-6 text-center bg-[#3b4d5e] ${
                  themeConfig.playerSkin === 'vinyl-circle' ||
                  themeConfig.playerSkin === 'circle-cobalt'
                    ? 'rounded-full'
                    : ''
                }`}
              >
                <Music2 className="w-20 h-20 text-[#132230] stroke-[2]" />
                <button
                  type="button"
                  onClick={e => {
                    e.stopPropagation();
                    onTriggerCoverUpload();
                  }}
                  className="px-4 py-2 rounded-full bg-black/35 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1.5 border border-white/20 cursor-pointer"
                >
                  <ImagePlus className="w-4 h-4" />
                  Elegir portada
                </button>
              </div>
            )}

            {themeConfig.playerSkin === 'circle-cobalt' && (
              <div className="absolute bottom-0 inset-x-0 h-11 bg-black/50 backdrop-blur-[2px] flex items-center justify-center pointer-events-none">
                <span className="text-xs font-extrabold font-mono-tabular text-white">
                  {formatDuration(currentTime)}
                </span>
              </div>
            )}
          </div>

          {themeConfig.playerSkin === 'vinyl-circle' && (
            <div
              className="w-12 h-12 rounded-full border-2 border-white/20 absolute pointer-events-none shadow-inner"
              style={{
                backgroundColor: `color-mix(in srgb, ${adaptiveColor} 50%, #101914)`
              }}
            />
          )}
        </div>

        {themeConfig.playerSkin === 'full-bleed-dark' && (
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: `linear-gradient(180deg, rgba(0,0,0,0.2) 0%, transparent 48%, color-mix(in srgb, ${adaptiveColor} 55%, #0b140f) 100%)`
            }}
          />
        )}

        {coverSeekBadge === '-10s' && (
          <div className="absolute inset-y-0 left-0 w-1/2 bg-black/45 backdrop-blur-xs rounded-r-full flex flex-col items-center justify-center text-white animate-pulse pointer-events-none z-20">
            <Rewind className="w-10 h-10 mb-1 fill-current" />
            <span className="text-base font-extrabold font-mono-tabular">-10s</span>
          </div>
        )}

        {coverSeekBadge === '+10s' && (
          <div className="absolute inset-y-0 right-0 w-1/2 bg-black/45 backdrop-blur-xs rounded-l-full flex flex-col items-center justify-center text-white animate-pulse pointer-events-none z-20">
            <FastForward className="w-10 h-10 mb-1 fill-current" />
            <span className="text-base font-extrabold font-mono-tabular">+10s</span>
          </div>
        )}

        {coverHeartBurst && (
          <div className="absolute inset-0 bg-black/15 backdrop-blur-[3px] flex items-center justify-center pointer-events-none z-20">
            <Heart
              className={`w-24 h-24 animate-heart-bounce drop-shadow-[0_10px_24px_rgba(0,0,0,0.55)] ${
                coverHeartBurst === 'favorite'
                  ? 'text-rose-500 fill-rose-500'
                  : 'text-white/90 fill-white/25'
              }`}
            />
          </div>
        )}

        {showCoverVolumeBar && (
          <div className="absolute right-5 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-2 px-2.5 py-3.5 rounded-2xl bg-black/65 backdrop-blur-md border border-white/15 shadow-2xl pointer-events-none">
            <span className="text-[11px] font-extrabold font-mono-tabular text-white">
              {isMuted ? 0 : Math.round(volume * 100)}%
            </span>
            <div className="w-2 h-32 rounded-full bg-white/20 overflow-hidden flex flex-col justify-end">
              <div
                className="w-full rounded-full transition-all duration-75"
                style={{
                  height: `${isMuted ? 0 : Math.round(volume * 100)}%`,
                  backgroundColor: 'var(--theme-accent)'
                }}
              />
            </div>
            {isMuted || volume === 0 ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-white" />
            )}
          </div>
        )}

        {themeConfig.playerSkin !== 'vinyl-circle' &&
          themeConfig.playerSkin !== 'framed-card' && (
            <>
              <button
                onClick={onCollapsePlayer}
                aria-label="Contraer reproductor"
                className="absolute top-4 left-4 w-10 h-10 rounded-full bg-black/25 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/40 transition-colors cursor-pointer z-10"
              >
                <ChevronDown className="w-6 h-6" />
              </button>

              {themeConfig.playerSkin === 'circle-cobalt' ? (
                <span className="absolute top-5 left-1/2 -translate-x-1/2 text-sm font-extrabold font-mono-tabular text-white z-10">
                  {currentQueuePosition}/{queueLength}
                </span>
              ) : (
                <button
                  onClick={e => {
                    e.stopPropagation();
                    setActiveModal('speed-picker');
                  }}
                  className="absolute top-4 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full bg-black/35 backdrop-blur-md text-white text-xs font-mono-tabular font-bold flex items-center gap-1.5 cursor-pointer z-10"
                >
                  <span>{eqState.playbackRate.toFixed(1)}x</span>
                  <span>·</span>
                  <span>Tono {eqState.pitchRate.toFixed(1)}</span>
                </button>
              )}

              <button
                onClick={e => {
                  e.stopPropagation();
                  setActiveModal('action-sheet');
                }}
                aria-label="Abrir menú de herramientas"
                className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/25 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/40 transition-colors cursor-pointer z-10"
              >
                <MoreVertical className="w-5 h-5" />
              </button>
            </>
          )}
      </div>
    </>
  );
};
