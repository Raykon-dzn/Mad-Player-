import React, { useRef } from 'react';
import { ListMusic, Music2, Pause, Play } from 'lucide-react';
import { Track } from '../../types/music';

interface MiniPlayerProps {
  currentTrack?: Track;
  mobilePlayerExpanded: boolean;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onExpandPlayer: () => void;
  onOpenQueue: () => void;
  onTogglePlayPause: () => void;
  onNextTrack: (fromAutoEnd?: boolean) => void;
  onPrevTrack: () => void;
  showToast: (msg: string) => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({
  currentTrack,
  mobilePlayerExpanded,
  isPlaying,
  currentTime,
  duration,
  onExpandPlayer,
  onOpenQueue,
  onTogglePlayPause,
  onNextTrack,
  onPrevTrack,
  showToast
}) => {
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);

  if (!currentTrack || mobilePlayerExpanded) return null;

  const progressPercent = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length !== 1) return;
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) return;
    const endX = e.changedTouches[0]?.clientX ?? touchStartXRef.current;
    const endY = e.changedTouches[0]?.clientY ?? touchStartYRef.current;
    const dx = endX - touchStartXRef.current;
    const dy = endY - touchStartYRef.current;

    touchStartXRef.current = null;
    touchStartYRef.current = null;

    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.3) {
      if (dx < 0) {
        onNextTrack(false);
        showToast('Siguiente canción »');
      } else {
        onPrevTrack();
        showToast('« Canción anterior');
      }
    }
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 flex flex-col select-none"
      style={{
        backgroundColor: '#101d29',
        borderTop: '1px solid rgba(255,255,255,0.06)'
      }}
    >
      <div className="px-3.5 py-2.5 flex items-center justify-between gap-3">
        <div
          onClick={onExpandPlayer}
          className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
        >
          <div className="w-11 h-11 rounded-lg overflow-hidden shrink-0 bg-[#3b4d5e] flex items-center justify-center">
            {currentTrack.coverUrl ? (
              <img
                src={currentTrack.coverUrl}
                alt={currentTrack.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : (
              <Music2 className="w-6 h-6 text-[#132230]" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 min-w-0">
              <p className="text-sm font-extrabold text-white truncate">{currentTrack.title}</p>
              {currentTrack.audioUnavailable && (
                <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0">
                  archivo no disponible
                </span>
              )}
            </div>
            <p className="text-xs font-bold text-[#6e8499] truncate">
              {currentTrack.artist} • {currentTrack.album}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onTogglePlayPause}
            aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
            className="w-10 h-10 flex items-center justify-center text-white cursor-pointer"
          >
            {isPlaying ? (
              <Pause className="w-6 h-6 fill-current" />
            ) : (
              <Play className="w-6 h-6 fill-current" />
            )}
          </button>

          <button
            onClick={onOpenQueue}
            aria-label="Cola de reproducción"
            className="w-10 h-10 flex items-center justify-center text-white cursor-pointer"
          >
            <ListMusic className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="w-full h-[2px] bg-white/10 overflow-hidden">
        <div
          className="h-full transition-all duration-150"
          style={{
            width: `${progressPercent}%`,
            backgroundColor: 'var(--theme-accent)'
          }}
        />
      </div>
    </div>
  );
};
