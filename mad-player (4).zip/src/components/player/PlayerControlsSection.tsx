import React from 'react';
import {
  Heart,
  ListMusic,
  Moon,
  Pause,
  Play,
  Repeat,
  RotateCcw,
  Share2,
  Shuffle,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  X
} from 'lucide-react';
import { EqualizerState, ThemeConfig, Track } from '../../types/music';
import { formatDuration } from '../../utils/formatters';
import { CoverArt } from '../CoverArt';
import { AudioVisualizer } from '../AudioVisualizer';
import { ActiveModal } from '../PlayerModals';

interface SkinControlsProps {
  currentTrack: Track;
  themeConfig: ThemeConfig;
  adaptiveColor: string;
  isLightLowerSkin: boolean;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  progressPercent: number;
  currentQueuePosition: number;
  queueLength: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  setIsShuffle: React.Dispatch<React.SetStateAction<boolean>>;
  repeatMode: 'off' | 'all' | 'one';
  setRepeatMode: React.Dispatch<React.SetStateAction<'off' | 'all' | 'one'>>;
  sleepSecondsRemaining: number | null;
  sleepEndOfTrack: boolean;
  isSleepTimerFading: boolean;
  onCancelSleepTimer: () => void;
  onLowerBodyTap: (e: React.MouseEvent<HTMLDivElement>) => void;
  onFavoriteButtonClick: (e: React.MouseEvent) => void;
  onSpeakerMuteClick: (e: React.MouseEvent) => void;
  onOpenQueue: () => void;
  onSeek: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onDirectSeek: (seconds: number) => void;
  onTogglePlayPause: () => void;
  onNextTrack: (fromAutoEnd?: boolean) => void;
  onPrevTrack: () => void;
  onShareTrack: (mode: 'hashtag' | 'native') => void;
  setActiveModal: React.Dispatch<React.SetStateAction<ActiveModal>>;
}

export const PlayerSkinControlsSection: React.FC<SkinControlsProps> = ({
  currentTrack,
  themeConfig,
  adaptiveColor,
  isLightLowerSkin,
  isPlaying,
  currentTime,
  duration,
  progressPercent,
  currentQueuePosition,
  queueLength,
  volume,
  isMuted,
  isShuffle,
  setIsShuffle,
  repeatMode,
  setRepeatMode,
  sleepSecondsRemaining,
  sleepEndOfTrack,
  isSleepTimerFading,
  onCancelSleepTimer,
  onLowerBodyTap,
  onFavoriteButtonClick,
  onSpeakerMuteClick,
  onOpenQueue,
  onSeek,
  onDirectSeek,
  onTogglePlayPause,
  onNextTrack,
  onPrevTrack,
  onShareTrack,
  setActiveModal
}) => {
  return (
    <>
      {themeConfig.playerSkin === 'muzio-classic' && (
        <div
          onClick={e => {
            const rect = e.currentTarget.getBoundingClientRect();
            const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            onDirectSeek(ratio * (duration || 1));
          }}
          className="relative h-8 w-full flex items-center justify-between px-3 cursor-pointer select-none"
          style={{
            backgroundColor: `color-mix(in srgb, ${adaptiveColor} 28%, #cedbd3)`
          }}
        >
          <div
            className="absolute inset-y-0 left-0 pointer-events-none"
            style={{
              width: `${progressPercent}%`,
              backgroundColor: `color-mix(in srgb, ${adaptiveColor} 46%, #b2c5b9)`
            }}
          />
          <div
            className="absolute inset-y-0 w-1.5 -translate-x-1/2 pointer-events-none"
            style={{
              left: `${progressPercent}%`,
              backgroundColor: `color-mix(in srgb, ${adaptiveColor} 78%, #0e2418)`
            }}
          />
          <span className="relative z-10 text-xs font-extrabold font-mono-tabular">
            {formatDuration(currentTime)}
          </span>
          <span className="relative z-10 text-xs font-extrabold font-mono-tabular">
            {formatDuration(duration)}
          </span>
        </div>
      )}

      <div
        onClick={onLowerBodyTap}
        className="flex-1 flex flex-col justify-between px-6 py-5 cursor-default"
      >
        {(themeConfig.playerSkin === 'stacked-cards' ||
          themeConfig.playerSkin === 'framed-card') && (
          <div className="flex flex-col gap-1.5">
            <input
              type="range"
              min={0}
              max={duration || 1}
              step={0.5}
              value={currentTime}
              onChange={onSeek}
              className="w-full cursor-pointer"
              style={{
                accentColor:
                  themeConfig.playerSkin === 'stacked-cards'
                    ? `color-mix(in srgb, ${adaptiveColor} 75%, #162b1f)`
                    : '#ffffff'
              }}
              aria-label="Progreso de la pista"
            />
            <div className="flex items-center justify-between text-xs font-extrabold font-mono-tabular opacity-90">
              <span>{formatDuration(currentTime)}</span>
              <span>{formatDuration(duration)}</span>
            </div>
          </div>
        )}

        {themeConfig.playerSkin !== 'vinyl-circle' && (
          <div className="flex items-center justify-between gap-3">
            {themeConfig.playerSkin !== 'circle-cobalt' ? (
              <button
                onClick={onFavoriteButtonClick}
                aria-label="Favorito"
                className="w-11 h-11 rounded-full flex items-center justify-center cursor-pointer"
              >
                <Heart
                  className={`w-6 h-6 ${currentTrack.isFavorite ? 'fill-current' : ''}`}
                />
              </button>
            ) : (
              <div className="w-8" />
            )}

            <div className="text-center min-w-0 flex-1 px-2">
              <h2 className="text-xl font-extrabold font-display tracking-tight truncate">
                {currentTrack.title}
              </h2>
              <p
                className={`text-sm font-bold truncate mt-0.5 ${
                  isLightLowerSkin ? 'opacity-85' : 'text-white/85'
                }`}
              >
                {currentTrack.artist}
              </p>
              {(sleepSecondsRemaining !== null || sleepEndOfTrack) && (
                <div className="mt-1.5 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/30 text-white text-[11px] font-mono-tabular font-bold border border-white/15">
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      setActiveModal('sleep-timer');
                    }}
                    className="flex items-center gap-1 cursor-pointer"
                  >
                    <Moon className="w-3 h-3 text-sky-300" />
                    <span>
                      {sleepEndOfTrack
                        ? `Fin de pista · ${formatDuration(sleepSecondsRemaining ?? 0)}`
                        : `${formatDuration(sleepSecondsRemaining ?? 0)}${
                            isSleepTimerFading ? ' (Fade-out)' : ''
                          }`}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      onCancelSleepTimer();
                    }}
                    aria-label="Cancelar temporizador"
                    className="p-0.5 rounded-full hover:bg-white/20 text-rose-300 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

            {themeConfig.playerSkin !== 'circle-cobalt' ? (
              <button
                onClick={onOpenQueue}
                aria-label="Ver cola de reproducción"
                className="w-11 h-11 rounded-full flex items-center justify-center cursor-pointer"
              >
                <ListMusic className="w-6 h-6" />
              </button>
            ) : (
              <div className="w-8" />
            )}
          </div>
        )}

        {(themeConfig.playerSkin === 'full-bleed-dark' ||
          themeConfig.playerSkin === 'vinyl-circle') && (
          <div className="flex flex-col gap-1.5 my-1">
            <input
              type="range"
              min={0}
              max={duration || 1}
              step={0.5}
              value={currentTime}
              onChange={onSeek}
              className="w-full cursor-pointer"
              style={{ accentColor: '#ffffff' }}
              aria-label="Progreso de la pista"
            />
            <div className="flex items-center justify-between text-xs font-extrabold font-mono-tabular text-white/90">
              <span>{formatDuration(currentTime)}</span>
              <span>{formatDuration(duration)}</span>
            </div>
          </div>
        )}

        {/* Transport Controls Row */}
        <div className="flex items-center justify-between px-1 my-2">
          <button
            onClick={() =>
              setRepeatMode(prev =>
                prev === 'off' ? 'all' : prev === 'all' ? 'one' : 'off'
              )
            }
            aria-label="Modo repetición"
            className="w-11 h-11 flex items-center justify-center relative cursor-pointer"
            style={{ opacity: repeatMode === 'off' ? 0.55 : 1 }}
          >
            <Repeat className="w-5 h-5" />
            {repeatMode === 'one' && (
              <span className="text-[9px] font-mono-tabular font-bold absolute top-1 right-1">
                1
              </span>
            )}
          </button>

          <button
            onClick={onPrevTrack}
            aria-label="Anterior"
            className="w-12 h-12 flex items-center justify-center cursor-pointer"
          >
            <SkipBack className="w-6 h-6 fill-current" />
          </button>

          <div
            className={
              themeConfig.playerSkin === 'full-bleed-dark' ||
              themeConfig.playerSkin === 'stacked-cards' ||
              themeConfig.playerSkin === 'framed-card'
                ? 'p-2 rounded-full'
                : ''
            }
            style={
              themeConfig.playerSkin === 'full-bleed-dark' ||
              themeConfig.playerSkin === 'framed-card'
                ? { backgroundColor: 'rgba(255,255,255,0.1)' }
                : themeConfig.playerSkin === 'stacked-cards'
                  ? {
                      backgroundColor: `color-mix(in srgb, ${adaptiveColor} 20%, transparent)`
                    }
                  : undefined
            }
          >
            <button
              onClick={onTogglePlayPause}
              aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
              className={`w-16 h-16 flex items-center justify-center shadow-xl transition-transform active:scale-95 cursor-pointer ${
                themeConfig.playerSkin === 'vinyl-circle'
                  ? 'rounded-2xl bg-white text-slate-900'
                  : themeConfig.playerSkin === 'circle-cobalt'
                    ? 'rounded-full bg-white text-slate-900'
                    : 'rounded-full text-white'
              }`}
              style={
                themeConfig.playerSkin === 'vinyl-circle' ||
                themeConfig.playerSkin === 'circle-cobalt'
                  ? undefined
                  : {
                      backgroundColor: `color-mix(in srgb, ${adaptiveColor} 74%, #112419)`,
                      color: '#ffffff'
                    }
              }
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 fill-current" />
              ) : (
                <Play className="w-7 h-7 fill-current ml-0.5" />
              )}
            </button>
          </div>

          <button
            onClick={() => onNextTrack(false)}
            aria-label="Siguiente"
            className="w-12 h-12 flex items-center justify-center cursor-pointer"
          >
            <SkipForward className="w-6 h-6 fill-current" />
          </button>

          <button
            onClick={() => setIsShuffle(!isShuffle)}
            aria-label="Aleatorio"
            className="w-11 h-11 flex items-center justify-center cursor-pointer"
            style={{ opacity: isShuffle ? 1 : 0.55 }}
          >
            <Shuffle className="w-5 h-5" />
          </button>
        </div>

        {themeConfig.playerSkin === 'circle-cobalt' && (
          <div className="flex items-center justify-between px-2 pt-2 text-white">
            <button
              onClick={onSpeakerMuteClick}
              aria-label={isMuted ? 'Activar sonido' : 'Silenciar'}
              className="p-2 cursor-pointer"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-5 h-5 text-rose-300" />
              ) : (
                <Volume2 className="w-5 h-5" />
              )}
            </button>
            <button
              onClick={onFavoriteButtonClick}
              aria-label="Favorito"
              className="p-2 cursor-pointer"
            >
              <Heart
                className={`w-5 h-5 ${currentTrack.isFavorite ? 'fill-current' : ''}`}
              />
            </button>
            <button
              onClick={() => onShareTrack('native')}
              aria-label="Compartir pista"
              className="p-2 cursor-pointer"
            >
              <Share2 className="w-5 h-5" />
            </button>
            <button
              onClick={onOpenQueue}
              aria-label="Cola de reproducción"
              className="p-2 cursor-pointer"
            >
              <ListMusic className="w-5 h-5" />
            </button>
          </div>
        )}

        {(themeConfig.playerSkin === 'muzio-classic' ||
          themeConfig.playerSkin === 'full-bleed-dark' ||
          themeConfig.playerSkin === 'stacked-cards') && (
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={onSpeakerMuteClick}
              aria-label={isMuted ? 'Activar sonido' : 'Silenciar'}
              className="p-2 rounded-full hover:bg-black/10 cursor-pointer"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-5 h-5 text-rose-500" />
              ) : (
                <Volume2 className="w-5 h-5" />
              )}
            </button>

            <span
              className={`text-xs font-extrabold font-mono-tabular tracking-wide px-3 py-1 rounded-full ${
                themeConfig.playerSkin === 'full-bleed-dark'
                  ? 'bg-black/25 text-white'
                  : ''
              }`}
            >
              {currentQueuePosition}/{queueLength}
            </span>

            <button
              onClick={() => onShareTrack('native')}
              aria-label="Compartir pista"
              className="p-2 rounded-full hover:bg-black/10 cursor-pointer"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </>
  );
};

interface StudioConsoleNowPlayingProps {
  currentTrack: Track;
  themeConfig: ThemeConfig;
  activeAccentColor: string;
  eqState: EqualizerState;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  setIsShuffle: React.Dispatch<React.SetStateAction<boolean>>;
  repeatMode: 'off' | 'all' | 'one';
  setRepeatMode: React.Dispatch<React.SetStateAction<'off' | 'all' | 'one'>>;
  loopA: number | null;
  loopB: number | null;
  sleepSecondsRemaining: number | null;
  sleepEndOfTrack: boolean;
  isSleepTimerFading: boolean;
  onCancelSleepTimer: () => void;
  onToggleFavorite: (trackId: string, e?: React.MouseEvent) => void;
  onSeek: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onTogglePlayPause: () => void;
  onNextTrack: (fromAutoEnd?: boolean) => void;
  onPrevTrack: () => void;
  onVolumeChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onToggleMute: () => void;
  onToggleLoopPoint: () => void;
  setActiveModal: React.Dispatch<React.SetStateAction<ActiveModal>>;
}

export const PlayerStudioNowPlayingSection: React.FC<StudioConsoleNowPlayingProps> = ({
  currentTrack,
  themeConfig,
  activeAccentColor,
  eqState,
  isPlaying,
  currentTime,
  duration,
  volume,
  isMuted,
  isShuffle,
  setIsShuffle,
  repeatMode,
  setRepeatMode,
  loopA,
  loopB,
  sleepSecondsRemaining,
  sleepEndOfTrack,
  isSleepTimerFading,
  onCancelSleepTimer,
  onToggleFavorite,
  onSeek,
  onTogglePlayPause,
  onNextTrack,
  onPrevTrack,
  onVolumeChange,
  onToggleMute,
  onToggleLoopPoint,
  setActiveModal
}) => {
  return (
    <>
      <div className="flex justify-center py-2">
        <CoverArt
          src={currentTrack.coverUrl}
          alt={currentTrack.title}
          dominantColor={currentTrack.dominantColor}
          secondaryColor={currentTrack.secondaryColor}
          shape={themeConfig.coverShape}
          isPlaying={isPlaying}
          sizeClass="w-56 h-56 sm:w-64 sm:h-64 shadow-xl"
        />
      </div>

      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <h2 className="text-xl font-bold font-display truncate">
              {currentTrack.title}
            </h2>
            {currentTrack.audioUnavailable && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0">
                archivo no disponible
              </span>
            )}
          </div>
          <p
            className="text-sm truncate mt-0.5"
            style={{ color: 'var(--theme-muted)' }}
          >
            {currentTrack.artist} · {currentTrack.album}
          </p>
          <p
            className="text-xs font-mono-tabular mt-1"
            style={{ color: 'var(--theme-muted)' }}
          >
            {currentTrack.bpm} BPM · {eqState.playbackRate.toFixed(1)}x · Tono{' '}
            {eqState.pitchRate.toFixed(1)}
          </p>
        </div>
        <button
          onClick={() => onToggleFavorite(currentTrack.id)}
          aria-label="Favorito"
          className="min-w-[40px] min-h-[40px] rounded-xl border flex items-center justify-center shrink-0 cursor-pointer"
          style={{
            borderColor: 'var(--theme-border)',
            color: currentTrack.isFavorite
              ? 'var(--theme-accent)'
              : 'var(--theme-muted)'
          }}
        >
          <Heart
            className={`w-4 h-4 ${currentTrack.isFavorite ? 'fill-current' : ''}`}
          />
        </button>
      </div>

      <div
        className="p-3 rounded-2xl border"
        style={{
          backgroundColor: 'var(--theme-bg)',
          borderColor: 'var(--theme-border)'
        }}
      >
        <AudioVisualizer
          isPlaying={isPlaying}
          style={themeConfig.visualizerStyle}
          accentColor={activeAccentColor}
          height={54}
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <input
          type="range"
          min={0}
          max={duration || 1}
          step={0.5}
          value={currentTime}
          onChange={onSeek}
          className="w-full cursor-pointer"
          style={{ accentColor: 'var(--theme-accent)' }}
          aria-label="Progreso de la pista"
        />
        <div
          className="flex items-center justify-between text-xs font-mono-tabular"
          style={{ color: 'var(--theme-muted)' }}
        >
          <span>{formatDuration(currentTime)}</span>
          {loopA !== null && (
            <span style={{ color: 'var(--theme-accent)' }}>
              Bucle {formatDuration(loopA)}–
              {loopB !== null ? formatDuration(loopB) : '...'}
            </span>
          )}
          <span>{formatDuration(duration)}</span>
        </div>
      </div>

      <div className="flex items-center justify-between gap-2">
        <button
          onClick={() => setIsShuffle(!isShuffle)}
          aria-label="Modo aleatorio"
          className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center cursor-pointer"
          style={{ color: isShuffle ? 'var(--theme-accent)' : 'var(--theme-muted)' }}
        >
          <Shuffle className="w-4 h-4" />
        </button>

        <button
          onClick={onPrevTrack}
          aria-label="Anterior"
          className="min-w-[44px] min-h-[44px] rounded-xl border flex items-center justify-center cursor-pointer"
          style={{ borderColor: 'var(--theme-border)' }}
        >
          <SkipBack className="w-4 h-4" />
        </button>

        <button
          onClick={onTogglePlayPause}
          aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
          className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-md transition-transform active:scale-95 cursor-pointer"
          style={{
            backgroundColor: 'var(--theme-accent)',
            color: 'var(--theme-accent-fg)'
          }}
        >
          {isPlaying ? (
            <Pause className="w-6 h-6 fill-current" />
          ) : (
            <Play className="w-6 h-6 fill-current ml-0.5" />
          )}
        </button>

        <button
          onClick={() => onNextTrack(false)}
          aria-label="Siguiente"
          className="min-w-[44px] min-h-[44px] rounded-xl border flex items-center justify-center cursor-pointer"
          style={{ borderColor: 'var(--theme-border)' }}
        >
          <SkipForward className="w-4 h-4" />
        </button>

        <button
          onClick={() =>
            setRepeatMode(prev =>
              prev === 'off' ? 'all' : prev === 'all' ? 'one' : 'off'
            )
          }
          aria-label="Modo repetición"
          className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center relative cursor-pointer"
          style={{
            color: repeatMode !== 'off' ? 'var(--theme-accent)' : 'var(--theme-muted)'
          }}
        >
          <Repeat className="w-4 h-4" />
          {repeatMode === 'one' && (
            <span className="text-[9px] font-mono-tabular font-bold absolute -top-0.5 right-1">
              1
            </span>
          )}
        </button>
      </div>

      <div
        className="flex items-center justify-between gap-3 pt-2 border-t"
        style={{ borderColor: 'var(--theme-border)' }}
      >
        <div className="flex items-center gap-2 flex-1">
          <button
            onClick={onToggleMute}
            aria-label="Silenciar"
            className="p-1.5 cursor-pointer"
            style={{ color: 'var(--theme-muted)' }}
          >
            {isMuted || volume === 0 ? (
              <VolumeX className="w-4 h-4" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.02}
            value={isMuted ? 0 : volume}
            onChange={onVolumeChange}
            className="w-full cursor-pointer"
            style={{ accentColor: 'var(--theme-accent)' }}
            aria-label="Volumen"
          />
        </div>

        <button
          onClick={onToggleLoopPoint}
          className="px-2.5 py-1.5 rounded-lg text-xs font-mono-tabular border flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
          style={{
            borderColor: loopA !== null ? 'var(--theme-accent)' : 'var(--theme-border)',
            color: loopA !== null ? 'var(--theme-accent)' : 'var(--theme-muted)'
          }}
        >
          <RotateCcw className="w-3 h-3" />
          {loopA === null ? 'A-B' : loopB === null ? 'Fijar B' : 'Limpiar'}
        </button>

        {sleepSecondsRemaining !== null || sleepEndOfTrack ? (
          <div
            className="px-2.5 py-1.5 rounded-lg text-xs font-mono-tabular border flex items-center gap-1.5 whitespace-nowrap shrink-0"
            style={{
              borderColor: 'var(--theme-accent)',
              color: 'var(--theme-accent)',
              backgroundColor: 'rgba(56, 189, 248, 0.08)'
            }}
          >
            <button
              type="button"
              onClick={() => setActiveModal('sleep-timer')}
              className="flex items-center gap-1 font-bold cursor-pointer"
            >
              <Moon className="w-3.5 h-3.5" />
              <span>
                {sleepEndOfTrack
                  ? `Fin · ${formatDuration(sleepSecondsRemaining ?? 0)}`
                  : `${formatDuration(sleepSecondsRemaining ?? 0)}${
                      isSleepTimerFading ? ' (Fade)' : ''
                    }`}
              </span>
            </button>
            <button
              type="button"
              onClick={() => onCancelSleepTimer()}
              aria-label="Cancelar temporizador de apagado"
              className="p-0.5 rounded hover:bg-rose-500/20 text-rose-400 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setActiveModal('sleep-timer')}
            title="Temporizador de apagado"
            aria-label="Temporizador de apagado"
            className="px-2.5 py-1.5 rounded-lg text-xs font-mono-tabular border flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              borderColor: 'var(--theme-border)',
              color: 'var(--theme-muted)'
            }}
          >
            <Moon className="w-3.5 h-3.5" />
            <span>Apagado</span>
          </button>
        )}
      </div>
    </>
  );
};
