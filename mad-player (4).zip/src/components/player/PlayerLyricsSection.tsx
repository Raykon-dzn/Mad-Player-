import React from 'react';
import { Track } from '../../types/music';

interface PlayerLyricsSectionProps {
  currentTrack: Track;
  currentTime: number;
  duration: number;
  onBackToNowPlaying: () => void;
}

export const PlayerLyricsSection: React.FC<PlayerLyricsSectionProps> = ({
  currentTrack,
  currentTime,
  duration,
  onBackToNowPlaying
}) => {
  return (
    <div className="flex flex-col gap-3 py-4 max-h-[420px] overflow-y-auto">
      <div className="flex items-center justify-between">
        <p
          className="text-xs font-mono-tabular uppercase"
          style={{ color: 'var(--theme-muted)' }}
        >
          Letra Sincronizada — {currentTrack.title}
        </p>
        <button
          onClick={onBackToNowPlaying}
          className="text-xs underline cursor-pointer"
          style={{ color: 'var(--theme-accent)' }}
        >
          Volver
        </button>
      </div>
      {currentTrack.lyrics && currentTrack.lyrics.length > 0 ? (
        <div className="flex flex-col gap-3">
          {currentTrack.lyrics.map((line, idx) => {
            const activeLineIdx = Math.floor(
              (currentTime / Math.max(1, duration)) * currentTrack.lyrics!.length
            );
            const isCurrentLine = idx === activeLineIdx;
            return (
              <p
                key={idx}
                className="text-sm transition-colors leading-relaxed"
                style={{
                  color: isCurrentLine ? 'var(--theme-accent)' : 'var(--theme-text)',
                  fontWeight: isCurrentLine ? 600 : 400
                }}
              >
                {line}
              </p>
            );
          })}
        </div>
      ) : (
        <p className="text-xs" style={{ color: 'var(--theme-muted)' }}>
          Pista instrumental sin letra registrada. Puedes añadir letra desde el editor de
          etiquetas ID3.
        </p>
      )}
    </div>
  );
};
