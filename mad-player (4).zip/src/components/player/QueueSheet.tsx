import React, { useMemo, useRef } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { X } from 'lucide-react';
import { Track } from '../../types/music';

interface QueueSheetProps {
  tracks: Track[];
  currentTrack?: Track;
  queueIds: string[];
  setQueueIds: React.Dispatch<React.SetStateAction<string[]>>;
  onPlayTrack: (track: Track, customQueueIds?: string[], fromUserSelection?: boolean) => void;
  onBackToNowPlaying: () => void;
}

export const QueueSheet: React.FC<QueueSheetProps> = ({
  tracks,
  currentTrack,
  queueIds,
  setQueueIds,
  onPlayTrack,
  onBackToNowPlaying
}) => {
  const queueScrollRef = useRef<HTMLDivElement | null>(null);

  const resolvedQueueItems = useMemo(
    () =>
      queueIds
        .map((id, idx) => ({
          track: tracks.find(item => item.id === id),
          idx
        }))
        .filter((entry): entry is { track: Track; idx: number } => Boolean(entry.track)),
    [queueIds, tracks]
  );

  const queueVirtualizer = useVirtualizer({
    count: resolvedQueueItems.length,
    getScrollElement: () => queueScrollRef.current,
    estimateSize: () => 52,
    overscan: 8
  });

  const currentQueuePosition = currentTrack
    ? Math.max(1, queueIds.indexOf(currentTrack.id) + 1)
    : 0;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold" style={{ color: 'var(--theme-muted)' }}>
          Pistas en cola ({currentQueuePosition}/{queueIds.length})
        </span>
        <button
          onClick={onBackToNowPlaying}
          className="text-xs underline cursor-pointer"
          style={{ color: 'var(--theme-accent)' }}
        >
          Volver al reproductor
        </button>
      </div>
      <div
        ref={queueScrollRef}
        className="max-h-[420px] overflow-y-auto pr-1"
        style={{ borderColor: 'var(--theme-border)' }}
      >
        <div
          style={{
            height: `${queueVirtualizer.getTotalSize()}px`,
            width: '100%',
            position: 'relative'
          }}
        >
          {queueVirtualizer.getVirtualItems().map(virtualRow => {
            const entry = resolvedQueueItems[virtualRow.index];
            if (!entry) return null;
            const { track: t, idx } = entry;
            const active = t.id === currentTrack?.id;
            const isLast = virtualRow.index === resolvedQueueItems.length - 1;
            return (
              <div
                key={`${t.id}-${idx}`}
                data-index={virtualRow.index}
                ref={queueVirtualizer.measureElement}
                onClick={() => onPlayTrack(t)}
                className={`py-2 flex items-center justify-between gap-2 cursor-pointer ${
                  isLast ? '' : 'border-b'
                }`}
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  transform: `translateY(${virtualRow.start}px)`,
                  borderColor: 'var(--theme-border)'
                }}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className="text-xs font-mono-tabular w-5"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    {idx + 1}
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <p
                        className="text-xs font-semibold truncate"
                        style={{
                          color: t.audioUnavailable
                            ? '#fb7185'
                            : active
                              ? 'var(--theme-accent)'
                              : 'var(--theme-text)'
                        }}
                      >
                        {t.title}
                      </p>
                      {t.audioUnavailable && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0">
                          archivo no disponible
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] truncate" style={{ color: 'var(--theme-muted)' }}>
                      {t.artist}
                    </p>
                  </div>
                </div>
                <button
                  onClick={e => {
                    e.stopPropagation();
                    if (queueIds.length > 1) {
                      setQueueIds(prev => prev.filter((_, i) => i !== idx));
                    }
                  }}
                  className="p-1 text-xs cursor-pointer"
                  style={{ color: 'var(--theme-muted)' }}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
