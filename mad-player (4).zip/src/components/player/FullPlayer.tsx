import React, { useRef, useState } from 'react';
import {
  ArrowLeft,
  FolderSearch,
  MoreVertical,
  Music2,
  Upload
} from 'lucide-react';
import { EqualizerState, ThemeConfig, Track } from '../../types/music';
import { useSettingsContext } from '../../hooks/useSettings';
import { ActiveModal } from '../PlayerModals';
import { QueueSheet } from './QueueSheet';
import { PlayerCoverSection } from './PlayerCoverSection';
import {
  PlayerSkinControlsSection,
  PlayerStudioNowPlayingSection
} from './PlayerControlsSection';
import { PlayerLyricsSection } from './PlayerLyricsSection';
import {
  PlayerEqualizerModal,
  PlayerTagEditorModal
} from './PlayerEqualizerModal';

export interface FullPlayerLibrarySlice {
  tracks: Track[];
  editingTrack: Track | null;
  setEditingTrack: React.Dispatch<React.SetStateAction<Track | null>>;
  handleSaveTrackTags: (e: React.FormEvent) => void;
  toggleFavorite: (trackId: string, e?: React.MouseEvent) => void;
  handleScanFolderOrLibrary: () => void;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  coverInputRef: React.RefObject<HTMLInputElement | null>;
}

export interface FullPlayerStateSlice {
  currentTrack?: Track;
  queueIds: string[];
  setQueueIds: React.Dispatch<React.SetStateAction<string[]>>;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  setIsShuffle: React.Dispatch<React.SetStateAction<boolean>>;
  repeatMode: 'off' | 'all' | 'one';
  setRepeatMode: React.Dispatch<React.SetStateAction<'off' | 'all' | 'one'>>;
  eqState: EqualizerState;
  setEqState: React.Dispatch<React.SetStateAction<EqualizerState>>;
  loopA: number | null;
  loopB: number | null;
  sleepSecondsRemaining: number | null;
  sleepEndOfTrack: boolean;
  isSleepTimerFading: boolean;
  cancelSleepTimer: () => void;
  mobilePlayerExpanded: boolean;
  setMobilePlayerExpanded: React.Dispatch<React.SetStateAction<boolean>>;
  playerPanelView: 'now-playing' | 'queue' | 'lyrics';
  setPlayerPanelView: React.Dispatch<React.SetStateAction<'now-playing' | 'queue' | 'lyrics'>>;
  playTrack: (track: Track, customQueueIds?: string[], fromUserSelection?: boolean) => void;
  togglePlayPause: () => void;
  handleNextTrack: (fromAutoEnd?: boolean) => void;
  handlePrevTrack: () => void;
  handleSeek: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleDirectSeek: (seconds: number) => void;
  handleVolumeChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleDirectVolumeChange: (val: number) => void;
  toggleMute: () => void;
  handleToggleLoopPoint: () => void;
  handleShareTrack: (mode: 'hashtag' | 'native') => void;
}

export interface FullPlayerProps {
  library: FullPlayerLibrarySlice;
  player: FullPlayerStateSlice;
  themeConfig: ThemeConfig;
  setThemeConfig: React.Dispatch<React.SetStateAction<ThemeConfig>>;
  extractedTrackColor: string;
  activeAccentColor: string;
  setActiveModal: React.Dispatch<React.SetStateAction<ActiveModal>>;
  showEqualizerModal: boolean;
  setShowEqualizerModal: React.Dispatch<React.SetStateAction<boolean>>;
  showToast: (msg: string) => void;
}

export const FullPlayer: React.FC<FullPlayerProps> = ({
  library,
  player,
  themeConfig,
  setThemeConfig,
  extractedTrackColor,
  activeAccentColor,
  setActiveModal,
  showEqualizerModal,
  setShowEqualizerModal,
  showToast
}) => {
  const { volumeGestureEnabled } = useSettingsContext();

  const {
    tracks,
    editingTrack,
    setEditingTrack,
    handleSaveTrackTags,
    toggleFavorite,
    handleScanFolderOrLibrary
  } = library;

  const {
    currentTrack,
    queueIds,
    setQueueIds,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    setIsShuffle,
    repeatMode,
    setRepeatMode,
    eqState,
    setEqState,
    loopA,
    loopB,
    sleepSecondsRemaining,
    sleepEndOfTrack,
    isSleepTimerFading,
    cancelSleepTimer,
    mobilePlayerExpanded,
    setMobilePlayerExpanded,
    playerPanelView,
    setPlayerPanelView,
    playTrack,
    togglePlayPause,
    handleNextTrack,
    handlePrevTrack,
    handleSeek,
    handleDirectSeek,
    handleVolumeChange,
    handleDirectVolumeChange,
    toggleMute,
    handleToggleLoopPoint,
    handleShareTrack
  } = player;

  // Gesture Animation States
  const [coverSeekBadge, setCoverSeekBadge] = useState<'-10s' | '+10s' | null>(null);
  const [coverHeartBurst, setCoverHeartBurst] = useState<'favorite' | 'unfavorite' | null>(null);
  const [swipeOffsetPx, setSwipeOffsetPx] = useState<number>(0);
  const [showCoverVolumeBar, setShowCoverVolumeBar] = useState<boolean>(false);

  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);
  const touchStartVolRef = useRef<number>(0.85);
  const gestureLockRef = useRef<'horizontal' | 'vertical' | null>(null);
  const volumeBarHideTimerRef = useRef<number | null>(null);
  const lastCoverTapRef = useRef<{ time: number; xRatio: number }>({ time: 0, xRatio: 0.5 });
  const lastEmptyAreaTapRef = useRef<number>(0);

  const currentQueuePosition = currentTrack
    ? Math.max(1, queueIds.indexOf(currentTrack.id) + 1)
    : 0;
  const progressPercent = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  // GESTURE 1: Swipe Left / Right on Cover Art to change to Next / Previous Song + Vertical Drag for Volume
  const handleCoverTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length !== 1) return;
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
    touchStartVolRef.current = isMuted ? 0 : volume;
    gestureLockRef.current = null;
  };

  const handleCoverTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) return;
    const dx = e.touches[0].clientX - touchStartXRef.current;
    const dy = e.touches[0].clientY - touchStartYRef.current;

    if (!gestureLockRef.current) {
      if (Math.abs(dx) > 14 && Math.abs(dx) > Math.abs(dy) * 1.2) {
        gestureLockRef.current = 'horizontal';
      } else if (volumeGestureEnabled && Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx) * 1.2) {
        gestureLockRef.current = 'vertical';
      }
    }

    if (gestureLockRef.current === 'horizontal') {
      setSwipeOffsetPx(Math.max(-90, Math.min(90, dx * 0.45)));
    } else if (gestureLockRef.current === 'vertical' && volumeGestureEnabled) {
      if (volumeBarHideTimerRef.current) {
        window.clearTimeout(volumeBarHideTimerRef.current);
        volumeBarHideTimerRef.current = null;
      }
      setShowCoverVolumeBar(true);
      const deltaVol = -dy / 200;
      const nextVol = Number(
        Math.max(0, Math.min(1, touchStartVolRef.current + deltaVol)).toFixed(2)
      );
      handleDirectVolumeChange(nextVol);
    }
  };

  const handleCoverTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) {
      setSwipeOffsetPx(0);
      return;
    }
    const endX = e.changedTouches[0]?.clientX ?? touchStartXRef.current;
    const endY = e.changedTouches[0]?.clientY ?? touchStartYRef.current;
    const dx = endX - touchStartXRef.current;
    const dy = endY - touchStartYRef.current;
    const locked = gestureLockRef.current;

    touchStartXRef.current = null;
    touchStartYRef.current = null;
    gestureLockRef.current = null;
    setSwipeOffsetPx(0);

    if (locked === 'vertical') {
      volumeBarHideTimerRef.current = window.setTimeout(() => {
        setShowCoverVolumeBar(false);
      }, 650);
      return;
    }

    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.3) {
      if (dx < 0) {
        handleNextTrack(false);
        showToast('Siguiente canción »');
      } else {
        handlePrevTrack();
        showToast('« Canción anterior');
      }
    }
  };

  // GESTURE 2: Double-Click / Double-Tap on Left or Right side of Cover Art (±10 seconds)
  const handleCoverPointerTap = (e: React.MouseEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('button')) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const xRatio = (e.clientX - rect.left) / Math.max(1, rect.width);
    const now = performance.now();
    const deltaMs = now - lastCoverTapRef.current.time;

    if (deltaMs > 0 && deltaMs < 330) {
      lastCoverTapRef.current.time = 0;
      if (xRatio < 0.48) {
        handleDirectSeek(Math.max(0, currentTime - 10));
        setCoverSeekBadge('-10s');
        window.setTimeout(() => setCoverSeekBadge(null), 750);
      } else if (xRatio > 0.52) {
        handleDirectSeek(Math.min(duration || currentTrack?.duration || 0, currentTime + 10));
        setCoverSeekBadge('+10s');
        window.setTimeout(() => setCoverSeekBadge(null), 750);
      }
    } else {
      lastCoverTapRef.current = { time: now, xRatio };
    }
  };

  // GESTURE 3: Double-Click / Double-Tap in ANY Empty Space Below the Cover Art -> Heart Animation
  const handleLowerBodyTap = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('input')) return;

    const now = performance.now();
    const deltaMs = now - lastEmptyAreaTapRef.current;

    if (deltaMs > 0 && deltaMs < 340) {
      if (!currentTrack) return;
      lastEmptyAreaTapRef.current = 0;
      const willBeFavorite = !currentTrack.isFavorite;
      toggleFavorite(currentTrack.id);
      setCoverHeartBurst(willBeFavorite ? 'favorite' : 'unfavorite');
      window.setTimeout(() => setCoverHeartBurst(null), 950);
      showToast(willBeFavorite ? 'Añadida a Favoritos ♥' : 'Eliminada de Favoritos');
    } else {
      lastEmptyAreaTapRef.current = now;
    }
  };

  const handleTriggerCoverUpload = () => library.coverInputRef.current?.click();
  const handleTriggerImportFiles = () => library.fileInputRef.current?.click();

  return (
    <>
      {/* RIGHT-HAND / MOBILE FULL-SCREEN PLAYER CONSOLE */}
      <aside
        className={`lg:col-span-4 ${
          mobilePlayerExpanded
            ? 'fixed inset-0 z-40 overflow-y-auto flex flex-col'
            : 'hidden lg:flex lg:flex-col'
        }`}
        style={{
          backgroundColor: mobilePlayerExpanded ? 'var(--theme-bg)' : 'transparent'
        }}
      >
        {themeConfig.playerSkin !== 'studio-console' &&
        themeConfig.playerSkin !== 'minimal-wave' &&
        currentTrack &&
        playerPanelView === 'now-playing' ? (
          (() => {
            const adaptiveColor = themeConfig.adaptToCoverArt
              ? extractedTrackColor || currentTrack.dominantColor || '#1e4631'
              : themeConfig.useCustomAccent
                ? themeConfig.customAccentHex
                : activeAccentColor;

            const isLightLowerSkin =
              themeConfig.playerSkin === 'muzio-classic' ||
              themeConfig.playerSkin === 'stacked-cards';

            const containerBgStyle: React.CSSProperties =
              themeConfig.playerSkin === 'muzio-classic'
                ? {
                    backgroundColor: `color-mix(in srgb, ${adaptiveColor} 18%, #eff4f1)`,
                    color: `color-mix(in srgb, ${adaptiveColor} 78%, #0f2217)`
                  }
                : themeConfig.playerSkin === 'stacked-cards'
                  ? {
                      backgroundColor: '#f4f6f4',
                      backgroundImage: `linear-gradient(180deg, color-mix(in srgb, ${adaptiveColor} 82%, #14241b) 0%, color-mix(in srgb, ${adaptiveColor} 46%, #8da193) 46%, #f4f6f4 54%, #f4f6f4 100%)`,
                      color: '#18241d'
                    }
                  : themeConfig.playerSkin === 'vinyl-circle'
                    ? {
                        backgroundColor: `color-mix(in srgb, ${adaptiveColor} 60%, #111d16)`,
                        backgroundImage: `linear-gradient(180deg, color-mix(in srgb, ${adaptiveColor} 80%, #1b2e23) 0%, color-mix(in srgb, ${adaptiveColor} 58%, #121f17) 55%, color-mix(in srgb, ${adaptiveColor} 40%, #09110c) 100%)`,
                        color: '#ffffff'
                      }
                    : themeConfig.playerSkin === 'circle-cobalt'
                      ? {
                          backgroundColor: `color-mix(in srgb, ${adaptiveColor} 64%, #14231a)`,
                          backgroundImage: `radial-gradient(circle at 50% 35%, color-mix(in srgb, ${adaptiveColor} 78%, #22382b) 0%, color-mix(in srgb, ${adaptiveColor} 52%, #0e1812) 100%)`,
                          color: '#ffffff'
                        }
                      : themeConfig.playerSkin === 'framed-card'
                        ? {
                            backgroundColor: `color-mix(in srgb, ${adaptiveColor} 58%, #121e17)`,
                            color: '#ffffff'
                          }
                        : {
                            backgroundColor: `color-mix(in srgb, ${adaptiveColor} 55%, #0b140f)`,
                            color: '#ffffff'
                          };

            const handleSpeakerMuteClick = (e: React.MouseEvent) => {
              e.stopPropagation();
              const willMute = !isMuted;
              toggleMute();
              showToast(willMute ? 'Audio silenciado (Mute)' : 'Sonido activado');
            };

            const handleFavoriteButtonClick = (e: React.MouseEvent) => {
              e.stopPropagation();
              const willBeFav = !currentTrack.isFavorite;
              toggleFavorite(currentTrack.id);
              setCoverHeartBurst(willBeFav ? 'favorite' : 'unfavorite');
              window.setTimeout(() => setCoverHeartBurst(null), 900);
            };

            const handleCollapsePlayer = (e: React.MouseEvent) => {
              e.stopPropagation();
              if (mobilePlayerExpanded) {
                setMobilePlayerExpanded(false);
              } else {
                setThemeConfig(prev => ({ ...prev, playerSkin: 'studio-console' }));
              }
            };

            return (
              <div
                className={`overflow-hidden flex flex-col justify-between shadow-2xl select-none relative ${
                  mobilePlayerExpanded
                    ? 'rounded-none border-0 min-h-screen w-full flex-1'
                    : 'rounded-none lg:rounded-3xl border sticky top-20 min-h-screen lg:min-h-[650px]'
                }`}
                style={{
                  ...containerBgStyle,
                  borderColor: 'var(--theme-border)'
                }}
              >
                <PlayerCoverSection
                  currentTrack={currentTrack}
                  themeConfig={themeConfig}
                  adaptiveColor={adaptiveColor}
                  eqState={eqState}
                  currentTime={currentTime}
                  progressPercent={progressPercent}
                  currentQueuePosition={currentQueuePosition}
                  queueLength={queueIds.length}
                  volume={volume}
                  isMuted={isMuted}
                  swipeOffsetPx={swipeOffsetPx}
                  coverSeekBadge={coverSeekBadge}
                  coverHeartBurst={coverHeartBurst}
                  showCoverVolumeBar={showCoverVolumeBar}
                  onCoverPointerTap={handleCoverPointerTap}
                  onCoverTouchStart={handleCoverTouchStart}
                  onCoverTouchMove={handleCoverTouchMove}
                  onCoverTouchEnd={handleCoverTouchEnd}
                  onCollapsePlayer={handleCollapsePlayer}
                  onSpeakerMuteClick={handleSpeakerMuteClick}
                  onFavoriteButtonClick={handleFavoriteButtonClick}
                  onShareTrack={handleShareTrack}
                  onOpenQueue={() => setPlayerPanelView('queue')}
                  onTriggerCoverUpload={handleTriggerCoverUpload}
                  setActiveModal={setActiveModal}
                />

                <PlayerSkinControlsSection
                  currentTrack={currentTrack}
                  themeConfig={themeConfig}
                  adaptiveColor={adaptiveColor}
                  isLightLowerSkin={isLightLowerSkin}
                  isPlaying={isPlaying}
                  currentTime={currentTime}
                  duration={duration}
                  progressPercent={progressPercent}
                  currentQueuePosition={currentQueuePosition}
                  queueLength={queueIds.length}
                  volume={volume}
                  isMuted={isMuted}
                  isShuffle={isShuffle}
                  setIsShuffle={setIsShuffle}
                  repeatMode={repeatMode}
                  setRepeatMode={setRepeatMode}
                  sleepSecondsRemaining={sleepSecondsRemaining}
                  sleepEndOfTrack={sleepEndOfTrack}
                  isSleepTimerFading={isSleepTimerFading}
                  onCancelSleepTimer={cancelSleepTimer}
                  onLowerBodyTap={handleLowerBodyTap}
                  onFavoriteButtonClick={handleFavoriteButtonClick}
                  onSpeakerMuteClick={handleSpeakerMuteClick}
                  onOpenQueue={() => setPlayerPanelView('queue')}
                  onSeek={handleSeek}
                  onDirectSeek={handleDirectSeek}
                  onTogglePlayPause={togglePlayPause}
                  onNextTrack={handleNextTrack}
                  onPrevTrack={handlePrevTrack}
                  onShareTrack={handleShareTrack}
                  setActiveModal={setActiveModal}
                />
              </div>
            );
          })()
        ) : (
          /* SKIN 2: STUDIO CONSOLE OR QUEUE / LYRICS SUB-VIEWS */
          <div
            className={`border p-5 flex flex-col gap-5 ${
              mobilePlayerExpanded
                ? 'rounded-none border-0 min-h-screen w-full flex-1'
                : 'rounded-3xl sticky top-20'
            }`}
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-border)'
            }}
          >
            <div className="flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  if (playerPanelView !== 'now-playing') {
                    setPlayerPanelView('now-playing');
                  } else if (mobilePlayerExpanded) {
                    setMobilePlayerExpanded(false);
                  }
                }}
                aria-label="Retroceder"
                className="w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 cursor-pointer"
                style={{ borderColor: 'var(--theme-border)', color: 'var(--theme-text)' }}
              >
                <ArrowLeft className="w-4 h-4" />
              </button>

              <div
                className="grid grid-cols-3 gap-1 p-1 rounded-xl border flex-1"
                style={{
                  backgroundColor: 'var(--theme-bg)',
                  borderColor: 'var(--theme-border)'
                }}
              >
                {(
                  [
                    { id: 'now-playing', label: 'Reproductor' },
                    { id: 'queue', label: `Cola (${queueIds.length})` },
                    { id: 'lyrics', label: 'Letra' }
                  ] as const
                ).map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setPlayerPanelView(tab.id)}
                    className="py-1.5 px-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    style={{
                      backgroundColor:
                        playerPanelView === tab.id ? 'var(--theme-surface)' : 'transparent',
                      color:
                        playerPanelView === tab.id
                          ? 'var(--theme-accent)'
                          : 'var(--theme-muted)'
                    }}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <button
                onClick={() => setActiveModal('action-sheet')}
                aria-label="Menú de opciones"
                className="w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 cursor-pointer"
                style={{ borderColor: 'var(--theme-border)', color: 'var(--theme-text)' }}
              >
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>

            {playerPanelView === 'now-playing' && currentTrack && (
              <PlayerStudioNowPlayingSection
                currentTrack={currentTrack}
                themeConfig={themeConfig}
                activeAccentColor={activeAccentColor}
                eqState={eqState}
                isPlaying={isPlaying}
                currentTime={currentTime}
                duration={duration}
                volume={volume}
                isMuted={isMuted}
                isShuffle={isShuffle}
                setIsShuffle={setIsShuffle}
                repeatMode={repeatMode}
                setRepeatMode={setRepeatMode}
                loopA={loopA}
                loopB={loopB}
                sleepSecondsRemaining={sleepSecondsRemaining}
                sleepEndOfTrack={sleepEndOfTrack}
                isSleepTimerFading={isSleepTimerFading}
                onCancelSleepTimer={cancelSleepTimer}
                onToggleFavorite={toggleFavorite}
                onSeek={handleSeek}
                onTogglePlayPause={togglePlayPause}
                onNextTrack={handleNextTrack}
                onPrevTrack={handlePrevTrack}
                onVolumeChange={handleVolumeChange}
                onToggleMute={toggleMute}
                onToggleLoopPoint={handleToggleLoopPoint}
                setActiveModal={setActiveModal}
              />
            )}

            {/* Player Queue Sub-View */}
            {playerPanelView === 'queue' && (
              <QueueSheet
                tracks={tracks}
                currentTrack={currentTrack}
                queueIds={queueIds}
                setQueueIds={setQueueIds}
                onPlayTrack={playTrack}
                onBackToNowPlaying={() => setPlayerPanelView('now-playing')}
              />
            )}

            {/* Synchronized Lyrics Sub-View */}
            {playerPanelView === 'lyrics' && currentTrack && (
              <PlayerLyricsSection
                currentTrack={currentTrack}
                currentTime={currentTime}
                duration={duration}
                onBackToNowPlaying={() => setPlayerPanelView('now-playing')}
              />
            )}

            {/* Empty Library State inside Player Panel */}
            {!currentTrack && (
              <div className="py-12 px-4 text-center flex flex-col items-center gap-3">
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center"
                  style={{
                    backgroundColor: 'var(--theme-bg)',
                    color: 'var(--theme-accent)'
                  }}
                >
                  <Music2 className="w-8 h-8" />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="text-sm font-extrabold" style={{ color: 'var(--theme-text)' }}>
                    Biblioteca vacía
                  </p>
                  <p className="text-xs" style={{ color: 'var(--theme-muted)' }}>
                    Escanea una carpeta de música o importa archivos de audio desde tu dispositivo.
                  </p>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2 mt-1">
                  <button
                    onClick={handleScanFolderOrLibrary}
                    className="px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                    style={{
                      backgroundColor: 'var(--theme-accent)',
                      color: 'var(--theme-accent-fg)'
                    }}
                  >
                    <FolderSearch className="w-3.5 h-3.5" />
                    Importar carpeta
                  </button>
                  <button
                    onClick={handleTriggerImportFiles}
                    className="px-3.5 py-2 rounded-xl text-xs font-extrabold border flex items-center gap-1.5 cursor-pointer"
                    style={{
                      borderColor: 'var(--theme-border)',
                      color: 'var(--theme-text)'
                    }}
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Archivos
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </aside>

      {/* FLOATING EQUALIZER OVERLAY WINDOW */}
      <PlayerEqualizerModal
        showEqualizerModal={showEqualizerModal}
        setShowEqualizerModal={setShowEqualizerModal}
        eqState={eqState}
        setEqState={setEqState}
      />

      {/* ID3 TAG EDITOR & COVER ART CHANGER MODAL */}
      <PlayerTagEditorModal
        editingTrack={editingTrack}
        setEditingTrack={setEditingTrack}
        onSaveTrackTags={handleSaveTrackTags}
        onTriggerCoverUpload={handleTriggerCoverUpload}
      />
    </>
  );
};
