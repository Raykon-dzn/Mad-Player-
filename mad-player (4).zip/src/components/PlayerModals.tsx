import React, { useState } from 'react';
import {
  FileText,
  PlusCircle,
  Pencil,
  Info,
  BarChart2,
  Scissors,
  PlaySquare,
  Palette,
  Car,
  Lock,
  Settings,
  EyeOff,
  Trash2,
  Hash,
  Share2,
  Volume2,
  VolumeX,
  X,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Heart,
  Check,
  ChevronDown,
  MoreVertical,
  Eye,
  Music2,
  ImagePlus,
  Moon
} from 'lucide-react';
import { Track, Playlist } from '../types/music';

export type ActiveModal =
  | null
  | 'action-sheet'
  | 'add-to-playlist'
  | 'details'
  | 'speed-picker'
  | 'sleep-timer'
  | 'mp3-cutter'
  | 'youtube-search'
  | 'car-mode'
  | 'lock-screen'
  | 'settings'
  | 'delete-confirm';

export interface PlayerModalsProps {
  activeModal: ActiveModal;
  onClose: () => void;
  onOpenModal: (modal: ActiveModal) => void;
  currentTrack: Track;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onPrev: () => void;
  onNext: () => void;
  onToggleFavorite: (id: string) => void;
  currentTime: number;
  duration: number;
  onSeek: (sec: number) => void;
  volume: number;
  isMuted: boolean;
  onVolumeChange: (val: number) => void;
  onToggleMute: () => void;
  playbackRate: number;
  pitchRate: number;
  onSpeedAndPitchChange: (rate: number, pitchRate: number) => void;
  sleepTimerActive: boolean;
  sleepTimerMinutes: number | null;
  sleepSecondsRemaining: number | null;
  sleepEndOfTrack: boolean;
  isSleepTimerFading: boolean;
  onStartSleepTimer: (minutes: number) => void;
  onStartSleepEndOfTrack: () => void;
  onCancelSleepTimer: () => void;
  onToggleSleepTimer: () => void;
  playPauseFadeEnabled: boolean;
  playPauseFadeMs: number;
  onTogglePlayPauseFade: () => void;
  onChangePlayPauseFadeMs: (ms: number) => void;
  crossfadeEnabled: boolean;
  onToggleCrossfade: () => void;
  gaplessEnabled: boolean;
  onToggleGapless: () => void;
  playlists: Playlist[];
  onAddTrackToPlaylist: (playlistId: string, trackId: string) => void;
  onOpenTagEditor: () => void;
  onOpenLyrics: () => void;
  onOpenEqualizer: () => void;
  onOpenThemes: () => void;
  onOpenFullSettings: () => void;
  onHideTrack: (trackId: string) => void;
  onDeleteTrack: (trackId: string) => void;
  onShareTrack: (mode: 'hashtag' | 'native') => void;
  onCreateTrimmedTrack: (title: string, startSec: number, endSec: number) => void;
  hiddenTracks: Track[];
  onRestoreHiddenTrack: (trackId: string) => void;
  onTriggerCoverUpload?: () => void;
  use24HourFormat?: boolean;
  muzioLockscreenBg?: string;
}

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export const PlayerModals: React.FC<PlayerModalsProps> = ({
  activeModal,
  onClose,
  onOpenModal,
  currentTrack,
  isPlaying,
  onTogglePlay,
  onPrev,
  onNext,
  onToggleFavorite,
  currentTime,
  duration,
  onSeek,
  volume,
  isMuted,
  onVolumeChange,
  onToggleMute,
  playbackRate,
  pitchRate,
  onSpeedAndPitchChange,
  sleepTimerActive,
  sleepTimerMinutes,
  sleepSecondsRemaining,
  sleepEndOfTrack,
  isSleepTimerFading,
  onStartSleepTimer,
  onStartSleepEndOfTrack,
  onCancelSleepTimer,
  onToggleSleepTimer,
  playPauseFadeEnabled,
  playPauseFadeMs,
  onTogglePlayPauseFade,
  onChangePlayPauseFadeMs,
  crossfadeEnabled,
  onToggleCrossfade,
  gaplessEnabled,
  onToggleGapless,
  playlists,
  onAddTrackToPlaylist,
  onOpenTagEditor,
  onOpenLyrics,
  onOpenEqualizer,
  onOpenThemes,
  onOpenFullSettings,
  onHideTrack,
  onDeleteTrack,
  onShareTrack,
  onCreateTrimmedTrack,
  hiddenTracks,
  onRestoreHiddenTrack,
  onTriggerCoverUpload,
  use24HourFormat = false,
  muzioLockscreenBg = 'Diseño'
}) => {
  const [cutStart, setCutStart] = useState<number>(15);
  const [cutEnd, setCutEnd] = useState<number>(
    Math.min(60, Math.max(30, currentTrack.duration - 10))
  );
  const [cutTitle, setCutTitle] = useState<string>(`${currentTrack.title} (Recorte)`);
  const [customSleepMinutes, setCustomSleepMinutes] = useState<number>(sleepTimerMinutes || 20);

  if (!activeModal) return null;

  const effectiveVolPercent = isMuted ? 0 : Math.round(volume * 100);
  const formattedSleepCountdown =
    sleepSecondsRemaining !== null ? formatTime(sleepSecondsRemaining) : null;

  // 1. MUZIO 3-DOTS ACTION SHEET
  if (activeModal === 'action-sheet') {
    return (
      <div className="fixed inset-0 z-50 flex flex-col bg-black/75 backdrop-blur-sm">
        {/* Top dimmed cover art preview area (clickable to close) */}
        <div
          onClick={onClose}
          className="relative h-36 sm:h-48 w-full overflow-hidden shrink-0 cursor-pointer select-none"
          style={{
            background: `linear-gradient(135deg, ${currentTrack.dominantColor}, ${currentTrack.secondaryColor || '#0f172a'})`
          }}
        >
          {currentTrack.coverUrl ? (
            <img
              src={currentTrack.coverUrl}
              alt={currentTrack.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-45 scale-105"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-white/30">
              <Music2 className="w-20 h-20" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-[#07192b]" />
          <button
            onClick={e => {
              e.stopPropagation();
              onClose();
            }}
            aria-label="Cerrar menú"
            className="absolute top-4 left-4 w-11 h-11 rounded-full flex items-center justify-center text-white/90 hover:bg-white/10 cursor-pointer"
          >
            <ChevronDown className="w-6 h-6" />
          </button>
          {onTriggerCoverUpload && (
            <button
              onClick={e => {
                e.stopPropagation();
                onTriggerCoverUpload();
              }}
              className="absolute top-4 left-1/2 -translate-x-1/2 px-3.5 py-1.5 rounded-full bg-black/45 backdrop-blur-md text-white text-xs font-semibold flex items-center gap-1.5 border border-white/15 cursor-pointer"
            >
              <ImagePlus className="w-3.5 h-3.5 text-sky-400" />
              Cambiar portada
            </button>
          )}
          <button
            onClick={e => {
              e.stopPropagation();
              onClose();
            }}
            aria-label="Opciones"
            className="absolute top-4 right-4 w-11 h-11 rounded-full flex items-center justify-center text-white/90 hover:bg-white/10 cursor-pointer"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>

        {/* Bottom Sheet Body (Muzio Deep Navy / Dynamic Dark Slate) */}
        <div
          className="flex-1 overflow-y-auto px-4 pt-5 pb-6 flex flex-col justify-between max-w-md w-full mx-auto rounded-t-3xl shadow-2xl"
          style={{
            backgroundColor: '#071a2e',
            color: '#f1f5f9',
            borderTop: '1px solid rgba(255,255,255,0.08)'
          }}
        >
          {/* 4x4 QUICK ACTION GRID */}
          <div className="flex flex-col gap-5">
            <div className="grid grid-cols-4 gap-y-5 gap-x-2 text-center">
              {/* 1. Letra */}
              <button
                onClick={() => {
                  onClose();
                  onOpenLyrics();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <FileText className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">Letra</span>
              </button>

              {/* 2. Agregar a la lista de reproducción ... */}
              <button
                onClick={() => onOpenModal('add-to-playlist')}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <PlusCircle className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100 px-0.5">
                  Agregar a la lista de reproducción ...
                </span>
              </button>

              {/* 3. Editor de etiquetas */}
              <button
                onClick={() => {
                  onClose();
                  onOpenTagEditor();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Pencil className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Editor de etiquetas
                </span>
              </button>

              {/* 4. Detalles */}
              <button
                onClick={() => onOpenModal('details')}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Info className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">Detalles</span>
              </button>

              {/* 5. Velocidad de reproducción */}
              <button
                onClick={() => onOpenModal('speed-picker')}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-16 h-11 rounded-2xl flex flex-col items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <span className="text-base font-extrabold font-mono-tabular tracking-tight leading-none">
                    {playbackRate.toFixed(1)}X
                  </span>
                  {Math.abs(pitchRate - 1.0) >= 0.05 && (
                    <span className="text-[10px] font-mono-tabular text-sky-400 font-bold leading-none mt-0.5">
                      Tono {pitchRate.toFixed(1)}
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Velocidad de reproducción
                </span>
              </button>

              {/* 6. Ecualizador */}
              <button
                onClick={() => {
                  onClose();
                  onOpenEqualizer();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <BarChart2 className="w-6 h-6 stroke-[2]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Ecualizador
                </span>
              </button>

              {/* 7. Cortador MP3 */}
              <button
                onClick={() => {
                  setCutStart(10);
                  setCutEnd(Math.min(55, Math.max(25, currentTrack.duration - 5)));
                  setCutTitle(`${currentTrack.title} (Clip)`);
                  onOpenModal('mp3-cutter');
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Scissors className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Cortador MP3
                </span>
              </button>

              {/* 8. Buscar en youtube */}
              <button
                onClick={() => onOpenModal('youtube-search')}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <PlaySquare className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Buscar en youtube
                </span>
              </button>

              {/* 9. Tema del reproductor */}
              <button
                onClick={() => {
                  onClose();
                  onOpenThemes();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Palette className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Tema del reproductor
                </span>
              </button>

              {/* 10. Modo de conducir */}
              <button
                onClick={() => onOpenModal('car-mode')}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Car className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Modo de conducir
                </span>
              </button>

              {/* 11. Pantalla de bloqueo */}
              <button
                onClick={() => onOpenModal('lock-screen')}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Lock className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Pantalla de bloqueo
                </span>
              </button>

              {/* 12. Ajustes -> Opens Full-Screen Ajustes View (Screenshot 5) */}
              <button
                onClick={() => {
                  onClose();
                  onOpenFullSettings();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Settings className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">Ajustes</span>
              </button>
            </div>

            {/* Subtle Divider before Row 4 */}
            <div className="border-t border-white/10" />

            {/* Row 4: Ocultar, Eliminar del dispositivo, Compartir (#), Compartir (<) */}
            <div className="grid grid-cols-4 gap-2 text-center">
              <button
                onClick={() => {
                  onHideTrack(currentTrack.id);
                  onClose();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <EyeOff className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">Ocultar</span>
              </button>

              <button
                onClick={() => onOpenModal('delete-confirm')}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Trash2 className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Eliminar del dispositivo
                </span>
              </button>

              <button
                onClick={() => {
                  onShareTrack('hashtag');
                  onClose();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Hash className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Compartir
                </span>
              </button>

              <button
                onClick={() => {
                  onShareTrack('native');
                  onClose();
                }}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white group-hover:bg-white/10 transition-colors">
                  <Share2 className="w-6 h-6 stroke-[1.8]" />
                </div>
                <span className="text-[11px] font-semibold leading-tight text-slate-100">
                  Compartir
                </span>
              </button>
            </div>

            {/* Subtle Divider before 2x2 Toggles */}
            <div className="border-t border-white/10" />

            {/* 2x2 AUDIO TRANSITION & SLEEP TIMER TOGGLES */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-4 items-center">
              {/* Toggle 1: Temporizador de apagado */}
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => onOpenModal('sleep-timer')}
                  className="text-left min-w-0 flex-1 cursor-pointer group"
                >
                  <span className="block text-xs font-bold leading-snug text-slate-100 group-hover:text-sky-400 transition-colors">
                    Temporizador de apagado
                  </span>
                  {sleepTimerActive ? (
                    <span className="block text-[11px] font-mono-tabular text-sky-400 font-bold mt-0.5">
                      {sleepEndOfTrack
                        ? `Al acabar canción · ${formattedSleepCountdown || '0:00'}`
                        : `${formattedSleepCountdown || '0:00'}${
                            isSleepTimerFading ? ' (Fade-out 10s)' : ''
                          }`}
                    </span>
                  ) : (
                    <span className="block text-[11px] font-mono-tabular text-slate-400 mt-0.5">
                      Configurar minutos...
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  role="switch"
                  aria-checked={sleepTimerActive}
                  onClick={() => {
                    if (sleepTimerActive) {
                      onCancelSleepTimer();
                    } else {
                      onOpenModal('sleep-timer');
                    }
                  }}
                  className={`w-12 h-6 rounded-full p-0.5 transition-colors flex items-center shrink-0 cursor-pointer ${
                    sleepTimerActive ? 'bg-sky-400 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <span className="w-5 h-5 rounded-full bg-white shadow" />
                </button>
              </div>

              {/* Toggle 2: Reproducir/Pausar Desvanecimiento (505 Milisegundos) */}
              <div className="flex items-center justify-between gap-2">
                <div>
                  <span className="block text-xs font-bold leading-snug text-slate-100">
                    Reproducir/Pausar Desvanecimiento
                  </span>
                  <span className="block text-[11px] font-mono-tabular text-slate-400 mt-0.5">
                    {playPauseFadeMs} Milisegundos
                  </span>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={playPauseFadeEnabled}
                  onClick={onTogglePlayPauseFade}
                  className={`w-12 h-6 rounded-full p-0.5 transition-colors flex items-center shrink-0 cursor-pointer ${
                    playPauseFadeEnabled ? 'bg-sky-400 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <span className="w-5 h-5 rounded-full bg-white shadow" />
                </button>
              </div>

              {/* Toggle 3: Desvanecer */}
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold leading-snug text-slate-100">Desvanecer</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={crossfadeEnabled}
                  onClick={onToggleCrossfade}
                  className={`w-12 h-6 rounded-full p-0.5 transition-colors flex items-center shrink-0 cursor-pointer ${
                    crossfadeEnabled ? 'bg-sky-400 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <span className="w-5 h-5 rounded-full bg-white shadow" />
                </button>
              </div>

              {/* Toggle 4: Reproducción sin pausas */}
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold leading-snug text-slate-100">
                  Reproducción sin pausas
                </span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={gaplessEnabled}
                  onClick={onToggleGapless}
                  className={`w-12 h-6 rounded-full p-0.5 transition-colors flex items-center shrink-0 cursor-pointer ${
                    gaplessEnabled ? 'bg-sky-400 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <span className="w-5 h-5 rounded-full bg-white shadow" />
                </button>
              </div>
            </div>

            <div className="border-t border-white/10" />

            {/* Bottom Volume Slider Row with Percentage */}
            <div className="flex items-center gap-4 pt-1">
              <button
                onClick={onToggleMute}
                aria-label="Silenciar"
                className="p-1.5 text-white hover:text-sky-400 cursor-pointer"
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={isMuted ? 0 : volume}
                onChange={e => onVolumeChange(Number(e.target.value))}
                className="flex-1 cursor-pointer accent-white"
                aria-label="Volumen"
              />
              <span className="text-sm font-bold font-mono-tabular w-11 text-right text-white">
                {effectiveVolPercent}%
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. MODAL: VELOCIDAD DE REPRODUCCIÓN + TONO DE REPRODUCCIÓN (EXACTO A CAPTURA 3)
  if (activeModal === 'speed-picker') {
    // Symmetric scale 0.5 to 1.5 so 1.0 (Normal) is 100% centered (50%) on BOTH sliders!
    const clampedSpeed = Math.max(0.5, Math.min(1.5, playbackRate));
    const clampedPitch = Math.max(0.5, Math.min(1.5, pitchRate));
    const speedPercent = ((clampedSpeed - 0.5) / 1.0) * 100;
    const pitchPercent = ((clampedPitch - 0.5) / 1.0) * 100;

    return (
      <div
        onClick={() => onClose()}
        className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 select-none"
      >
        <div
          onClick={e => e.stopPropagation()}
          className="w-full max-w-md rounded-t-3xl sm:rounded-3xl px-6 py-7 flex flex-col gap-9 shadow-2xl"
          style={{
            backgroundColor: '#071c2f',
            color: '#ffffff'
          }}
        >
          {/* BLOCK 1: VELOCIDAD DE REPRODUCCIÓN */}
          <div className="flex flex-col gap-5">
            <div className="flex items-center justify-between gap-3">
              <span className="text-base sm:text-lg font-extrabold tracking-tight text-white">
                Velocidad de reproducción: {playbackRate.toFixed(1)}x
              </span>
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(1.0, pitchRate)}
                className="px-4 py-1.5 rounded-xl text-sm font-bold transition-colors cursor-pointer shrink-0"
                style={{
                  backgroundColor: '#1b3146',
                  color: '#8ca0b5'
                }}
              >
                Restablecer
              </button>
            </div>

            {/* Custom Aligned White Track + White Thumb Slider */}
            <div className="relative h-7 flex items-center">
              <div className="w-full h-[3px] rounded-full bg-[#1e3448] relative">
                <div
                  className="absolute inset-y-0 left-0 bg-white rounded-full"
                  style={{ width: `${speedPercent}%` }}
                />
                <div
                  className="w-5 h-5 rounded-full bg-white shadow-md absolute top-1/2 -translate-y-1/2 -translate-x-1/2 pointer-events-none"
                  style={{ left: `${speedPercent}%` }}
                />
              </div>
              <input
                type="range"
                min={0.5}
                max={1.5}
                step={0.1}
                value={clampedSpeed}
                onChange={e => onSpeedAndPitchChange(Number(e.target.value), pitchRate)}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                aria-label="Velocidad de reproducción"
              />
            </div>

            {/* Lento / Normal / Rápido labels */}
            <div className="grid grid-cols-3 text-sm font-bold text-[#7c93a8]">
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(0.5, pitchRate)}
                className="text-left hover:text-white cursor-pointer"
              >
                Lento
              </button>
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(1.0, pitchRate)}
                className="text-center hover:text-white cursor-pointer"
              >
                Normal
              </button>
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(1.5, pitchRate)}
                className="text-right hover:text-white cursor-pointer"
              >
                Rápido
              </button>
            </div>
          </div>

          {/* BLOCK 2: TONO DE REPRODUCCIÓN */}
          <div className="flex flex-col gap-5">
            <div className="flex items-center justify-between gap-3">
              <span className="text-base sm:text-lg font-extrabold tracking-tight text-white">
                Tono de reproducción: {pitchRate.toFixed(1)}
              </span>
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(playbackRate, 1.0)}
                className="px-4 py-1.5 rounded-xl text-sm font-bold transition-colors cursor-pointer shrink-0"
                style={{
                  backgroundColor: '#1b3146',
                  color: '#8ca0b5'
                }}
              >
                Restablecer
              </button>
            </div>

            {/* Custom Aligned White Track + White Thumb Slider */}
            <div className="relative h-7 flex items-center">
              <div className="w-full h-[3px] rounded-full bg-[#1e3448] relative">
                <div
                  className="absolute inset-y-0 left-0 bg-white rounded-full"
                  style={{ width: `${pitchPercent}%` }}
                />
                <div
                  className="w-5 h-5 rounded-full bg-white shadow-md absolute top-1/2 -translate-y-1/2 -translate-x-1/2 pointer-events-none"
                  style={{ left: `${pitchPercent}%` }}
                />
              </div>
              <input
                id="sliderTono"
                type="range"
                min={0.5}
                max={1.5}
                step={0.1}
                value={clampedPitch}
                onChange={e => {
                  const ratio = parseFloat(e.target.value);
                  onSpeedAndPitchChange(playbackRate, ratio);
                }}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                aria-label="Tono de reproducción"
              />
            </div>

            {/* Lento / Normal / Rápido labels */}
            <div className="grid grid-cols-3 text-sm font-bold text-[#7c93a8]">
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(playbackRate, 0.5)}
                className="text-left hover:text-white cursor-pointer"
              >
                Lento
              </button>
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(playbackRate, 1.0)}
                className="text-center hover:text-white cursor-pointer"
              >
                Normal
              </button>
              <button
                type="button"
                onClick={() => onSpeedAndPitchChange(playbackRate, 1.5)}
                className="text-right hover:text-white cursor-pointer"
              >
                Rápido
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2B. MODAL: TEMPORIZADOR DE APAGADO (SLEEP TIMER)
  if (activeModal === 'sleep-timer') {
    const presetMinutes = [1, 5, 10, 15, 30, 45, 60, 90];
    const currentTrackRemainingSec = Math.max(
      0,
      Math.ceil(Math.max(0, (duration || currentTrack.duration || 0) - currentTime) / (playbackRate || 1))
    );

    return (
      <div
        onClick={() => onClose()}
        className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 select-none"
      >
        <div
          onClick={e => e.stopPropagation()}
          className="w-full max-w-md rounded-t-3xl sm:rounded-3xl border p-6 flex flex-col gap-5 shadow-2xl"
          style={{
            backgroundColor: '#071c2f',
            borderColor: 'rgba(255,255,255,0.12)',
            color: '#ffffff'
          }}
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3.5">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-sky-400/15 text-sky-400 flex items-center justify-center">
                <Moon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold font-display">Temporizador de apagado</h3>
                <p className="text-[11px] text-slate-400">
                  Desvanecimiento de 10 s y pausa automática
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onClose()}
              className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Live Countdown Banner when Active */}
          {sleepTimerActive && (
            <div className="p-4 rounded-2xl bg-sky-500/15 border border-sky-400/40 flex items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-sky-300 block">
                  {sleepEndOfTrack
                    ? 'Terminar al acabar la canción actual'
                    : isSleepTimerFading
                      ? 'Desvaneciendo volumen (últimos 10 s)...'
                      : `Apagado programado (${sleepTimerMinutes} min)`}
                </span>
                <span className="text-2xl font-extrabold font-mono-tabular text-white mt-0.5 block">
                  {formattedSleepCountdown || '0:00'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => onCancelSleepTimer()}
                className="px-3.5 py-2 rounded-xl text-xs font-extrabold bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-400/30 cursor-pointer shrink-0"
              >
                Cancelar
              </button>
            </div>
          )}

          {/* Option: Finish at the end of current track */}
          <button
            type="button"
            onClick={() => {
              onStartSleepEndOfTrack();
              onClose();
            }}
            className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-left transition-colors cursor-pointer ${
              sleepEndOfTrack
                ? 'bg-sky-400 text-slate-950 border-sky-400 font-extrabold'
                : 'bg-white/5 hover:bg-white/10 border-white/10 text-white font-bold'
            }`}
          >
            <div>
              <span className="text-xs sm:text-sm block">
                Terminar al acabar la canción actual
              </span>
              <span
                className={`text-[11px] font-mono-tabular block mt-0.5 ${
                  sleepEndOfTrack ? 'text-slate-900' : 'text-slate-400'
                }`}
              >
                Restante en pista: {formatTime(currentTrackRemainingSec)}
              </span>
            </div>
            {sleepEndOfTrack && <Check className="w-5 h-5 shrink-0" />}
          </button>

          {/* Preset Minutes Grid */}
          <div>
            <span className="text-xs font-bold text-slate-300 block mb-2.5">
              Elegir minutos de apagado
            </span>
            <div className="grid grid-cols-4 gap-2">
              {presetMinutes.map(mins => {
                const isSelected = !sleepEndOfTrack && sleepTimerMinutes === mins && sleepTimerActive;
                return (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => {
                      onStartSleepTimer(mins);
                      onClose();
                    }}
                    className={`py-2.5 px-2 rounded-xl text-xs font-extrabold font-mono-tabular border transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-sky-400 text-slate-950 border-sky-400'
                        : 'bg-white/5 hover:bg-white/10 text-white border-white/10'
                    }`}
                  >
                    {mins} min
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Minutes Picker */}
          <div className="p-3.5 rounded-2xl bg-black/25 border border-white/10 flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-200">Minutos personalizados</span>
              <span className="font-mono-tabular text-sky-400 font-extrabold">
                {customSleepMinutes} min
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={180}
              step={1}
              value={customSleepMinutes}
              onChange={e => setCustomSleepMinutes(Number(e.target.value))}
              className="w-full accent-sky-400 cursor-pointer"
              aria-label="Minutos personalizados"
            />
            <div className="flex items-center justify-between gap-2">
              <input
                type="number"
                min={1}
                max={360}
                value={customSleepMinutes}
                onChange={e =>
                  setCustomSleepMinutes(Math.max(1, Math.min(360, Number(e.target.value) || 1)))
                }
                className="w-24 px-3 py-1.5 rounded-xl bg-slate-900 border border-white/15 text-xs font-mono-tabular text-white outline-none"
                aria-label="Cantidad de minutos"
              />
              <button
                type="button"
                onClick={() => {
                  onStartSleepTimer(customSleepMinutes);
                  onClose();
                }}
                className="flex-1 py-2 px-4 rounded-xl text-xs font-extrabold bg-sky-400 text-slate-950 cursor-pointer"
              >
                Fijar {customSleepMinutes} min
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            {sleepTimerActive ? (
              <button
                type="button"
                onClick={() => {
                  onCancelSleepTimer();
                  onClose();
                }}
                className="px-4 py-2 rounded-xl text-xs font-extrabold text-rose-300 hover:bg-rose-500/15 cursor-pointer"
              >
                Desactivar temporizador
              </button>
            ) : (
              <span className="text-[11px] text-slate-400">Temporizador inactivo</span>
            )}
            <button
              type="button"
              onClick={() => onClose()}
              className="px-5 py-2 rounded-xl text-xs font-bold border border-white/15 hover:bg-white/10 cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 3. MODAL: AGREGAR A LA LISTA DE REPRODUCCIÓN
  if (activeModal === 'add-to-playlist') {
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div
          className="w-full max-w-md rounded-2xl border p-6 flex flex-col gap-4"
          style={{
            backgroundColor: '#071a2e',
            borderColor: 'rgba(255,255,255,0.12)',
            color: '#f8fafc'
          }}
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h3 className="text-base font-bold font-display">Agregar a la lista de reproducción</h3>
            <button onClick={() => onOpenModal('action-sheet')} className="p-1 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-slate-300">
            Selecciona la lista donde deseas guardar <strong>{currentTrack.title}</strong>:
          </p>
          <div className="flex flex-col gap-2 max-h-64 overflow-y-auto">
            {playlists.map(pl => {
              const alreadyIn = pl.trackIds.includes(currentTrack.id);
              return (
                <button
                  key={pl.id}
                  onClick={() => {
                    onAddTrackToPlaylist(pl.id, currentTrack.id);
                    onClose();
                  }}
                  className="p-3 rounded-xl border border-white/10 hover:bg-white/10 flex items-center justify-between text-left cursor-pointer"
                >
                  <div>
                    <p className="text-sm font-semibold">{pl.name}</p>
                    <p className="text-xs text-slate-400 font-mono-tabular">
                      {pl.trackIds.length} pistas
                    </p>
                  </div>
                  {alreadyIn && <Check className="w-4 h-4 text-sky-400" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // 4. MODAL: DETALLES TÉCNICOS DEL ARCHIVO
  if (activeModal === 'details') {
    const rows = [
      { label: 'Título de pista', value: currentTrack.title },
      { label: 'Artista', value: currentTrack.artist },
      { label: 'Álbum', value: currentTrack.album },
      { label: 'Género', value: currentTrack.genre },
      { label: 'Duración exacta', value: formatTime(currentTrack.duration) },
      { label: 'Tempo', value: `${currentTrack.bpm} BPM` },
      {
        label: 'Portada de canción',
        value: currentTrack.coverUrl ? 'Carátula reconocida / activa' : 'Sin carátula incrustada'
      },
      {
        label: 'Formato de audio',
        value: currentTrack.audioUrl ? 'Audio Local (MP3/FLAC/M4A)' : 'Pista de Muestreo'
      }
    ];
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div
          className="w-full max-w-md rounded-2xl border p-6 flex flex-col gap-4"
          style={{
            backgroundColor: '#071a2e',
            borderColor: 'rgba(255,255,255,0.12)',
            color: '#f8fafc'
          }}
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h3 className="text-base font-bold font-display">Detalles de la Pista</h3>
            <button onClick={() => onOpenModal('action-sheet')} className="p-1 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="divide-y divide-white/10 text-xs">
            {rows.map(r => (
              <div key={r.label} className="py-2.5 flex items-start justify-between gap-4">
                <span className="text-slate-400 shrink-0">{r.label}</span>
                <span className="font-mono-tabular text-right text-slate-100 break-all">
                  {r.value}
                </span>
              </div>
            ))}
          </div>
          <div className="flex justify-end pt-2">
            <button
              onClick={() => onOpenModal('action-sheet')}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-sky-400 text-slate-950 cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 5. MODAL: CORTADOR MP3 / CREADOR DE RINGTONES
  if (activeModal === 'mp3-cutter') {
    const clipDuration = Math.max(1, cutEnd - cutStart);
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div
          className="w-full max-w-lg rounded-2xl border p-6 flex flex-col gap-5"
          style={{
            backgroundColor: '#071a2e',
            borderColor: 'rgba(255,255,255,0.12)',
            color: '#f8fafc'
          }}
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Scissors className="w-5 h-5 text-sky-400" />
              <h3 className="text-base font-bold font-display">Cortador MP3 y Creador de Clips</h3>
            </div>
            <button onClick={() => onOpenModal('action-sheet')} className="p-1 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div>
            <label className="block text-xs text-slate-300 mb-1">Nombre del recorte / tono</label>
            <input
              type="text"
              value={cutTitle}
              onChange={e => setCutTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-lg text-sm bg-slate-900/90 border border-white/15 text-white outline-none"
            />
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-white/10 flex flex-col gap-3">
            <div className="relative h-16 flex items-center gap-1 overflow-hidden">
              {Array.from({ length: 40 }).map((_, idx) => {
                const posSec = (idx / 40) * currentTrack.duration;
                const inSelection = posSec >= cutStart && posSec <= cutEnd;
                const barH = 25 + Math.abs(Math.sin(idx * 0.65) * 65);
                return (
                  <div
                    key={idx}
                    className="flex-1 rounded-full transition-colors"
                    style={{
                      height: `${barH}%`,
                      backgroundColor: inSelection ? '#38bdf8' : 'rgba(255,255,255,0.18)'
                    }}
                  />
                );
              })}
            </div>

            <div className="flex items-center justify-between text-xs font-mono-tabular text-sky-400">
              <span>Inicio: {formatTime(cutStart)}</span>
              <span>Duración: {formatTime(clipDuration)}</span>
              <span>Fin: {formatTime(cutEnd)}</span>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-1">
              <div>
                <span className="text-[11px] text-slate-400 block mb-1">Punto de Inicio</span>
                <input
                  type="range"
                  min={0}
                  max={Math.max(1, cutEnd - 5)}
                  value={cutStart}
                  onChange={e => setCutStart(Number(e.target.value))}
                  className="w-full accent-sky-400 cursor-pointer"
                />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 block mb-1">Punto de Fin</span>
                <input
                  type="range"
                  min={cutStart + 5}
                  max={currentTrack.duration}
                  value={cutEnd}
                  onChange={e => setCutEnd(Number(e.target.value))}
                  className="w-full accent-sky-400 cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => {
                onSeek(cutStart);
                if (!isPlaying) onTogglePlay();
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold border border-white/15 hover:bg-white/10 flex items-center gap-1.5 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Preescuchar desde {formatTime(cutStart)}
            </button>

            <button
              type="button"
              onClick={() => {
                onCreateTrimmedTrack(cutTitle || `${currentTrack.title} (Clip)`, cutStart, cutEnd);
                onClose();
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-sky-400 text-slate-950 cursor-pointer"
            >
              Guardar Recorte
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 6. MODAL: BUSCAR EN YOUTUBE
  if (activeModal === 'youtube-search') {
    const query = `${currentTrack.artist} - ${currentTrack.title}`;
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div
          className="w-full max-w-md rounded-2xl border p-6 flex flex-col gap-4"
          style={{
            backgroundColor: '#071a2e',
            borderColor: 'rgba(255,255,255,0.12)',
            color: '#f8fafc'
          }}
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <PlaySquare className="w-5 h-5 text-rose-500" />
              <h3 className="text-base font-bold font-display">Buscar en YouTube</h3>
            </div>
            <button onClick={() => onOpenModal('action-sheet')} className="p-1 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-3 rounded-xl bg-slate-900 border border-white/10 text-xs font-mono-tabular text-slate-200">
            Búsqueda: &ldquo;{query}&rdquo;
          </div>

          <div className="flex flex-col gap-2.5">
            {[
              {
                suffix: 'Video Oficial',
                views: '1.2M vistas',
                time: formatTime(currentTrack.duration)
              },
              {
                suffix: 'Audio Oficial HD',
                views: '340K vistas',
                time: formatTime(currentTrack.duration)
              },
              {
                suffix: 'Letra / Lyric Video',
                views: '89K vistas',
                time: formatTime(currentTrack.duration)
              }
            ].map((item, i) => (
              <div
                key={i}
                className="p-3 rounded-xl border border-white/10 bg-slate-950/60 flex items-center gap-3"
              >
                {currentTrack.coverUrl ? (
                  <img
                    src={currentTrack.coverUrl}
                    alt={currentTrack.title}
                    referrerPolicy="no-referrer"
                    className="w-14 h-10 rounded object-cover shrink-0"
                  />
                ) : (
                  <div className="w-14 h-10 rounded bg-slate-800 flex items-center justify-center shrink-0">
                    <Music2 className="w-5 h-5 text-slate-400" />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold truncate">
                    {query} — {item.suffix}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {currentTrack.artist} · {item.views} · {item.time}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              onClick={() => {
                navigator.clipboard
                  ?.writeText(
                    `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
                  )
                  .catch(() => {});
                onOpenModal('action-sheet');
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-rose-600 text-white cursor-pointer"
            >
              Copiar Búsqueda
            </button>
            <button
              onClick={() => onOpenModal('action-sheet')}
              className="px-4 py-2 rounded-lg text-xs font-medium border border-white/15 cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 7. FULL-SCREEN: MODO DE CONDUCIR (CAR MODE)
  if (activeModal === 'car-mode') {
    return (
      <div className="fixed inset-0 z-50 bg-[#050b14] text-white flex flex-col justify-between p-6 select-none">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <Car className="w-7 h-7 text-sky-400" />
            <div>
              <h2 className="text-lg font-bold font-display">Modo de Conducir — Mad Player</h2>
              <p className="text-xs text-slate-400">Controles táctiles gigantes para conducción</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-3 rounded-2xl bg-white/10 hover:bg-white/15 text-sm font-bold cursor-pointer"
          >
            Salir
          </button>
        </div>

        <div className="flex flex-col items-center text-center gap-6 my-auto py-6">
          {currentTrack.coverUrl ? (
            <img
              src={currentTrack.coverUrl}
              alt={currentTrack.title}
              referrerPolicy="no-referrer"
              className="w-44 h-44 sm:w-56 sm:h-56 rounded-3xl object-cover shadow-2xl border border-white/15"
            />
          ) : (
            <div
              className="w-44 h-44 sm:w-56 sm:h-56 rounded-3xl flex items-center justify-center shadow-2xl border border-white/15"
              style={{
                background: `linear-gradient(135deg, ${currentTrack.dominantColor}, ${currentTrack.secondaryColor || '#1e293b'})`
              }}
            >
              <Music2 className="w-20 h-20 text-white/85" />
            </div>
          )}
          <div className="max-w-xl">
            <h1 className="text-3xl sm:text-4xl font-extrabold font-display tracking-tight">
              {currentTrack.title}
            </h1>
            <p className="text-lg sm:text-xl text-sky-400 font-semibold mt-2">
              {currentTrack.artist}
            </p>
          </div>

          <div className="w-full max-w-xl flex flex-col gap-2">
            <input
              type="range"
              min={0}
              max={duration || 1}
              value={currentTime}
              onChange={e => onSeek(Number(e.target.value))}
              className="w-full h-3 accent-sky-400 cursor-pointer"
            />
            <div className="flex justify-between text-base font-mono-tabular text-slate-300">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 max-w-2xl w-full mx-auto pb-4">
          <button
            onClick={() => onToggleFavorite(currentTrack.id)}
            className="h-24 rounded-3xl bg-white/10 flex items-center justify-center cursor-pointer"
            aria-label="Favorito"
          >
            <Heart
              className={`w-10 h-10 ${
                currentTrack.isFavorite ? 'text-rose-500 fill-current' : 'text-white'
              }`}
            />
          </button>
          <button
            onClick={onPrev}
            className="h-24 rounded-3xl bg-white/10 flex items-center justify-center cursor-pointer"
            aria-label="Anterior"
          >
            <SkipBack className="w-11 h-11" />
          </button>
          <button
            onClick={onTogglePlay}
            className="h-24 rounded-3xl bg-sky-400 text-slate-950 flex items-center justify-center cursor-pointer"
            aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
          >
            {isPlaying ? (
              <Pause className="w-12 h-12 fill-current" />
            ) : (
              <Play className="w-12 h-12 fill-current" />
            )}
          </button>
          <button
            onClick={onNext}
            className="h-24 rounded-3xl bg-white/10 flex items-center justify-center cursor-pointer"
            aria-label="Siguiente"
          >
            <SkipForward className="w-11 h-11" />
          </button>
        </div>
      </div>
    );
  }

  // 8. FULL-SCREEN: PANTALLA DE BLOQUEO
  if (activeModal === 'lock-screen') {
    const nowStr = new Date().toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: !use24HourFormat
    });
    const dateStr = new Date().toLocaleDateString('es-ES', {
      weekday: 'long',
      day: 'numeric',
      month: 'long'
    });
    return (
      <div
        className="fixed inset-0 z-50 flex flex-col justify-between p-6 text-white select-none overflow-hidden"
        style={{
          background:
            muzioLockscreenBg === 'Color sólido oscuro'
              ? '#040911'
              : `linear-gradient(135deg, ${currentTrack.dominantColor}, #050b14)`
        }}
      >
        {currentTrack.coverUrl && muzioLockscreenBg !== 'Color sólido oscuro' && (
          <img
            src={currentTrack.coverUrl}
            alt={currentTrack.title}
            referrerPolicy="no-referrer"
            className={`absolute inset-0 w-full h-full object-cover scale-110 ${
              muzioLockscreenBg === 'Carátula desenfocada'
                ? 'blur-3xl opacity-65'
                : 'blur-xl opacity-40'
            }`}
          />
        )}
        <div className="absolute inset-0 bg-black/55" />

        <div className="relative z-10 text-center pt-8">
          <Lock className="w-5 h-5 mx-auto mb-2 text-white/70" />
          <div className="text-6xl sm:text-7xl font-bold font-mono-tabular tracking-tight">
            {nowStr}
          </div>
          <p className="text-sm capitalize text-white/80 mt-1">{dateStr}</p>
        </div>

        <div className="relative z-10 max-w-md w-full mx-auto rounded-3xl bg-white/10 backdrop-blur-xl border border-white/15 p-5 flex flex-col gap-4 shadow-2xl">
          <div className="flex items-center gap-4">
            {currentTrack.coverUrl ? (
              <img
                src={currentTrack.coverUrl}
                alt={currentTrack.title}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-2xl object-cover"
              />
            ) : (
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: currentTrack.dominantColor }}
              >
                <Music2 className="w-8 h-8 text-white" />
              </div>
            )}
            <div className="min-w-0 flex-1">
              <p className="text-base font-bold truncate">{currentTrack.title}</p>
              <p className="text-xs text-white/75 truncate">{currentTrack.artist}</p>
            </div>
          </div>

          <input
            type="range"
            min={0}
            max={duration || 1}
            value={currentTime}
            onChange={e => onSeek(Number(e.target.value))}
            className="w-full accent-white cursor-pointer"
          />

          <div className="flex items-center justify-around">
            <button onClick={onPrev} className="p-2 cursor-pointer">
              <SkipBack className="w-7 h-7" />
            </button>
            <button
              onClick={onTogglePlay}
              className="w-14 h-14 rounded-full bg-white text-slate-950 flex items-center justify-center cursor-pointer"
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 fill-current" />
              ) : (
                <Play className="w-6 h-6 fill-current" />
              )}
            </button>
            <button onClick={onNext} className="p-2 cursor-pointer">
              <SkipForward className="w-7 h-7" />
            </button>
          </div>
        </div>

        <div className="relative z-10 text-center pb-4">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-full bg-white/15 hover:bg-white/25 text-xs font-semibold tracking-wide cursor-pointer"
          >
            Desbloquear y volver a Mad Player
          </button>
        </div>
      </div>
    );
  }

  // 9. MODAL: ARCHIVOS OCULTOS / AJUSTES RÁPIDOS
  if (activeModal === 'settings') {
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div
          className="w-full max-w-lg rounded-2xl border p-6 flex flex-col gap-5"
          style={{
            backgroundColor: '#071a2e',
            borderColor: 'rgba(255,255,255,0.12)',
            color: '#f8fafc'
          }}
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h3 className="text-base font-bold font-display">
              Archivos Ocultos y Desvanecimiento
            </h3>
            <button onClick={() => onClose()} className="p-1 cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span>Duración de Reproducir/Pausar Desvanecimiento</span>
              <span className="font-mono-tabular text-sky-400">
                {playPauseFadeMs} Milisegundos
              </span>
            </div>
            <input
              type="range"
              min={100}
              max={1500}
              step={5}
              value={playPauseFadeMs}
              onChange={e => onChangePlayPauseFadeMs(Number(e.target.value))}
              className="w-full accent-sky-400 cursor-pointer"
            />
          </div>

          <div className="border-t border-white/10 pt-3">
            <h4 className="text-xs font-bold mb-2">Hidden Files ({hiddenTracks.length})</h4>
            {hiddenTracks.length === 0 ? (
              <p className="text-xs text-slate-400">No hay archivos ocultos actualmente.</p>
            ) : (
              <div className="flex flex-col gap-2 max-h-40 overflow-y-auto">
                {hiddenTracks.map(ht => (
                  <div
                    key={ht.id}
                    className="p-2 rounded-lg bg-slate-900 border border-white/10 flex items-center justify-between text-xs"
                  >
                    <span className="truncate">
                      {ht.title} — {ht.artist}
                    </span>
                    <button
                      onClick={() => onRestoreHiddenTrack(ht.id)}
                      className="px-2.5 py-1 rounded bg-sky-400 text-slate-950 font-semibold flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      <Eye className="w-3 h-3" />
                      Mostrar
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={() => onClose()}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-sky-400 text-slate-950 cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 10. MODAL: CONFIRMAR ELIMINACIÓN DEL DISPOSITIVO
  if (activeModal === 'delete-confirm') {
    return (
      <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div
          className="w-full max-w-sm rounded-2xl border p-6 flex flex-col gap-4"
          style={{
            backgroundColor: '#071a2e',
            borderColor: 'rgba(255,255,255,0.12)',
            color: '#f8fafc'
          }}
        >
          <h3 className="text-base font-bold font-display">¿Eliminar pista de la biblioteca?</h3>
          <p className="text-xs text-slate-300">
            Se eliminará <strong>{currentTrack.title}</strong> ({currentTrack.artist}) de tus
            listas y biblioteca activa.
          </p>
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              onClick={() => onOpenModal('action-sheet')}
              className="px-4 py-2 rounded-lg text-xs border border-white/15 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              onClick={() => {
                onDeleteTrack(currentTrack.id);
                onClose();
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-rose-600 text-white cursor-pointer"
            >
              Eliminar
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
