import React, { useState, useRef } from 'react';
import {
  ArrowLeft,
  ChevronDown,
  MoreVertical,
  Heart,
  ListMusic,
  Repeat,
  SkipBack,
  SkipForward,
  Play,
  Pause,
  Shuffle,
  Volume2,
  Share2,
  X,
  Plus,
  Check,
  Search,
  Menu,
  Music2,
  Sliders
} from 'lucide-react';
import { PlayerSkin, ThemeConfig, Track } from '../types/music';
import {
  saveWallpaperToDb,
  updateWallpaperMetaInDb
} from '../services/mediaStorageDb';

// Curated Wallpapers matching Screenshots 7 & 8
export interface PresetWallpaper {
  id: string;
  name: string;
  cssBg: string;
  imageUrl?: string;
  isPremiumBadge?: boolean;
}

export const PRESET_WALLPAPERS: PresetWallpaper[] = [
  {
    id: 'wp-navy-mist',
    name: 'Niebla Marina',
    cssBg:
      'radial-gradient(circle at 50% 25%, #163854 0%, #091d2e 55%, #040d17 100%)',
    imageUrl:
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=700&q=80'
  },
  {
    id: 'wp-slate-fog',
    name: 'Horizonte Gris',
    cssBg: 'linear-gradient(180deg, #4b5563 0%, #64748b 45%, #1e293b 100%)',
    imageUrl:
      'https://images.unsplash.com/photo-1485236715568-ddc5ee6ca227?auto=format&fit=crop&w=700&q=80'
  },
  {
    id: 'wp-indigo-aurora',
    name: 'Aurora Nocturna',
    cssBg: 'linear-gradient(180deg, #1e1b4b 0%, #311042 55%, #090a10 100%)',
    imageUrl:
      'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=700&q=80'
  },
  {
    id: 'wp-sunset-pines',
    name: 'Bosque al Atardecer',
    cssBg: 'linear-gradient(180deg, #3b2d54 0%, #7c3f58 55%, #120d17 100%)',
    imageUrl:
      'https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&w=700&q=80'
  },
  {
    id: 'wp-watchtower',
    name: 'Torre del Bosque',
    cssBg: 'linear-gradient(180deg, #0d2b3e 0%, #164e63 60%, #04131d 100%)',
    imageUrl:
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=80',
    isPremiumBadge: true
  },
  {
    id: 'wp-golden-gate',
    name: 'Puente al Ocaso',
    cssBg: 'linear-gradient(180deg, #153e4b 0%, #7c3f2c 60%, #141418 100%)',
    imageUrl:
      'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&w=700&q=80'
  }
];

export const PRESET_SOLID_COLORS: { id: string; name: string; hex: string }[] = [
  { id: 'col-muzio-navy', name: 'Mad Navy', hex: '#061928' },
  { id: 'col-amoled', name: 'Negro AMOLED', hex: '#040609' },
  { id: 'col-midnight', name: 'Azul Medianoche', hex: '#0f172a' },
  { id: 'col-forest', name: 'Bosque Profundo', hex: '#06201b' },
  { id: 'col-burgundy', name: 'Vino Nocturno', hex: '#230b14' },
  { id: 'col-charcoal', name: 'Carbón Studio', hex: '#141821' },
  { id: 'col-indigo', name: 'Índigo Real', hex: '#141230' }
];

export const PRESET_GRADIENTS: { id: string; name: string; css: string }[] = [
  {
    id: 'grad-ocean',
    name: 'Océano Profundo',
    css: 'linear-gradient(165deg, #0c2d48 0%, #051622 55%, #02080d 100%)'
  },
  {
    id: 'grad-nebula',
    name: 'Nebulosa Violeta',
    css: 'linear-gradient(165deg, #2e1065 0%, #170d36 55%, #070510 100%)'
  },
  {
    id: 'grad-sunset',
    name: 'Atardecer Carmesí',
    css: 'linear-gradient(165deg, #4c0519 0%, #1e1b4b 65%, #060913 100%)'
  },
  {
    id: 'grad-emerald',
    name: 'Aurora Esmeralda',
    css: 'linear-gradient(165deg, #064e3b 0%, #0f172a 65%, #030712 100%)'
  },
  {
    id: 'grad-amber',
    name: 'Destello Ámbar',
    css: 'linear-gradient(165deg, #451a03 0%, #1c1917 65%, #090a0f 100%)'
  },
  {
    id: 'grad-cyber',
    name: 'Cian Eléctrico',
    css: 'linear-gradient(165deg, #083344 0%, #1e1b4b 65%, #040711 100%)'
  }
];

// Page 1: Exact 16 colors from Screenshot 8 (4x4 grid)
export const ACCENT_COLORS_PAGE_1: string[] = [
  '#fbbf24', // Row 1 Col 1: Amber Gold
  '#f97316', // Row 1 Col 2: Orange
  '#f43f5e', // Row 1 Col 3: Crimson Rose
  '#ec4899', // Row 1 Col 4: Hot Pink
  '#d946ef', // Row 2 Col 1: Magenta Fuchsia
  '#6320ee', // Row 2 Col 2: Deep Purple
  '#4f6ef7', // Row 2 Col 3: Royal Indigo Blue
  '#2589f5', // Row 2 Col 4: Dodger Blue
  '#0ea5e9', // Row 3 Col 1: Sky Blue
  '#1cc8ee', // Row 3 Col 2: Muzio Cyan
  '#14dfb4', // Row 3 Col 3: Mint Turquoise
  '#10d468', // Row 3 Col 4: Vibrant Green
  '#65f00d', // Row 4 Col 1: Neon Lime
  '#b8f500', // Row 4 Col 2: Chartreuse
  '#facc15', // Row 4 Col 3: Bright Yellow
  '#ff4500'  // Row 4 Col 4: Red Orange
];

// Page 2: Additional colors + "+" Custom Color Picker button
export const ACCENT_COLORS_PAGE_2: string[] = [
  '#ff6b6b',
  '#a855f7',
  '#38bdf8',
  '#34d399',
  '#fb7185',
  '#818cf8',
  '#2dd4bf',
  '#f59e0b',
  '#e879f9',
  '#60a5fa',
  '#4ade80',
  '#f87171'
];

// 6 Player Skins matching Screenshots 1-6
export const PLAYER_SKINS_LIST: {
  id: PlayerSkin;
  name: string;
  sampleTitle: string;
  sampleArtist: string;
  sampleAlbum: string;
  sampleCover: string;
}[] = [
  {
    id: 'stacked-cards',
    name: 'Tarjetas Apiladas',
    sampleTitle: 'Shape of you',
    sampleArtist: 'Ed Sheeran',
    sampleAlbum: 'Divide',
    sampleCover:
      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'muzio-classic',
    name: 'Borde a Borde (Original)',
    sampleTitle: 'Baby One More Time',
    sampleArtist: 'Britney Spears',
    sampleAlbum: 'Divide',
    sampleCover:
      'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'vinyl-circle',
    name: 'Círculo Coral',
    sampleTitle: 'Shape of you',
    sampleArtist: 'Ed Sheeran',
    sampleAlbum: 'Divide',
    sampleCover:
      'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'full-bleed-dark',
    name: 'Inmersivo Pantalla Completa',
    sampleTitle: 'As Long As You Love Me',
    sampleArtist: 'Justin Bieber',
    sampleAlbum: 'Divide',
    sampleCover:
      'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'framed-card',
    name: 'Cuadro Clásico',
    sampleTitle: 'Shape of you',
    sampleArtist: 'Ed Sheeran',
    sampleAlbum: 'Divide',
    sampleCover:
      'https://images.unsplash.com/photo-1485236715568-ddc5ee6ca227?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'circle-cobalt',
    name: 'Círculo Cobalto',
    sampleTitle: 'Baby One More Time',
    sampleArtist: 'Britney Spears',
    sampleAlbum: 'Divide',
    sampleCover:
      'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=600&q=80'
  }
];

// ============================================================================
// COMPONENT 1: SWIPEABLE "TEMA DEL REPRODUCTOR" MODAL (Screenshots 1 to 6)
// ============================================================================
interface PlayerSkinCarouselModalProps {
  currentSkin: PlayerSkin;
  currentTrack?: Track;
  onClose: () => void;
  onApplySkin?: (skin: PlayerSkin) => void;
  onSelectSkin?: (skin: PlayerSkin) => void;
  onAfterApply?: () => void;
  showToast?: (msg: string) => void;
}

export const PlayerSkinCarouselModal: React.FC<PlayerSkinCarouselModalProps> = ({
  currentSkin,
  currentTrack,
  onClose,
  onApplySkin,
  onSelectSkin,
  onAfterApply,
  showToast
}) => {
  const initialIndex = Math.max(
    0,
    PLAYER_SKINS_LIST.findIndex(s => s.id === currentSkin)
  );
  const [activeIndex, setActiveIndex] = useState<number>(initialIndex);
  const [dragOffset, setDragOffset] = useState<number>(0);
  const startXRef = useRef<number | null>(null);

  const handleTouchStart = (clientX: number) => {
    startXRef.current = clientX;
  };

  const handleTouchMove = (clientX: number) => {
    if (startXRef.current === null) return;
    setDragOffset(clientX - startXRef.current);
  };

  const handleTouchEnd = () => {
    if (startXRef.current === null) return;
    if (dragOffset < -45 && activeIndex < PLAYER_SKINS_LIST.length - 1) {
      setActiveIndex(prev => prev + 1);
    } else if (dragOffset > 45 && activeIndex > 0) {
      setActiveIndex(prev => prev - 1);
    }
    startXRef.current = null;
    setDragOffset(0);
  };

  const selectedSkinObj = PLAYER_SKINS_LIST[activeIndex] || PLAYER_SKINS_LIST[0];
  const coverSrc = currentTrack?.coverUrl || selectedSkinObj.sampleCover;

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 select-none"
    >
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-[370px] rounded-3xl px-6 pt-6 pb-5 shadow-2xl flex flex-col justify-between gap-5 border border-white/10"
        style={{ backgroundColor: '#051b30', color: '#ffffff' }}
      >
        {/* Top Title with Back Button (←) */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              aria-label="Retroceder"
              className="w-9 h-9 rounded-full flex items-center justify-center text-slate-200 hover:bg-white/10 cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-extrabold font-display tracking-tight text-white">
              Tema del reproductor
            </h2>
          </div>
          <span className="text-xs font-extrabold text-[#6e8499] font-mono-tabular">
            {activeIndex + 1}/{PLAYER_SKINS_LIST.length}
          </span>
        </div>

        {/* Center Swipeable Preview Container (Screenshots 1-6) */}
        <div
          onTouchStart={e => handleTouchStart(e.touches[0].clientX)}
          onTouchMove={e => handleTouchMove(e.touches[0].clientX)}
          onTouchEnd={handleTouchEnd}
          onMouseDown={e => handleTouchStart(e.clientX)}
          onMouseMove={e => {
            if (startXRef.current !== null) handleTouchMove(e.clientX);
          }}
          onMouseUp={handleTouchEnd}
          onMouseLeave={handleTouchEnd}
          className="relative w-full aspect-[9/15.2] overflow-hidden shadow-2xl cursor-grab active:cursor-grabbing mx-auto"
          style={{
            transform: `translateX(${dragOffset * 0.25}px)`,
            transition: startXRef.current === null ? 'transform 200ms ease-out' : 'none'
          }}
        >
          {/* SKIN 1: STACKED CARDS (Screenshot 1) */}
          {selectedSkinObj.id === 'stacked-cards' && (
            <div className="w-full h-full flex flex-col justify-between bg-gradient-to-b from-[#d8892c] via-[#f0d8be] to-[#fbf7f4] text-[#5c4738] p-4 pt-5">
              {/* Stacked Cover Art with Green & Purple top cards */}
              <div className="relative pt-3 px-1">
                <div className="mx-6 h-2 rounded-t-md bg-[#2e7d32]" />
                <div className="mx-3 h-2 rounded-t-md bg-[#9c27b0]" />
                <div className="w-full aspect-square rounded-lg overflow-hidden shadow-xl bg-amber-900">
                  <img
                    src={coverSrc}
                    alt="Preview"
                    className="w-full h-full object-cover pointer-events-none"
                  />
                </div>
              </div>

              {/* Info Row */}
              <div className="flex items-center justify-between px-1 mt-1">
                <Heart className="w-4 h-4 fill-[#7d6250] text-[#7d6250]" />
                <div className="text-center min-w-0 px-2">
                  <p className="text-xs font-extrabold text-[#4a3728] truncate">
                    {selectedSkinObj.sampleTitle}
                  </p>
                  <p className="text-[10px] font-semibold text-[#8c7362] truncate">
                    {selectedSkinObj.sampleArtist}
                  </p>
                </div>
                <ListMusic className="w-4 h-4 text-[#7d6250]" />
              </div>

              {/* Progress Slider */}
              <div className="px-1">
                <div className="relative w-full h-[2px] bg-[#cbb8a8]">
                  <div className="w-2/3 h-full bg-[#8c7362]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-[#9aa8b8] absolute top-1/2 left-2/3 -translate-y-1/2 -translate-x-1/2 shadow" />
                </div>
                <div className="flex justify-between text-[9px] font-bold text-[#8c7362] mt-1">
                  <span>2:39</span>
                  <span>3:58</span>
                </div>
              </div>

              {/* Transport Controls */}
              <div className="flex items-center justify-between px-2">
                <Repeat className="w-3.5 h-3.5 text-[#7d6250]" />
                <SkipBack className="w-4 h-4 fill-[#7d6250] text-[#7d6250]" />
                <div className="w-10 h-10 rounded-full bg-[#f57c00] text-white flex items-center justify-center shadow-md">
                  <Pause className="w-4 h-4 fill-current" />
                </div>
                <SkipForward className="w-4 h-4 fill-[#7d6250] text-[#7d6250]" />
                <Shuffle className="w-3.5 h-3.5 text-[#7d6250]" />
              </div>

              {/* Bottom Bar */}
              <div className="flex items-center justify-between px-1 pt-1 text-[#7d6250]">
                <X className="w-3.5 h-3.5" />
                <div className="flex items-center gap-5">
                  <Volume2 className="w-3.5 h-3.5" />
                  <Share2 className="w-3.5 h-3.5" />
                  <MoreVertical className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          )}

          {/* SKIN 2: MUZIO CLASSIC EDGE-TO-EDGE (Screenshot 2) */}
          {selectedSkinObj.id === 'muzio-classic' && (
            <div className="w-full h-full flex flex-col justify-between bg-[#3c4b99] text-white">
              <div className="relative w-full aspect-square overflow-hidden shrink-0">
                <img
                  src={coverSrc}
                  alt="Preview"
                  className="w-full h-full object-cover pointer-events-none"
                />
                <ChevronDown className="w-4 h-4 text-white absolute top-3 left-3 drop-shadow" />
                <MoreVertical className="w-4 h-4 text-white absolute top-3 right-3 drop-shadow" />
              </div>

              {/* Flat Progress Strip */}
              <div>
                <div className="w-full h-2.5 bg-[#4d5aa3] relative">
                  <div className="w-2/3 h-full bg-[#9aa5d6] border-r-2 border-white" />
                </div>
                <div className="flex justify-between px-3 pt-1 text-[9px] font-bold text-white/60">
                  <span>2:39</span>
                  <span>3:58</span>
                </div>
              </div>

              {/* Info Row */}
              <div className="flex items-center justify-between px-4">
                <Heart className="w-4 h-4 fill-white text-white" />
                <div className="text-center min-w-0 px-2">
                  <p className="text-xs font-extrabold text-white truncate">
                    {selectedSkinObj.sampleTitle}
                  </p>
                  <p className="text-[10px] font-semibold text-white/65 truncate">
                    {selectedSkinObj.sampleArtist}
                  </p>
                </div>
                <ListMusic className="w-4 h-4 text-white" />
              </div>

              {/* Transport */}
              <div className="flex items-center justify-between px-5">
                <Repeat className="w-3.5 h-3.5 text-white/85" />
                <SkipBack className="w-4 h-4 fill-white text-white" />
                <div className="w-11 h-11 rounded-full bg-[#5294e2] text-white flex items-center justify-center shadow-md">
                  <Pause className="w-4 h-4 fill-current" />
                </div>
                <SkipForward className="w-4 h-4 fill-white text-white" />
                <Shuffle className="w-3.5 h-3.5 text-white/85" />
              </div>

              {/* Bottom Bar */}
              <div className="flex items-center justify-between px-4 pb-3 text-white/75 text-[9px] font-bold">
                <Volume2 className="w-3.5 h-3.5" />
                <span>7/21</span>
                <Share2 className="w-3.5 h-3.5" />
              </div>
            </div>
          )}

          {/* SKIN 3: VINYL CIRCLE CORAL GRADIENT (Screenshot 3) */}
          {selectedSkinObj.id === 'vinyl-circle' && (
            <div className="w-full h-full flex flex-col justify-between bg-gradient-to-b from-[#fd4958] via-[#b84c56] to-[#874349] text-white p-4">
              <div className="flex items-center justify-between text-[9px]">
                <ChevronDown className="w-4 h-4" />
                <div className="text-center leading-tight">
                  <p className="text-[8px] uppercase tracking-wider text-white/75">PLAYING FROM</p>
                  <p className="font-bold text-white">{selectedSkinObj.sampleAlbum}</p>
                </div>
                <MoreVertical className="w-4 h-4" />
              </div>

              {/* Circular Cover with Ring */}
              <div className="w-44 h-44 mx-auto rounded-full p-1.5 bg-white/15 shadow-xl flex items-center justify-center">
                <img
                  src={coverSrc}
                  alt="Preview"
                  className="w-full h-full rounded-full object-cover pointer-events-none"
                />
              </div>

              <div className="flex items-center justify-between px-1">
                <Heart className="w-4 h-4 fill-white text-white" />
                <div className="text-center min-w-0 px-2">
                  <p className="text-xs font-extrabold text-white truncate">
                    {selectedSkinObj.sampleTitle}
                  </p>
                  <p className="text-[10px] font-semibold text-white/75 truncate">
                    {selectedSkinObj.sampleArtist}
                  </p>
                </div>
                <ListMusic className="w-4 h-4 text-white" />
              </div>

              <div className="px-1">
                <div className="relative w-full h-[2px] bg-white/30">
                  <div className="w-2/3 h-full bg-white" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white absolute top-1/2 left-2/3 -translate-y-1/2 -translate-x-1/2" />
                </div>
                <div className="flex justify-between text-[9px] font-bold text-white/75 mt-1">
                  <span>2:39</span>
                  <span>3:58</span>
                </div>
              </div>

              <div className="flex items-center justify-between px-2 pb-1">
                <Repeat className="w-3.5 h-3.5 text-white/85" />
                <SkipBack className="w-4 h-4 fill-white text-white" />
                <div className="w-10 h-10 rounded-full bg-white text-[#874349] flex items-center justify-center shadow-md">
                  <Pause className="w-4 h-4 fill-current" />
                </div>
                <SkipForward className="w-4 h-4 fill-white text-white" />
                <Shuffle className="w-3.5 h-3.5 text-white/85" />
              </div>
            </div>
          )}

          {/* SKIN 4: FULL-BLEED DARK IMMERSIVE (Screenshot 4) */}
          {selectedSkinObj.id === 'full-bleed-dark' && (
            <div className="relative w-full h-full flex flex-col justify-between text-white p-4">
              <img
                src={coverSrc}
                alt="Preview"
                className="absolute inset-0 w-full h-full object-cover pointer-events-none"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/95 pointer-events-none" />

              <div className="relative z-10 flex items-center justify-between text-[9px]">
                <ChevronDown className="w-4 h-4" />
                <div className="text-center leading-tight">
                  <p className="text-[8px] uppercase tracking-wider text-white/75">PLAYING FROM</p>
                  <p className="font-bold text-white">{selectedSkinObj.sampleAlbum}</p>
                </div>
                <MoreVertical className="w-4 h-4" />
              </div>

              <div className="relative z-10 flex flex-col gap-3 pt-28">
                <div className="flex items-center justify-between px-1">
                  <Heart className="w-4 h-4 text-white" />
                  <div className="text-center min-w-0 px-2">
                    <p className="text-xs font-extrabold text-white truncate">
                      {selectedSkinObj.sampleTitle}
                    </p>
                    <p className="text-[10px] font-semibold text-white/65 truncate">
                      {selectedSkinObj.sampleArtist}
                    </p>
                  </div>
                  <ListMusic className="w-4 h-4 text-white" />
                </div>

                <div className="px-1">
                  <div className="relative w-full h-[2px] bg-white/40">
                    <div className="w-2/3 h-full bg-[#e09145]" />
                    <div className="w-2.5 h-2.5 rounded-full bg-white absolute top-1/2 left-2/3 -translate-y-1/2 -translate-x-1/2" />
                  </div>
                  <div className="flex justify-between text-[9px] font-bold text-white/70 mt-1">
                    <span>2:39</span>
                    <span>3:58</span>
                  </div>
                </div>

                <div className="flex items-center justify-between px-2">
                  <Repeat className="w-3.5 h-3.5 text-white" />
                  <SkipBack className="w-4 h-4 fill-white text-white" />
                  <div className="w-10 h-10 rounded-full border-2 border-white/80 text-white flex items-center justify-center">
                    <Pause className="w-4 h-4 fill-current" />
                  </div>
                  <SkipForward className="w-4 h-4 fill-white text-white" />
                  <Shuffle className="w-3.5 h-3.5 text-white" />
                </div>

                <div className="flex items-center justify-between px-1 pt-1 text-white/80 text-[9px] font-bold">
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>7/21</span>
                  <Share2 className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          )}

          {/* SKIN 5: FRAMED CLASSIC CARD (Screenshot 5) */}
          {selectedSkinObj.id === 'framed-card' && (
            <div className="w-full h-full flex flex-col justify-between bg-[#374270] text-white p-4">
              <div className="flex items-center justify-between text-[9px]">
                <ChevronDown className="w-4 h-4 text-white/80" />
                <div className="text-center leading-tight">
                  <p className="text-[8px] uppercase tracking-wider text-white/60">PLAYING FROM</p>
                  <p className="font-bold text-white/90">{selectedSkinObj.sampleAlbum}</p>
                </div>
                <MoreVertical className="w-4 h-4 text-white/80" />
              </div>

              <div className="w-full aspect-square overflow-hidden shadow-lg bg-slate-800 my-1">
                <img
                  src={coverSrc}
                  alt="Preview"
                  className="w-full h-full object-cover pointer-events-none"
                />
              </div>

              <div className="flex items-center justify-between px-1">
                <Heart className="w-4 h-4 fill-[#cbd5e1] text-[#cbd5e1]" />
                <div className="text-center min-w-0 px-2">
                  <p className="text-xs font-extrabold text-[#e2e8f0] truncate">
                    {selectedSkinObj.sampleTitle}
                  </p>
                  <p className="text-[10px] font-semibold text-[#94a3b8] truncate">
                    {selectedSkinObj.sampleArtist}
                  </p>
                </div>
                <ListMusic className="w-4 h-4 text-[#cbd5e1]" />
              </div>

              <div className="px-1">
                <div className="relative w-full h-[2px] bg-white/20">
                  <div className="w-2/3 h-full bg-[#94a3b8]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-[#94a3b8] absolute top-1/2 left-2/3 -translate-y-1/2 -translate-x-1/2" />
                </div>
                <div className="flex justify-between text-[9px] font-bold text-[#94a3b8] mt-1">
                  <span>2:39</span>
                  <span>3:58</span>
                </div>
              </div>

              <div className="flex items-center justify-between px-2 pb-1">
                <Repeat className="w-3.5 h-3.5 text-[#cbd5e1]" />
                <SkipBack className="w-4 h-4 fill-[#cbd5e1] text-[#cbd5e1]" />
                <div className="w-10 h-10 rounded-full bg-[#cbd5e1] text-[#374270] flex items-center justify-center shadow-md">
                  <Pause className="w-4 h-4 fill-current" />
                </div>
                <SkipForward className="w-4 h-4 fill-[#cbd5e1] text-[#cbd5e1]" />
                <Shuffle className="w-3.5 h-3.5 text-[#cbd5e1]" />
              </div>
            </div>
          )}

          {/* SKIN 6: CIRCLE COBALT (Screenshot 6) */}
          {selectedSkinObj.id === 'circle-cobalt' && (
            <div className="w-full h-full flex flex-col justify-between bg-[#00509d] text-white p-4">
              <div className="flex items-center justify-between text-[9px]">
                <ChevronDown className="w-4 h-4" />
                <div className="text-center leading-tight">
                  <p className="text-[8px] uppercase tracking-wider text-white/70">PLAYING FROM</p>
                  <p className="font-bold text-white">{selectedSkinObj.sampleAlbum}</p>
                </div>
                <MoreVertical className="w-4 h-4" />
              </div>

              <div className="w-44 h-44 mx-auto rounded-full p-1.5 bg-white/10 shadow-xl flex items-center justify-center">
                <img
                  src={coverSrc}
                  alt="Preview"
                  className="w-full h-full rounded-full object-cover pointer-events-none"
                />
              </div>

              <div className="flex items-center justify-between px-1">
                <Heart className="w-4 h-4 fill-white text-white" />
                <div className="text-center min-w-0 px-2">
                  <p className="text-xs font-extrabold text-white truncate">
                    {selectedSkinObj.sampleTitle}
                  </p>
                  <p className="text-[10px] font-semibold text-white/70 truncate">
                    {selectedSkinObj.sampleArtist}
                  </p>
                </div>
                <ListMusic className="w-4 h-4 text-white" />
              </div>

              <div className="flex items-center justify-between px-2">
                <Repeat className="w-3.5 h-3.5 text-white/85" />
                <SkipBack className="w-4 h-4 fill-white text-white" />
                <div className="w-10 h-10 rounded-full bg-[#4ea8de] text-white flex items-center justify-center shadow-md">
                  <Pause className="w-4 h-4 fill-current" />
                </div>
                <SkipForward className="w-4 h-4 fill-white text-white" />
                <Shuffle className="w-3.5 h-3.5 text-white/85" />
              </div>

              <div className="flex items-center justify-between px-1 text-white/75 text-[9px] font-bold">
                <Volume2 className="w-3.5 h-3.5" />
                <span>7/21</span>
                <Share2 className="w-3.5 h-3.5" />
              </div>
            </div>
          )}
        </div>

        {/* Dot Indicators for Swipe Navigation */}
        <div className="flex items-center justify-center gap-1.5">
          {PLAYER_SKINS_LIST.map((s, idx) => (
            <button
              key={s.id}
              onClick={() => setActiveIndex(idx)}
              aria-label={s.name}
              className={`h-1.5 rounded-full transition-all cursor-pointer ${
                idx === activeIndex ? 'w-5 bg-[#1cc8ee]' : 'w-1.5 bg-white/25'
              }`}
            />
          ))}
        </div>

        {/* Bottom Actions: Cancelar & Poner (Exact Match to Screenshots 1-6) */}
        <div className="flex items-center justify-end gap-7 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="text-base font-extrabold text-white hover:text-slate-300 cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={() => {
              onApplySkin?.(selectedSkinObj.id);
              onSelectSkin?.(selectedSkinObj.id);
              showToast?.(`Tema del reproductor aplicado: ${selectedSkinObj.name}`);
              if (onAfterApply) {
                onAfterApply();
              } else {
                onClose();
              }
            }}
            className="text-base font-extrabold text-[#1cc8ee] hover:text-white cursor-pointer"
          >
            Poner
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// COMPONENT 2: "ELEGIR TEMA" SCREEN + "COLOR ÉNFASIS" MODAL + GALLERY ALPHA/BLUR
// (Exact Match to Screenshots 7 & 8)
// ============================================================================
export interface ThemeStudioModalProps {
  themeConfig: ThemeConfig;
  onUpdateThemeConfig: React.Dispatch<React.SetStateAction<ThemeConfig>>;
  onBack?: () => void;
  onClose?: () => void;
  currentTrack?: Track;
  tracks?: Track[];
  showToast: (msg: string) => void;
}

export const ThemeStudioModal: React.FC<ThemeStudioModalProps> = ({
  themeConfig,
  onUpdateThemeConfig,
  onBack,
  onClose,
  showToast
}) => {
  const handleBackAction = () => {
    if (showAccentModal) {
      setShowAccentModal(false);
      return;
    }
    if (editingGalleryImage) {
      if (
        editingGalleryImage.url.startsWith('blob:') &&
        editingGalleryImage.url !== themeConfig.bgImageUrl
      ) {
        URL.revokeObjectURL(editingGalleryImage.url);
      }
      setEditingGalleryImage(null);
      return;
    }
    if (onBack) {
      onBack();
    } else if (onClose) {
      onClose();
    }
  };
  const [activeCategory, setActiveCategory] = useState<'image' | 'color' | 'gradient'>(
    themeConfig.appBgMode || 'image'
  );

  // Color Énfasis Modal State (Screenshot 8)
  const [showAccentModal, setShowAccentModal] = useState<boolean>(false);
  const [accentPage, setAccentPage] = useState<0 | 1>(0);
  const [draftAccentHex, setDraftAccentHex] = useState<string>(
    themeConfig.customAccentHex || '#1cc8ee'
  );
  const accentTouchStartX = useRef<number | null>(null);
  const customColorInputRef = useRef<HTMLInputElement | null>(null);
  const customSolidBgInputRef = useRef<HTMLInputElement | null>(null);

  // Gallery Image Upload & Alpha/Blur Editor State
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const [editingGalleryImage, setEditingGalleryImage] = useState<{
    url: string;
    file?: File;
    alpha: number;
    blur: number;
  } | null>(null);

  const activeAccent = themeConfig.useCustomAccent
    ? themeConfig.customAccentHex
    : '#1cc8ee';

  const currentWallpaper =
    PRESET_WALLPAPERS.find(w => w.id === (themeConfig.bgImageId || 'wp-navy-mist')) ||
    PRESET_WALLPAPERS[0];

  // Handle Gallery Image Selection -> Opens Alpha & Blur Live Preview Editor
  const handleSelectGalleryImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (
      editingGalleryImage?.url &&
      editingGalleryImage.url.startsWith('blob:') &&
      editingGalleryImage.url !== themeConfig.bgImageUrl
    ) {
      URL.revokeObjectURL(editingGalleryImage.url);
    }
    const url = URL.createObjectURL(file);
    e.target.value = '';
    setEditingGalleryImage({
      url,
      file,
      alpha: themeConfig.bgImageAlpha ?? 0.65,
      blur: themeConfig.bgImageBlur ?? 4
    });
  };

  const handleApplyGalleryImage = () => {
    if (!editingGalleryImage) return;

    if (editingGalleryImage.file) {
      const customId = `custom-wp-${Date.now()}`;
      saveWallpaperToDb(
        customId,
        editingGalleryImage.file,
        editingGalleryImage.alpha,
        editingGalleryImage.blur,
        true
      );
      onUpdateThemeConfig(prev => {
        if (
          prev.bgImageUrl &&
          prev.bgImageUrl.startsWith('blob:') &&
          prev.bgImageUrl !== editingGalleryImage.url
        ) {
          URL.revokeObjectURL(prev.bgImageUrl);
        }
        (prev.customUserImages || []).forEach(oldImg => {
          if (
            oldImg.url &&
            oldImg.url.startsWith('blob:') &&
            oldImg.url !== editingGalleryImage.url &&
            oldImg.url !== prev.bgImageUrl
          ) {
            URL.revokeObjectURL(oldImg.url);
          }
        });
        return {
          ...prev,
          appBgMode: 'image',
          bgImageId: customId,
          bgImageUrl: editingGalleryImage.url,
          bgImageAlpha: editingGalleryImage.alpha,
          bgImageBlur: editingGalleryImage.blur,
          customUserImages: [
            {
              id: customId,
              url: editingGalleryImage.url,
              alpha: editingGalleryImage.alpha,
              blur: editingGalleryImage.blur
            }
          ]
        };
      });
    } else {
      if (themeConfig.bgImageId && themeConfig.bgImageId.startsWith('custom-wp-')) {
        updateWallpaperMetaInDb(
          themeConfig.bgImageId,
          editingGalleryImage.alpha,
          editingGalleryImage.blur
        );
      }
      onUpdateThemeConfig(prev => ({
        ...prev,
        appBgMode: 'image',
        bgImageUrl: editingGalleryImage.url,
        bgImageAlpha: editingGalleryImage.alpha,
        bgImageBlur: editingGalleryImage.blur,
        customUserImages: (prev.customUserImages || []).map(img =>
          img.id === prev.bgImageId
            ? { ...img, alpha: editingGalleryImage.alpha, blur: editingGalleryImage.blur }
            : img
        )
      }));
    }

    setEditingGalleryImage(null);
    showToast('Fondo personalizado con Alpha y Blur aplicado');
  };

  // Compute live preview background styles
  const previewBgMode = editingGalleryImage ? 'image' : themeConfig.appBgMode || 'image';
  const previewImageUrl = editingGalleryImage
    ? editingGalleryImage.url
    : themeConfig.bgImageUrl || currentWallpaper.imageUrl;
  const previewAlpha = editingGalleryImage
    ? editingGalleryImage.alpha
    : themeConfig.bgImageAlpha ?? 0.7;
  const previewBlur = editingGalleryImage
    ? editingGalleryImage.blur
    : themeConfig.bgImageBlur ?? 0;

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col justify-between overflow-y-auto select-none">
      {/* Hidden Gallery Input & Custom Color Inputs */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        onChange={handleSelectGalleryImage}
        className="hidden"
      />
      <input
        ref={customColorInputRef}
        type="color"
        value={draftAccentHex}
        onChange={e => {
          const hex = e.target.value;
          setDraftAccentHex(hex);
          onUpdateThemeConfig(prev => ({
            ...prev,
            useCustomAccent: true,
            customAccentHex: hex,
            adaptToCoverArt: false,
            customUserAccents: Array.from(new Set([hex, ...(prev.customUserAccents || [])]))
          }));
        }}
        className="hidden"
      />
      <input
        ref={customSolidBgInputRef}
        type="color"
        value={themeConfig.bgColorHex || '#061928'}
        onChange={e => {
          const hex = e.target.value;
          onUpdateThemeConfig(prev => ({
            ...prev,
            appBgMode: 'color',
            bgColorHex: hex,
            adaptToCoverArt: false
          }));
        }}
        className="hidden"
      />

      {/* Top Header: <- Elegir Tema */}
      <div className="flex items-center justify-between px-4 py-4 shrink-0">
        <div className="flex items-center gap-5">
          <button
            type="button"
            onClick={handleBackAction}
            aria-label="Retroceder"
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-extrabold font-display tracking-tight text-white">
            Elegir Tema
          </h1>
        </div>

        {/* If user has a custom or preset image active, allow opening Alpha & Blur editor anytime */}
        {previewBgMode === 'image' && !editingGalleryImage && (
          <button
            onClick={() =>
              setEditingGalleryImage({
                url: previewImageUrl || '',
                alpha: previewAlpha,
                blur: previewBlur
              })
            }
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5" style={{ color: activeAccent }} />
            <span>Alpha / Blur</span>
          </button>
        )}
      </div>

      {/* CENTER: LIVE PHONE MOCKUP PREVIEW (Exact Match to Screenshot 7) */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-2 min-h-[340px]">
        <div
          className="relative w-full max-w-[250px] aspect-[9/16] rounded-xl overflow-hidden shadow-2xl border border-white/10 flex flex-col justify-between"
          style={{
            background:
              previewBgMode === 'color'
                ? themeConfig.bgColorHex || '#061928'
                : previewBgMode === 'gradient'
                  ? themeConfig.bgGradientCss || PRESET_GRADIENTS[0].css
                  : currentWallpaper.cssBg
          }}
        >
          {/* Background Image Layer with Live Alpha & Blur */}
          {previewBgMode === 'image' && previewImageUrl && (
            <>
              <img
                src={previewImageUrl}
                alt="Theme Preview"
                className="absolute inset-0 w-full h-full object-cover pointer-events-none transition-all"
                style={{
                  opacity: previewAlpha,
                  filter: `blur(${previewBlur}px) scale(1.06)`
                }}
              />
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  backgroundColor: `rgba(4, 15, 26, ${Math.max(0.15, 1 - previewAlpha)})`
                }}
              />
            </>
          )}

          {/* Top Mock App Header */}
          <div className="relative z-10 flex flex-col">
            <div className="flex items-center justify-between px-3 pt-3 pb-2">
              <div className="flex items-center gap-2.5">
                <Menu className="w-3.5 h-3.5 text-slate-300" />
                <span className="text-xs font-extrabold text-white tracking-tight">
                  Mad Player
                </span>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <Search className="w-3.5 h-3.5" />
                <MoreVertical className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Mock Tabs */}
            <div className="flex items-center gap-3 px-3 border-b border-white/10 text-[9px] font-extrabold text-slate-400">
              <span className="py-1.5">Sugirió</span>
              <span
                className="py-1.5 text-white border-b-2"
                style={{ borderColor: activeAccent }}
              >
                Canciones
              </span>
              <span className="py-1.5">Álbumes</span>
              <span className="py-1.5">Artistas</span>
              <span className="py-1.5">Ca</span>
            </div>

            {/* Mock Song List */}
            <div className="flex flex-col gap-2 px-3 pt-2.5">
              {[
                { title: 'November Rain', artist: 'Guns n Roses', active: false },
                { title: 'Wonderful Tonight', artist: 'Eric Clapton', active: true },
                { title: 'Brothers in Arms', artist: 'Dire Straits', active: false },
                { title: 'Everything I Do', artist: 'Bryan Adams', active: false },
                { title: 'The Final Cut', artist: 'Pink Floyd', active: false },
                { title: 'Letter Song', artist: 'Hatsune Miku', active: false }
              ].map((song, idx) => (
                <div key={idx} className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-6 h-6 rounded bg-white/15 flex items-center justify-center shrink-0">
                      <Music2 className="w-3.5 h-3.5 text-slate-300" />
                    </div>
                    <div className="min-w-0 leading-tight">
                      <p
                        className="text-[9px] font-extrabold truncate"
                        style={{ color: song.active ? activeAccent : '#ffffff' }}
                      >
                        {song.title}
                      </p>
                      <p
                        className="text-[7px] font-bold truncate"
                        style={{ color: song.active ? activeAccent : '#94a3b8' }}
                      >
                        {song.artist}
                      </p>
                    </div>
                  </div>
                  <MoreVertical className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                </div>
              ))}
            </div>
          </div>

          {/* Floating Shuffle FAB + Mini Player Bar */}
          <div className="relative z-10 flex flex-col gap-2">
            <div className="flex justify-end px-3">
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center shadow-lg"
                style={{ backgroundColor: activeAccent }}
              >
                <Shuffle className="w-3.5 h-3.5 text-slate-950" />
              </div>
            </div>

            <div className="bg-black/45 backdrop-blur-md px-2.5 py-1.5 flex flex-col gap-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded bg-white/15 flex items-center justify-center">
                    <Music2 className="w-3 h-3 text-slate-300" />
                  </div>
                  <div className="leading-none">
                    <p className="text-[8px] font-extrabold text-white">Wonderful Tonight</p>
                    <p className="text-[6px] text-slate-400 mt-0.5">Eric Clapton</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-white">
                  <Play className="w-3 h-3 fill-current" />
                  <ListMusic className="w-3 h-3" />
                </div>
              </div>
              <div className="w-full h-[2px] bg-white/15">
                <div className="w-3/5 h-full" style={{ backgroundColor: activeAccent }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* LIVE GALLERY IMAGE ALPHA & BLUR EDITOR PANEL (When user selects an image from gallery) */}
      {editingGalleryImage && (
        <div className="mx-4 mb-3 p-4 rounded-2xl bg-[#0b2239] border border-white/15 flex flex-col gap-3 shadow-2xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
              Editar Fondo (Previsualización en vivo)
            </span>
            <button
              onClick={() => {
                if (
                  editingGalleryImage.url.startsWith('blob:') &&
                  editingGalleryImage.url !== themeConfig.bgImageUrl
                ) {
                  URL.revokeObjectURL(editingGalleryImage.url);
                }
                setEditingGalleryImage(null);
              }}
              className="text-xs font-bold text-slate-400 hover:text-white cursor-pointer"
            >
              Cancelar
            </button>
          </div>

          {/* Alpha (Opacidad) Slider */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-extrabold">
              <span>Alpha (Opacidad de imagen)</span>
              <span style={{ color: activeAccent }}>
                {Math.round(editingGalleryImage.alpha * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.15}
              max={1}
              step={0.05}
              value={editingGalleryImage.alpha}
              onChange={e =>
                setEditingGalleryImage(prev =>
                  prev ? { ...prev, alpha: Number(e.target.value) } : null
                )
              }
              className="w-full cursor-pointer"
              style={{ accentColor: activeAccent }}
            />
          </div>

          {/* Blur (Desenfoque) Slider */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-extrabold">
              <span>Blur (Desenfoque)</span>
              <span style={{ color: activeAccent }}>{editingGalleryImage.blur} px</span>
            </div>
            <input
              type="range"
              min={0}
              max={25}
              step={1}
              value={editingGalleryImage.blur}
              onChange={e =>
                setEditingGalleryImage(prev =>
                  prev ? { ...prev, blur: Number(e.target.value) } : null
                )
              }
              className="w-full cursor-pointer"
              style={{ accentColor: activeAccent }}
            />
          </div>

          <button
            onClick={handleApplyGalleryImage}
            className="py-2 rounded-xl text-xs font-extrabold text-slate-950 cursor-pointer"
            style={{ backgroundColor: activeAccent }}
          >
            Aplicar imagen con Alpha y Blur
          </button>
        </div>
      )}

      {/* BOTTOM SELECTOR BAR: Imagen | Colores | Degradado + Circular Accent Button on Right (Screenshot 7) */}
      <div className="bg-[#05080c] pt-2 pb-6 px-4 flex flex-col gap-4 border-t border-white/10 shrink-0">
        <div className="flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-6">
            {(
              [
                { id: 'image', label: 'Imagen' },
                { id: 'color', label: 'Colores' },
                { id: 'gradient', label: 'Degradado' }
              ] as const
            ).map(tab => {
              const active = activeCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveCategory(tab.id)}
                  className="py-2.5 text-base font-extrabold tracking-tight border-b-[3px] transition-colors cursor-pointer"
                  style={{
                    color: active ? '#ffffff' : '#7c93a8',
                    borderColor: active ? activeAccent : 'transparent'
                  }}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Circular Accent Color Button next to Degradado -> Opens "Color Énfasis" modal (Screenshot 8) */}
          <button
            onClick={() => {
              setDraftAccentHex(activeAccent);
              setShowAccentModal(true);
            }}
            aria-label="Elegir Color Énfasis"
            className="w-9 h-9 rounded-full p-0.5 border-2 flex items-center justify-center cursor-pointer transition-transform active:scale-95"
            style={{ borderColor: activeAccent }}
          >
            <span
              className="w-full h-full rounded-full"
              style={{ backgroundColor: activeAccent }}
            />
          </button>
        </div>

        {/* CAROUSEL 1: IMAGEN (Plus button for Gallery + Preset & Custom Wallpapers) */}
        {activeCategory === 'image' && (
          <div className="flex items-center gap-3.5 overflow-x-auto pb-2 no-scrollbar">
            {/* Circular "+" Button to pick image from Gallery */}
            <button
              onClick={() => galleryInputRef.current?.click()}
              aria-label="Elegir imagen de la galería"
              className="w-12 h-12 rounded-full bg-[#141a22] border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/10 cursor-pointer"
            >
              <Plus className="w-6 h-6 text-white" />
            </button>

            {/* User's Custom Uploaded Gallery Images */}
            {(themeConfig.customUserImages || []).map(customImg => {
              const isSelected =
                themeConfig.appBgMode === 'image' && themeConfig.bgImageId === customImg.id;
              return (
                <div
                  key={customImg.id}
                  onClick={() => {
                    onUpdateThemeConfig(prev => ({
                      ...prev,
                      appBgMode: 'image',
                      bgImageId: customImg.id,
                      bgImageUrl: customImg.url,
                      bgImageAlpha: customImg.alpha,
                      bgImageBlur: customImg.blur
                    }));
                  }}
                  className={`relative w-24 h-36 rounded-xl overflow-hidden shrink-0 cursor-pointer border-2 transition-all ${
                    isSelected ? 'border-white scale-[1.02]' : 'border-transparent opacity-80'
                  }`}
                >
                  <img
                    src={customImg.url}
                    alt="Fondo personalizado"
                    className="w-full h-full object-cover"
                    style={{
                      opacity: customImg.alpha,
                      filter: `blur(${Math.min(8, customImg.blur)}px)`
                    }}
                  />
                  {isSelected && (
                    <div className="absolute inset-0 bg-black/25 flex items-center justify-center">
                      <Check className="w-7 h-7 text-white stroke-[2.5]" />
                    </div>
                  )}
                </div>
              );
            })}

            {/* Curated Preset Wallpapers (Screenshots 7 & 8) */}
            {PRESET_WALLPAPERS.map(wp => {
              const isSelected =
                (themeConfig.appBgMode || 'image') === 'image' &&
                (themeConfig.bgImageId || 'wp-navy-mist') === wp.id;
              return (
                <div
                  key={wp.id}
                  onClick={() => {
                    onUpdateThemeConfig(prev => ({
                      ...prev,
                      appBgMode: 'image',
                      bgImageId: wp.id,
                      bgImageUrl: wp.imageUrl || undefined,
                      bgGradientCss: !wp.imageUrl ? wp.cssBg : prev.bgGradientCss,
                      bgImageAlpha: prev.bgImageAlpha ?? 0.7,
                      bgImageBlur: prev.bgImageBlur ?? 0
                    }));
                  }}
                  className={`relative w-24 h-36 rounded-xl overflow-hidden shrink-0 cursor-pointer border-2 transition-all ${
                    isSelected ? 'border-white scale-[1.02]' : 'border-white/10 opacity-85'
                  }`}
                  style={{ background: wp.cssBg }}
                >
                  {wp.imageUrl && (
                    <img
                      src={wp.imageUrl}
                      alt={wp.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover opacity-80"
                    />
                  )}
                  {isSelected && (
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                      <Check className="w-7 h-7 text-white stroke-[2.5]" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* CAROUSEL 2: COLORES (Solid Background Colors + "+" Custom Color) */}
        {activeCategory === 'color' && (
          <div className="flex items-center gap-3.5 overflow-x-auto pb-2 no-scrollbar">
            <button
              onClick={() => customSolidBgInputRef.current?.click()}
              aria-label="Color de fondo personalizado"
              className="w-12 h-12 rounded-full bg-[#141a22] border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/10 cursor-pointer"
            >
              <Plus className="w-6 h-6 text-white" />
            </button>

            {PRESET_SOLID_COLORS.map(col => {
              const isSelected =
                themeConfig.appBgMode === 'color' && themeConfig.bgColorHex === col.hex;
              return (
                <div
                  key={col.id}
                  onClick={() => {
                    onUpdateThemeConfig(prev => ({
                      ...prev,
                      appBgMode: 'color',
                      bgColorHex: col.hex,
                      adaptToCoverArt: false
                    }));
                  }}
                  className={`relative w-24 h-36 rounded-xl shrink-0 cursor-pointer border-2 flex items-center justify-center transition-all ${
                    isSelected ? 'border-white scale-[1.02]' : 'border-white/10'
                  }`}
                  style={{ backgroundColor: col.hex }}
                >
                  {isSelected && <Check className="w-7 h-7 text-white stroke-[2.5]" />}
                </div>
              );
            })}
          </div>
        )}

        {/* CAROUSEL 3: DEGRADADO (Multi-stop Gradient Backgrounds) */}
        {activeCategory === 'gradient' && (
          <div className="flex items-center gap-3.5 overflow-x-auto pb-2 no-scrollbar">
            {PRESET_GRADIENTS.map(grad => {
              const isSelected =
                themeConfig.appBgMode === 'gradient' && themeConfig.bgGradientCss === grad.css;
              return (
                <div
                  key={grad.id}
                  onClick={() => {
                    onUpdateThemeConfig(prev => ({
                      ...prev,
                      appBgMode: 'gradient',
                      bgGradientCss: grad.css
                    }));
                  }}
                  className={`relative w-24 h-36 rounded-xl shrink-0 cursor-pointer border-2 flex items-center justify-center transition-all ${
                    isSelected ? 'border-white scale-[1.02]' : 'border-white/10'
                  }`}
                  style={{ background: grad.css }}
                >
                  {isSelected && <Check className="w-7 h-7 text-white stroke-[2.5]" />}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* =====================================================================
          MODAL: "COLOR ÉNFASIS" (Exact Match to Screenshot 8 + Swipeable 2nd Page with "+" Button)
         ===================================================================== */}
      {showAccentModal && (
        <div
          onClick={() => setShowAccentModal(false)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div
            onClick={e => e.stopPropagation()}
            onTouchStart={e => {
              accentTouchStartX.current = e.touches[0].clientX;
            }}
            onTouchEnd={e => {
              if (accentTouchStartX.current === null) return;
              const dx = (e.changedTouches[0]?.clientX ?? 0) - accentTouchStartX.current;
              if (dx < -40) setAccentPage(1);
              if (dx > 40) setAccentPage(0);
              accentTouchStartX.current = null;
            }}
            className="w-full max-w-[360px] rounded-3xl p-6 shadow-2xl flex flex-col gap-5 border border-white/10"
            style={{ backgroundColor: '#051b30', color: '#ffffff' }}
          >
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setShowAccentModal(false)}
                aria-label="Retroceder a Elegir Tema"
                className="w-9 h-9 rounded-full flex items-center justify-center text-slate-200 hover:bg-white/10 cursor-pointer"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h2 className="text-xl font-extrabold font-display tracking-tight text-white">
                Color Énfasis
              </h2>
            </div>

            {/* Page Indicator Dots (● •) — Tappable or Swipeable */}
            <div className="flex items-center justify-center gap-2.5">
              <button
                onClick={() => setAccentPage(0)}
                aria-label="Página 1 de colores"
                className={` rounded-full transition-all cursor-pointer ${
                  accentPage === 0 ? 'w-2.5 h-2.5 bg-white' : 'w-1.5 h-1.5 bg-white/40'
                }`}
              />
              <button
                onClick={() => setAccentPage(1)}
                aria-label="Página 2 de colores y color personalizado"
                className={`rounded-full transition-all cursor-pointer ${
                  accentPage === 1 ? 'w-2.5 h-2.5 bg-white' : 'w-1.5 h-1.5 bg-white/40'
                }`}
              />
            </div>

            {/* 4x4 Color Swatches Grid */}
            {accentPage === 0 ? (
              <div className="grid grid-cols-4 gap-4 place-items-center py-1">
                {ACCENT_COLORS_PAGE_1.map(hex => {
                  const selected = draftAccentHex.toLowerCase() === hex.toLowerCase();
                  return (
                    <button
                      key={hex}
                      onClick={() => {
                        setDraftAccentHex(hex);
                        onUpdateThemeConfig(prev => ({
                          ...prev,
                          useCustomAccent: true,
                          customAccentHex: hex,
                          adaptToCoverArt: false
                        }));
                      }}
                      className="w-14 h-14 rounded-full border-2 border-white flex items-center justify-center shadow-md transition-transform active:scale-90 cursor-pointer"
                      style={{ backgroundColor: hex }}
                    >
                      {selected && <Check className="w-6 h-6 text-slate-950 stroke-[3]" />}
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="grid grid-cols-4 gap-4 place-items-center py-1">
                {ACCENT_COLORS_PAGE_2.map(hex => {
                  const selected = draftAccentHex.toLowerCase() === hex.toLowerCase();
                  return (
                    <button
                      key={hex}
                      onClick={() => {
                        setDraftAccentHex(hex);
                        onUpdateThemeConfig(prev => ({
                          ...prev,
                          useCustomAccent: true,
                          customAccentHex: hex,
                          adaptToCoverArt: false
                        }));
                      }}
                      className="w-14 h-14 rounded-full border-2 border-white flex items-center justify-center shadow-md transition-transform active:scale-90 cursor-pointer"
                      style={{ backgroundColor: hex }}
                    >
                      {selected && <Check className="w-6 h-6 text-slate-950 stroke-[3]" />}
                    </button>
                  );
                })}

                {/* User's Custom Saved Accents */}
                {(themeConfig.customUserAccents || []).slice(0, 3).map(hex => {
                  const selected = draftAccentHex.toLowerCase() === hex.toLowerCase();
                  return (
                    <button
                      key={hex}
                      onClick={() => {
                        setDraftAccentHex(hex);
                        onUpdateThemeConfig(prev => ({
                          ...prev,
                          useCustomAccent: true,
                          customAccentHex: hex,
                          adaptToCoverArt: false
                        }));
                      }}
                      className="w-14 h-14 rounded-full border-2 border-white flex items-center justify-center shadow-md cursor-pointer"
                      style={{ backgroundColor: hex }}
                    >
                      {selected && <Check className="w-6 h-6 text-slate-950 stroke-[3]" />}
                    </button>
                  );
                })}

                {/* "+" Button to Choose Any Custom Color Desired! */}
                <button
                  onClick={() => customColorInputRef.current?.click()}
                  aria-label="Añadir color personalizado"
                  className="w-14 h-14 rounded-full border-2 border-white bg-[#132838] hover:bg-white/15 flex items-center justify-center shadow-md cursor-pointer"
                >
                  <Plus className="w-7 h-7 text-white" />
                </button>
              </div>
            )}

            {/* Quick Custom Color Bar + Aceptar Button */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => customColorInputRef.current?.click()}
                className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/15 text-xs font-extrabold text-white flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Color personalizado</span>
              </button>

              <button
                onClick={() => {
                  setShowAccentModal(false);
                  showToast('Color de énfasis actualizado');
                }}
                className="text-base font-extrabold text-white hover:text-[#1cc8ee] cursor-pointer"
              >
                Aceptar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const ElegirTemaScreen = ThemeStudioModal;

