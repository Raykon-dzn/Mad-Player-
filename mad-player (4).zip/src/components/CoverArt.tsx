import React, { useState, useEffect } from 'react';
import { Disc3, Music2 } from 'lucide-react';
import { CoverShape } from '../types/music';

interface CoverArtProps {
  src: string;
  alt: string;
  dominantColor: string;
  secondaryColor?: string;
  shape?: CoverShape;
  isPlaying?: boolean;
  sizeClass?: string;
}

export const CoverArt: React.FC<CoverArtProps> = ({
  src,
  alt,
  dominantColor,
  secondaryColor = '#1e293b',
  shape = 'rounded',
  isPlaying = false,
  sizeClass = 'w-12 h-12'
}) => {
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    setImgError(false);
  }, [src]);

  const radiusClass =
    shape === 'vinyl'
      ? 'rounded-full'
      : shape === 'square'
        ? 'rounded-none'
        : 'rounded-xl';

  const spinClass =
    shape === 'vinyl'
      ? isPlaying
        ? 'animate-vinyl-spin'
        : 'animate-vinyl-paused'
      : '';

  return (
    <div
      className={`relative overflow-hidden shrink-0 select-none ${sizeClass} ${radiusClass} ${spinClass}`}
      style={{
        background: `linear-gradient(135deg, ${dominantColor}, ${secondaryColor})`,
        border: '1px solid var(--theme-border)'
      }}
    >
      {!imgError && src ? (
        <img
          src={src}
          alt={alt}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center text-white/90">
          {shape === 'vinyl' ? (
            <Disc3 className="w-1/2 h-1/2" />
          ) : (
            <Music2 className="w-1/2 h-1/2" />
          )}
        </div>
      )}

      {shape === 'vinyl' && (
        <>
          <div
            className="absolute inset-0 pointer-events-none rounded-full"
            style={{
              background:
                'repeating-radial-gradient(circle at center, rgba(0,0,0,0) 0px, rgba(0,0,0,0) 5px, rgba(0,0,0,0.22) 6px, rgba(0,0,0,0) 7px)'
            }}
          />
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1/4 h-1/4 rounded-full border border-white/30 flex items-center justify-center"
            style={{ backgroundColor: 'var(--theme-bg)' }}
          >
            <div className="w-2 h-2 rounded-full bg-white/50" />
          </div>
        </>
      )}
    </div>
  );
};
