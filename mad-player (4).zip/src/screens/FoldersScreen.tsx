import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Folder, FolderSearch, Music2, Play, Upload } from 'lucide-react';
import { Track } from '../types/music';
import { isCapacitorNative } from '../services/folderScanner';
import { formatDuration } from '../utils/formatters';

interface FoldersScreenProps {
  groupedFolders: [string, Track[]][];
  isScanningFolder: boolean;
  onTriggerScanFolder: () => void;
  onTriggerImportFiles: () => void;
  onPlayTrack: (track: Track, queueIds: string[], fromUserSelection: boolean) => void;
}

export const FoldersScreen: React.FC<FoldersScreenProps> = ({
  groupedFolders,
  isScanningFolder,
  onTriggerScanFolder,
  onTriggerImportFiles,
  onPlayTrack
}) => {
  const nativeCap = isCapacitorNative();
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({});

  const toggleFolderExpanded = (folderPath: string) => {
    setExpandedFolders(prev => ({
      ...prev,
      [folderPath]: !prev[folderPath]
    }));
  };

  return (
    <div className="flex flex-col gap-4">
      <div
        className="flex flex-wrap items-center justify-between gap-3 border-b pb-3"
        style={{ borderColor: 'var(--theme-border)' }}
      >
        <div>
          <h1 className="text-xl font-bold font-display">Carpetas del Dispositivo</h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--theme-muted)' }}>
            {nativeCap
              ? 'Modo nativo APK (Capacitor): escaneo directo de /Music, /Download y /Podcasts.'
              : 'Importa carpetas completas (mp3, m4a, flac, wav, ogg) o selecciona archivos.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onTriggerScanFolder}
            disabled={isScanningFolder}
            className="px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            style={{
              backgroundColor: 'var(--theme-accent)',
              color: 'var(--theme-accent-fg)'
            }}
          >
            <FolderSearch className="w-4 h-4" />
            {isScanningFolder ? 'Importando...' : 'Importar carpeta'}
          </button>

          <button
            onClick={onTriggerImportFiles}
            disabled={isScanningFolder}
            className="px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-border)',
              color: 'var(--theme-text)'
            }}
          >
            <Upload className="w-4 h-4" />
            Archivos
          </button>
        </div>
      </div>

      {groupedFolders.length === 0 ? (
        <div
          className="p-8 rounded-2xl border text-center flex flex-col items-center gap-3"
          style={{
            backgroundColor: 'var(--theme-surface)',
            borderColor: 'var(--theme-border)'
          }}
        >
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{
              backgroundColor: 'var(--theme-accent-soft)',
              color: 'var(--theme-accent)'
            }}
          >
            <Folder className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm font-bold">Sin carpetas indexadas</p>
            <p className="text-xs mt-1 max-w-md" style={{ color: 'var(--theme-muted)' }}>
              Selecciona una carpeta de música para indexar todas sus canciones y subcarpetas
              automáticamente en tu biblioteca offline.
            </p>
          </div>
          <button
            onClick={onTriggerScanFolder}
            disabled={isScanningFolder}
            className="mt-1 px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            style={{
              backgroundColor: 'var(--theme-accent)',
              color: 'var(--theme-accent-fg)'
            }}
          >
            <FolderSearch className="w-4 h-4" />
            Importar carpeta
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {groupedFolders.map(([folderPath, folderTracks]) => {
            const isExpanded = Boolean(expandedFolders[folderPath]);
            const folderIds = folderTracks.map(t => t.id);

            return (
              <div
                key={folderPath}
                className="p-4 rounded-2xl border flex flex-col gap-3"
                style={{
                  backgroundColor: 'var(--theme-surface)',
                  borderColor: 'var(--theme-border)'
                }}
              >
                <div
                  onClick={() => toggleFolderExpanded(folderPath)}
                  className="flex items-center justify-between gap-3 cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                      style={{
                        backgroundColor: 'var(--theme-accent-soft)',
                        color: 'var(--theme-accent)'
                      }}
                    >
                      <Folder className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h2 className="text-sm font-bold truncate">
                          {folderPath.split('/').filter(Boolean).pop() || folderPath}
                        </h2>
                        {isExpanded ? (
                          <ChevronDown
                            className="w-4 h-4 shrink-0"
                            style={{ color: 'var(--theme-muted)' }}
                          />
                        ) : (
                          <ChevronRight
                            className="w-4 h-4 shrink-0"
                            style={{ color: 'var(--theme-muted)' }}
                          />
                        )}
                      </div>
                      <p
                        className="text-xs font-mono-tabular truncate"
                        style={{ color: 'var(--theme-muted)' }}
                      >
                        {folderPath} · {folderTracks.length} pista(s)
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onPlayTrack(folderTracks[0], folderIds, true);
                    }}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
                    style={{
                      backgroundColor: 'var(--theme-accent)',
                      color: 'var(--theme-accent-fg)'
                    }}
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    Reproducir
                  </button>
                </div>

                {isExpanded && (
                  <div
                    className="flex flex-col border-t pt-2.5 gap-1"
                    style={{ borderColor: 'var(--theme-border)' }}
                  >
                    {folderTracks.map(track => (
                      <div
                        key={track.id}
                        onClick={() => onPlayTrack(track, folderIds, true)}
                        className="flex items-center justify-between gap-3 py-2 px-2 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className="w-9 h-9 rounded-lg overflow-hidden shrink-0 bg-[#3b4d5e] flex items-center justify-center">
                            {track.coverUrl ? (
                              <img
                                src={track.coverUrl}
                                alt={track.title}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <Music2 className="w-4 h-4 text-[#132230]" />
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 min-w-0">
                              <p className="text-xs font-extrabold truncate">{track.title}</p>
                              {track.audioUnavailable && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0">
                                  archivo no disponible
                                </span>
                              )}
                            </div>
                            <p
                              className="text-[11px] truncate"
                              style={{ color: 'var(--theme-muted)' }}
                            >
                              {track.artist} • {track.album}
                            </p>
                          </div>
                        </div>
                        <span
                          className="text-xs font-mono-tabular shrink-0"
                          style={{ color: 'var(--theme-muted)' }}
                        >
                          {formatDuration(track.duration)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
