import React from 'react';
import {
  EqualizerState,
  PlayerSkin,
  ThemeBaseId,
  ThemeConfig
} from '../types/music';
import { EQ_PRESETS } from '../data/initialLibrary';
import { SettingsSubPage } from '../hooks/useSettings';

interface ThemesAndEqualizerScreenProps {
  mode: 'themes' | 'equalizer';
  themeConfig: ThemeConfig;
  setThemeConfig: React.Dispatch<React.SetStateAction<ThemeConfig>>;
  extractedTrackColor: string;
  onOpenSettingsSubPage: (subPage: SettingsSubPage) => void;
  eqState: EqualizerState;
  setEqState: React.Dispatch<React.SetStateAction<EqualizerState>>;
  onInstantSpeedAndPitchChange: (rate: number, pitchRate: number) => void;
}

export const ThemesAndEqualizerScreen: React.FC<ThemesAndEqualizerScreenProps> = ({
  mode,
  themeConfig,
  setThemeConfig,
  extractedTrackColor,
  onOpenSettingsSubPage,
  eqState,
  setEqState,
  onInstantSpeedAndPitchChange
}) => {
  if (mode === 'themes') {
    return (
      <div className="flex flex-col gap-5">
        <div
          className="border-b pb-3 flex flex-wrap items-center justify-between gap-3"
          style={{ borderColor: 'var(--theme-border)' }}
        >
          <div>
            <h1 className="text-xl sm:text-2xl font-bold font-display tracking-tight">
              Temas Dinámicos de Mad Player
            </h1>
            <p className="text-xs mt-0.5" style={{ color: 'var(--theme-muted)' }}>
              Personaliza el tema general (Imagen con Alpha/Blur, Colores, Degradado, Color Énfasis)
              y los 6 temas del reproductor.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenSettingsSubPage('elegir-tema')}
              className="px-3.5 py-2 rounded-xl text-xs font-extrabold cursor-pointer"
              style={{
                backgroundColor: 'var(--theme-accent)',
                color: 'var(--theme-accent-fg)'
              }}
            >
              Abrir Elegir Tema
            </button>
            <button
              onClick={() => onOpenSettingsSubPage('player-skins')}
              className="px-3.5 py-2 rounded-xl text-xs font-extrabold border cursor-pointer"
              style={{
                backgroundColor: 'var(--theme-surface)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            >
              Carrusel de Jugador (6 Temas)
            </button>
          </div>
        </div>

        <div
          className="p-4 rounded-2xl border flex flex-col gap-3"
          style={{ backgroundColor: 'var(--theme-surface)', borderColor: 'var(--theme-border)' }}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">6 Temas del Reproductor (Jugador)</h2>
            <button
              onClick={() => onOpenSettingsSubPage('player-skins')}
              className="text-xs font-extrabold underline cursor-pointer"
              style={{ color: 'var(--theme-accent)' }}
            >
              Ver vista deslizable →
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(
              [
                {
                  id: 'muzio-classic',
                  title: '1. Mad Player Borde a Borde (Original)',
                  desc: 'Portada cuadrada con barra plana inferior y fondo pastel adaptativo.'
                },
                {
                  id: 'stacked-cards',
                  title: '2. Tarjetas Apiladas con Onda',
                  desc: 'Portada en tarjetas apiladas con forma de onda central y botón coral.'
                },
                {
                  id: 'vinyl-circle',
                  title: '3. Disco Circular con Aro de Progreso',
                  desc: 'Carátula circular con aro de tiempo alrededor y controles cápsula.'
                },
                {
                  id: 'full-bleed-dark',
                  title: '4. Inmersivo Oscuro Degradado',
                  desc: 'Portada superior con fundido oscuro y barra de progreso rosa.'
                },
                {
                  id: 'framed-card',
                  title: '5. Marco Flotante con Controles Superpuestos',
                  desc: 'Tarjeta enmarcada con barra de transporte flotante sobre el borde.'
                },
                {
                  id: 'circle-cobalt',
                  title: '6. Círculo Cobalto Minimalista',
                  desc: 'Portada circular limpia sobre tarjeta azul cobalto con acento celeste.'
                }
              ] as { id: PlayerSkin; title: string; desc: string }[]
            ).map(skin => {
              const active = themeConfig.playerSkin === skin.id;
              return (
                <button
                  key={skin.id}
                  onClick={() => setThemeConfig(prev => ({ ...prev, playerSkin: skin.id }))}
                  className="p-3.5 rounded-xl border text-left flex flex-col gap-1 cursor-pointer"
                  style={{
                    backgroundColor: active ? 'var(--theme-accent-soft)' : 'var(--theme-bg)',
                    borderColor: active ? 'var(--theme-accent)' : 'var(--theme-border)'
                  }}
                >
                  <span className="text-sm font-bold">{skin.title}</span>
                  <span className="text-xs" style={{ color: 'var(--theme-muted)' }}>
                    {skin.desc}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div
          className="p-4 rounded-2xl border flex items-center justify-between gap-4"
          style={{
            backgroundColor: 'var(--theme-surface)',
            borderColor: 'var(--theme-border)'
          }}
        >
          <div>
            <h2 className="text-sm font-semibold">Color Dinámico por Portada (Camaleón)</h2>
            <p className="text-xs mt-0.5" style={{ color: 'var(--theme-muted)' }}>
              Extrae el color dominante de la carátula incrustada de cada canción.
            </p>
          </div>
          <button
            onClick={() =>
              setThemeConfig(prev => ({
                ...prev,
                adaptToCoverArt: !prev.adaptToCoverArt,
                useCustomAccent: false
              }))
            }
            className="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: themeConfig.adaptToCoverArt
                ? 'var(--theme-accent)'
                : 'var(--theme-bg)',
              color: themeConfig.adaptToCoverArt
                ? 'var(--theme-accent-fg)'
                : 'var(--theme-text)',
              border: '1px solid var(--theme-border)'
            }}
          >
            {themeConfig.adaptToCoverArt ? 'Activo' : 'Activar'}
          </button>
        </div>

        <div>
          <h3 className="text-xs font-semibold mb-2.5" style={{ color: 'var(--theme-muted)' }}>
            Paletas Base
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {(
              [
                { id: 'nordic-slate', name: 'Mad Navy (Original)', swatch: '#1cc8ee' },
                { id: 'dynamic-cover', name: 'Camaleón (Portada)', swatch: extractedTrackColor },
                { id: 'obsidian-studio', name: 'Obsidiana Studio', swatch: '#f59e0b' },
                { id: 'velvet-crimson', name: 'Terciopelo Nocturno', swatch: '#f43f5e' },
                { id: 'solar-concrete', name: 'Hormigón Solar', swatch: '#f97316' },
                { id: 'editorial-paper', name: 'Papel Claro', swatch: '#0284c7' }
              ] as { id: ThemeBaseId; name: string; swatch: string }[]
            ).map(preset => {
              const active = themeConfig.baseId === preset.id;
              return (
                <button
                  key={preset.id}
                  onClick={() =>
                    setThemeConfig(prev => ({
                      ...prev,
                      baseId: preset.id,
                      adaptToCoverArt: preset.id === 'dynamic-cover',
                      useCustomAccent: false
                    }))
                  }
                  className="p-3 rounded-xl border text-left flex items-center gap-2.5 cursor-pointer"
                  style={{
                    backgroundColor: active
                      ? 'var(--theme-accent-soft)'
                      : 'var(--theme-surface)',
                    borderColor: active ? 'var(--theme-accent)' : 'var(--theme-border)'
                  }}
                >
                  <span
                    className="w-5 h-5 rounded-full shrink-0 border border-white/20"
                    style={{ backgroundColor: preset.swatch }}
                  />
                  <span className="text-xs font-semibold truncate">{preset.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <div
        className="flex items-center justify-between gap-4 border-b pb-3"
        style={{ borderColor: 'var(--theme-border)' }}
      >
        <div>
          <h1 className="text-xl sm:text-2xl font-bold font-display tracking-tight">
            Ecualizador, Velocidad y Tono
          </h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--theme-muted)' }}>
            Efecto instantáneo en tiempo real sobre la música activa.
          </p>
        </div>

        <button
          onClick={() => setEqState(prev => ({ ...prev, enabled: !prev.enabled }))}
          className="px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer"
          style={{
            backgroundColor: eqState.enabled ? 'var(--theme-accent)' : 'var(--theme-surface)',
            color: eqState.enabled ? 'var(--theme-accent-fg)' : 'var(--theme-muted)',
            border: '1px solid var(--theme-border)'
          }}
        >
          {eqState.enabled ? 'EQ Activo' : 'Bypass'}
        </button>
      </div>

      {/* Instantaneous Speed & Pitch Cards (Aligned 0.5 - 1.5 scale) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div
          className="p-4 rounded-2xl border flex flex-col gap-3"
          style={{
            backgroundColor: 'var(--theme-surface)',
            borderColor: 'var(--theme-border)'
          }}
        >
          <div className="flex items-center justify-between text-xs font-bold">
            <span>Velocidad de reproducción: {eqState.playbackRate.toFixed(1)}x</span>
            <button
              onClick={() => onInstantSpeedAndPitchChange(1.0, eqState.pitchRate)}
              className="px-2.5 py-1 rounded-lg bg-white/10 text-slate-300 cursor-pointer"
            >
              Restablecer
            </button>
          </div>
          <input
            type="range"
            min={0.5}
            max={1.5}
            step={0.1}
            value={eqState.playbackRate}
            onChange={e => onInstantSpeedAndPitchChange(Number(e.target.value), eqState.pitchRate)}
            className="w-full cursor-pointer"
            style={{ accentColor: 'var(--theme-accent)' }}
          />
          <div
            className="grid grid-cols-3 text-[11px] font-bold"
            style={{ color: 'var(--theme-muted)' }}
          >
            <span>Lento</span>
            <span className="text-center">Normal</span>
            <span className="text-right">Rápido</span>
          </div>
        </div>

        <div
          className="p-4 rounded-2xl border flex flex-col gap-3"
          style={{
            backgroundColor: 'var(--theme-surface)',
            borderColor: 'var(--theme-border)'
          }}
        >
          <div className="flex items-center justify-between text-xs font-bold">
            <span>Tono de reproducción: {eqState.pitchRate.toFixed(1)}</span>
            <button
              onClick={() => onInstantSpeedAndPitchChange(eqState.playbackRate, 1.0)}
              className="px-2.5 py-1 rounded-lg bg-white/10 text-slate-300 cursor-pointer"
            >
              Restablecer
            </button>
          </div>
          <input
            type="range"
            min={0.5}
            max={1.5}
            step={0.1}
            value={eqState.pitchRate}
            onChange={e =>
              onInstantSpeedAndPitchChange(eqState.playbackRate, Number(e.target.value))
            }
            className="w-full cursor-pointer"
            style={{ accentColor: 'var(--theme-accent)' }}
          />
          <div
            className="grid grid-cols-3 text-[11px] font-bold"
            style={{ color: 'var(--theme-muted)' }}
          >
            <span>Lento</span>
            <span className="text-center">Normal</span>
            <span className="text-right">Rápido</span>
          </div>
        </div>
      </div>

      {/* EQ Presets */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {Object.entries(EQ_PRESETS).map(([name, gains]) => {
          const active = eqState.presetName === name;
          return (
            <button
              key={name}
              onClick={() =>
                setEqState(prev => ({
                  ...prev,
                  presetName: name,
                  bands: prev.bands.map((b, i) => ({ ...b, gain: gains[i] }))
                }))
              }
              className="px-3.5 py-2 rounded-xl text-xs font-medium border whitespace-nowrap shrink-0 cursor-pointer"
              style={{
                backgroundColor: active ? 'var(--theme-accent)' : 'var(--theme-surface)',
                color: active ? 'var(--theme-accent-fg)' : 'var(--theme-text)',
                borderColor: active ? 'var(--theme-accent)' : 'var(--theme-border)'
              }}
            >
              {name}
            </button>
          );
        })}
      </div>

      {/* 5-Band Graphic EQ */}
      <div
        className="p-5 rounded-2xl border grid grid-cols-5 gap-2 sm:gap-4"
        style={{
          backgroundColor: 'var(--theme-surface)',
          borderColor: 'var(--theme-border)'
        }}
      >
        {eqState.bands.map((band, idx) => (
          <div key={band.frequency} className="flex flex-col items-center gap-3">
            <span
              className="text-xs font-mono-tabular font-semibold"
              style={{ color: 'var(--theme-accent)' }}
            >
              {band.gain > 0 ? `+${band.gain}` : band.gain}dB
            </span>
            <div className="h-36 flex items-center justify-center">
              <input
                type="range"
                min={-12}
                max={12}
                step={0.5}
                value={band.gain}
                onChange={e => {
                  const val = Number(e.target.value);
                  setEqState(prev => ({
                    ...prev,
                    presetName: 'Personalizado',
                    bands: prev.bands.map((b, i) => (i === idx ? { ...b, gain: val } : b))
                  }));
                }}
                className="w-28 -rotate-90 cursor-pointer"
                style={{ accentColor: 'var(--theme-accent)' }}
                aria-label={`Banda ${band.label}`}
              />
            </div>
            <span className="text-[11px] font-mono-tabular" style={{ color: 'var(--theme-muted)' }}>
              {band.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
