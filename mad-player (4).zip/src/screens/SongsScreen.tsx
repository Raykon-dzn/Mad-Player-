import React, { useMemo, useRef } from 'react';
import { useWindowVirtualizer } from '@tanstack/react-virtual';
import {
  ArrowUpDown,
  FolderSearch,
  Gauge,
  Heart,
  MoreVertical,
  Music2,
  Shuffle,
  Upload
} from 'lucide-react';
import { EqualizerState, Playlist, Track } from '../types/music';

interface SongsScreenProps {
  filteredTracks: Track[];
  currentTrack?: Track;
  onlyFavorites: boolean;
  onClearOnlyFavorites: () => void;
  onResetAllFilters: () => void;
  sortBy: 'title' | 'artist' | 'bpm' | 'playCount' | 'duration';
  onChangeSortBy: (sort: 'title' | 'artist' | 'bpm' | 'playCount' | 'duration') => void;
  eqState: EqualizerState;
  onOpenSpeedPicker: () => void;
  onTriggerImportFiles: () => void;
  onTriggerScanFolder: () => void;
  selectedTrackIds: string[];
  onClearSelectedTracks: () => void;
  playlists: Playlist[];
  onBatchAddToPlaylist: (playlistId: string) => void;
  onBatchAddToQueue: () => void;
  onShufflePlayAll: () => void;
  onPlayTrack: (track: Track, queueIds: string[], fromUserSelection: boolean) => void;
  onToggleFavorite: (trackId: string, e?: React.MouseEvent) => void;
  onOpenTrackMenu: (trackId: string) => void;
}

export const SongsScreen: React.FC<SongsScreenProps> = ({
  filteredTracks,
  currentTrack,
  onlyFavorites,
  onClearOnlyFavorites,
  onResetAllFilters,
  sortBy,
  onChangeSortBy,
  eqState,
  onOpenSpeedPicker,
  onTriggerImportFiles,
  onTriggerScanFolder,
  selectedTrackIds,
  onClearSelectedTracks,
  playlists,
  onBatchAddToPlaylist,
  onBatchAddToQueue,
  onShufflePlayAll,
  onPlayTrack,
  onToggleFavorite,
  onOpenTrackMenu
}) => {
  const listRef = useRef<HTMLDivElement | null>(null);

  const allFilteredIds = useMemo(() => filteredTracks.map(t => t.id), [filteredTracks]);

  const rowVirtualizer = useWindowVirtualizer({
    count: filteredTracks.length,
    estimateSize: () => 68,
    overscan: 10,
    scrollMargin: listRef.current?.offsetTop ?? 0
  });

  return (
    <div className="flex flex-col gap-3.5">
      {/* Sub-Header Row: "Aleatorio todo (N)" + Speed/Pitch + Sort + Import */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
        <button
          onClick={onShufflePlayAll}
          className="flex items-center gap-2.5 py-1.5 px-1 text-left group cursor-pointer"
        >
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center shadow-sm"
            style={{
              backgroundColor: 'var(--theme-accent)',
              color: 'var(--theme-accent-fg)'
            }}
          >
            <Shuffle className="w-4 h-4" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-extrabold font-display">Aleatorio todo</span>
            <span
              className="text-xs font-mono-tabular font-semibold"
              style={{ color: 'var(--theme-muted)' }}
            >
              ({filteredTracks.length})
            </span>
          </div>
        </button>

        <div className="flex flex-wrap items-center gap-1.5">
          {onlyFavorites && (
            <button
              onClick={onClearOnlyFavorites}
              className="h-8 px-2.5 rounded-lg text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 cursor-pointer"
            >
              Solo Favoritos ×
            </button>
          )}

          {/* Live Speed & Pitch Trigger Pill */}
          <button
            onClick={onOpenSpeedPicker}
            className="h-8 px-2.5 rounded-lg text-xs font-mono-tabular font-bold border flex items-center gap-1 cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-border)',
              color: 'var(--theme-accent)'
            }}
            title="Velocidad y Tono de reproducción"
          >
            <Gauge className="w-3.5 h-3.5" />
            <span>{eqState.playbackRate.toFixed(1)}x</span>
            {Math.abs(eqState.pitchRate - 1.0) >= 0.05 && (
              <span>/{eqState.pitchRate.toFixed(1)}</span>
            )}
          </button>

          {/* Sort Selector */}
          <div className="relative flex items-center">
            <ArrowUpDown
              className="w-3.5 h-3.5 absolute left-2.5 pointer-events-none"
              style={{ color: 'var(--theme-muted)' }}
            />
            <select
              value={sortBy}
              onChange={e => onChangeSortBy(e.target.value as typeof sortBy)}
              aria-label="Ordenar canciones"
              className="h-8 pl-7 pr-2 rounded-lg text-xs font-semibold border outline-none cursor-pointer"
              style={{
                backgroundColor: 'var(--theme-surface)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            >
              <option value="title" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                A - Z
              </option>
              <option value="artist" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                Artista
              </option>
              <option value="playCount" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                Reproducciones
              </option>
              <option value="duration" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                Duración
              </option>
            </select>
          </div>

          <button
            onClick={onTriggerScanFolder}
            className="h-8 px-2.5 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-accent)',
              color: 'var(--theme-accent-fg)'
            }}
            title="Importar carpeta completa"
          >
            <FolderSearch className="w-3.5 h-3.5" />
            <span>Importar carpeta</span>
          </button>

          <button
            onClick={onTriggerImportFiles}
            className="h-8 px-2.5 rounded-lg text-xs font-bold border flex items-center gap-1 cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-border)',
              color: 'var(--theme-text)'
            }}
            title="Importar archivos sueltos"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Archivos</span>
          </button>
        </div>
      </div>

      {/* Multi-Select Batch Action Toolbar */}
      {selectedTrackIds.length > 0 && (
        <div
          className="p-3 rounded-xl border flex flex-wrap items-center justify-between gap-3"
          style={{
            backgroundColor: 'var(--theme-accent-soft)',
            borderColor: 'var(--theme-accent)'
          }}
        >
          <div className="flex items-center gap-2 text-xs font-semibold">
            <span className="font-mono-tabular">{selectedTrackIds.length} seleccionada(s)</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={onClearSelectedTracks}
              className="underline cursor-pointer"
              style={{ color: 'var(--theme-muted)' }}
            >
              Cancelar
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              onChange={e => {
                if (e.target.value) {
                  onBatchAddToPlaylist(e.target.value);
                  e.target.value = '';
                }
              }}
              defaultValue=""
              className="px-3 py-1.5 rounded-lg text-xs font-medium border outline-none cursor-pointer"
              style={{
                backgroundColor: 'var(--theme-surface)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            >
              <option value="" disabled>
                + Añadir a lista...
              </option>
              {playlists.map(pl => (
                <option
                  key={pl.id}
                  value={pl.id}
                  style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                >
                  {pl.name}
                </option>
              ))}
            </select>

            <button
              onClick={onBatchAddToQueue}
              className="px-3 py-1.5 rounded-lg text-xs font-medium border whitespace-nowrap shrink-0 cursor-pointer"
              style={{
                backgroundColor: 'var(--theme-surface)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            >
              A la Cola
            </button>
          </div>
        </div>
      )}

      {/* MUZIO SONG LIST ROWS (VIRTUALIZED) */}
      <div ref={listRef} className="flex flex-col" style={{ borderColor: 'var(--theme-border)' }}>
        {filteredTracks.length === 0 ? (
          <div className="p-10 text-center flex flex-col items-center gap-3">
            <p className="text-sm font-semibold">
              No hay canciones en la biblioteca o con el filtro activo
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2">
              <button
                onClick={onTriggerScanFolder}
                className="px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                style={{
                  backgroundColor: 'var(--theme-accent)',
                  color: 'var(--theme-accent-fg)'
                }}
              >
                <FolderSearch className="w-3.5 h-3.5" />
                Importar carpeta
              </button>
              <button
                onClick={onResetAllFilters}
                className="px-4 py-2 rounded-lg text-xs font-semibold border cursor-pointer"
                style={{
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-text)'
                }}
              >
                Limpiar Filtros
              </button>
            </div>
          </div>
        ) : (
          <div
            style={{
              height: `${rowVirtualizer.getTotalSize()}px`,
              width: '100%',
              position: 'relative'
            }}
          >
            {rowVirtualizer.getVirtualItems().map(virtualRow => {
              const track = filteredTracks[virtualRow.index];
              if (!track) return null;
              const isCurrent = track.id === currentTrack?.id;
              const isLast = virtualRow.index === filteredTracks.length - 1;

              return (
                <div
                  key={track.id}
                  data-index={virtualRow.index}
                  ref={rowVirtualizer.measureElement}
                  onClick={() => onPlayTrack(track, allFilteredIds, true)}
                  className={`flex items-center justify-between gap-3 py-2.5 px-1 transition-colors cursor-pointer ${
                    isLast ? '' : 'border-b'
                  }`}
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    transform: `translateY(${virtualRow.start - rowVirtualizer.options.scrollMargin}px)`,
                    borderColor: 'var(--theme-border)'
                  }}
                >
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div className="w-12 h-12 rounded-xl overflow-hidden shrink-0 bg-[#3b4d5e] flex items-center justify-center">
                      {track.coverUrl ? (
                        <img
                          src={track.coverUrl}
                          alt={track.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Music2 className="w-6 h-6 text-[#132230] stroke-[2.2]" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <p
                          className="text-base font-extrabold truncate"
                          style={{
                            color: track.audioUnavailable
                              ? '#fb7185'
                              : isCurrent
                                ? 'var(--theme-accent)'
                                : 'var(--theme-text)'
                          }}
                        >
                          {track.title}
                        </p>
                        {track.audioUnavailable && (
                          <span className="px-1.5 py-0.5 rounded-md text-[10px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0">
                            archivo no disponible
                          </span>
                        )}
                      </div>
                      <p
                        className="text-xs font-bold truncate mt-0.5"
                        style={{ color: 'var(--theme-muted)' }}
                      >
                        {track.artist} • {track.album}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-0.5 shrink-0">
                    <button
                      type="button"
                      onClick={e => onToggleFavorite(track.id, e)}
                      aria-label="Favorito"
                      className="w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer"
                      style={{
                        color: track.isFavorite ? '#f43f5e' : 'var(--theme-muted)'
                      }}
                    >
                      <Heart className={`w-4 h-4 ${track.isFavorite ? 'fill-current' : ''}`} />
                    </button>

                    <button
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        onOpenTrackMenu(track.id);
                      }}
                      aria-label="Opciones de canción"
                      className="w-9 h-9 flex items-center justify-center rounded-lg hover:opacity-80 cursor-pointer"
                      style={{ color: 'var(--theme-muted)' }}
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
