import React from 'react';
import { Disc3 } from 'lucide-react';
import { Track } from '../types/music';

interface GenresScreenProps {
  groupedGenres: [string, Track[]][];
  onSelectGenre: (genreName: string) => void;
}

export const GenresScreen: React.FC<GenresScreenProps> = ({ groupedGenres, onSelectGenre }) => {
  return (
    <div className="flex flex-col gap-4">
      <div className="border-b pb-3" style={{ borderColor: 'var(--theme-border)' }}>
        <h1 className="text-xl font-bold font-display">Géneros ({groupedGenres.length})</h1>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {groupedGenres.map(([genreName, genreTracks]) => (
          <button
            key={genreName}
            onClick={() => onSelectGenre(genreName)}
            className="p-4 rounded-2xl border text-left flex flex-col justify-between gap-2 cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-border)'
            }}
          >
            <Disc3 className="w-6 h-6" style={{ color: 'var(--theme-accent)' }} />
            <div>
              <h3 className="text-sm font-bold truncate">{genreName}</h3>
              <p className="text-xs font-mono-tabular" style={{ color: 'var(--theme-muted)' }}>
                {genreTracks.length} canción(es)
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
