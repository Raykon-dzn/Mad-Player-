import React from 'react';
import { Play, User } from 'lucide-react';
import { Track } from '../types/music';
import { CoverArt } from '../components/CoverArt';

interface ArtistsScreenProps {
  groupedArtists: [string, Track[]][];
  onPlayTrack: (track: Track, queueIds: string[], fromUserSelection: boolean) => void;
}

export const ArtistsScreen: React.FC<ArtistsScreenProps> = ({ groupedArtists, onPlayTrack }) => {
  return (
    <div className="flex flex-col gap-4">
      <div className="border-b pb-3" style={{ borderColor: 'var(--theme-border)' }}>
        <h1 className="text-xl font-bold font-display">Artistas ({groupedArtists.length})</h1>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {groupedArtists.map(([artistName, artistTracks]) => (
          <div
            key={artistName}
            onClick={() =>
              onPlayTrack(
                artistTracks[0],
                artistTracks.map(t => t.id),
                true
              )
            }
            className="p-3.5 rounded-2xl border flex items-center justify-between gap-3 cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-border)'
            }}
          >
            <div className="flex items-center gap-3 min-w-0">
              <CoverArt
                src={artistTracks[0].coverUrl}
                alt={artistName}
                dominantColor={artistTracks[0].dominantColor}
                shape="vinyl"
                sizeClass="w-12 h-12"
              />
              <div className="min-w-0">
                <h3 className="text-sm font-bold truncate flex items-center gap-1.5">
                  <User
                    className="w-3.5 h-3.5 shrink-0"
                    style={{ color: 'var(--theme-accent)' }}
                  />
                  {artistName}
                </h3>
                <p className="text-xs" style={{ color: 'var(--theme-muted)' }}>
                  {artistTracks.length} canción(es)
                </p>
              </div>
            </div>
            <Play className="w-4 h-4 shrink-0" style={{ color: 'var(--theme-accent)' }} />
          </div>
        ))}
      </div>
    </div>
  );
};
