import React from 'react';
import {
  ArrowDown,
  ArrowUp,
  Copy,
  Download,
  GitMerge,
  Play,
  Plus,
  Sparkles,
  Trash2,
  X
} from 'lucide-react';
import {
  CoverShape,
  Playlist,
  SmartPlaylist,
  SmartRule,
  SmartRuleField,
  SmartRuleOperator,
  Track
} from '../types/music';
import { evaluateSmartPlaylist, formatDuration } from '../utils/formatters';
import { CoverArt } from '../components/CoverArt';

interface PlaylistsScreenProps {
  mode: 'playlists' | 'smart-lists';
  tracks: Track[];
  visibleTracks: Track[];
  playlists: Playlist[];
  setPlaylists: React.Dispatch<React.SetStateAction<Playlist[]>>;
  activePlaylist?: Playlist;
  activePlaylistTracks: Track[];
  onSelectPlaylist: (id: string) => void;
  showCreatePlaylistForm: boolean;
  setShowCreatePlaylistForm: React.Dispatch<React.SetStateAction<boolean>>;
  newPlaylistName: string;
  setNewPlaylistName: React.Dispatch<React.SetStateAction<string>>;
  newPlaylistDesc: string;
  setNewPlaylistDesc: React.Dispatch<React.SetStateAction<string>>;
  onCreatePlaylist: (e: React.FormEvent) => void;
  onDuplicatePlaylist: () => void;
  onExportPlaylistJson: () => void;
  mergeTargetId: string;
  setMergeTargetId: React.Dispatch<React.SetStateAction<string>>;
  onMergePlaylists: () => void;
  onMovePlaylistTrack: (index: number, direction: -1 | 1) => void;
  onRemoveFromPlaylist: (trackId: string) => void;
  smartPlaylists: SmartPlaylist[];
  activeSmartPlaylist?: SmartPlaylist;
  onSelectSmartPlaylist: (id: string) => void;
  showSmartBuilder: boolean;
  setShowSmartBuilder: React.Dispatch<React.SetStateAction<boolean>>;
  smartName: string;
  setSmartName: React.Dispatch<React.SetStateAction<string>>;
  smartDesc: string;
  setSmartDesc: React.Dispatch<React.SetStateAction<string>>;
  smartMatchMode: 'all' | 'any';
  setSmartMatchMode: React.Dispatch<React.SetStateAction<'all' | 'any'>>;
  smartRules: SmartRule[];
  setSmartRules: React.Dispatch<React.SetStateAction<SmartRule[]>>;
  onCreateSmartPlaylist: (e: React.FormEvent) => void;
  coverShape: CoverShape;
  onPlayTrack: (track: Track, queueIds: string[], fromUserSelection: boolean) => void;
  showToast: (msg: string) => void;
}

export const PlaylistsScreen: React.FC<PlaylistsScreenProps> = ({
  mode,
  tracks,
  visibleTracks,
  playlists,
  setPlaylists,
  activePlaylist,
  activePlaylistTracks,
  onSelectPlaylist,
  showCreatePlaylistForm,
  setShowCreatePlaylistForm,
  newPlaylistName,
  setNewPlaylistName,
  newPlaylistDesc,
  setNewPlaylistDesc,
  onCreatePlaylist,
  onDuplicatePlaylist,
  onExportPlaylistJson,
  mergeTargetId,
  setMergeTargetId,
  onMergePlaylists,
  onMovePlaylistTrack,
  onRemoveFromPlaylist,
  smartPlaylists,
  activeSmartPlaylist,
  onSelectSmartPlaylist,
  showSmartBuilder,
  setShowSmartBuilder,
  smartName,
  setSmartName,
  smartDesc,
  setSmartDesc,
  smartMatchMode,
  setSmartMatchMode,
  smartRules,
  setSmartRules,
  onCreateSmartPlaylist,
  coverShape,
  onPlayTrack,
  showToast
}) => {
  if (mode === 'smart-lists') {
    return (
      <div className="flex flex-col gap-5">
        <div
          className="flex items-center justify-between gap-4 border-b pb-3"
          style={{ borderColor: 'var(--theme-border)' }}
        >
          <div>
            <h1 className="text-xl sm:text-2xl font-bold font-display tracking-tight">
              Listas Inteligentes
            </h1>
            <p className="text-xs mt-0.5" style={{ color: 'var(--theme-muted)' }}>
              Reglas dinámicas automáticas por BPM, reproducciones, año o favoritos.
            </p>
          </div>

          <button
            onClick={() => setShowSmartBuilder(!showSmartBuilder)}
            className="min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-accent)',
              color: 'var(--theme-accent-fg)'
            }}
          >
            <Sparkles className="w-4 h-4" />
            Nueva Regla
          </button>
        </div>

        {showSmartBuilder && (
          <form
            onSubmit={onCreateSmartPlaylist}
            className="p-4 rounded-2xl border flex flex-col gap-3"
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-border)'
            }}
          >
            <h2 className="text-sm font-semibold">Constructor de Lista Inteligente</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <input
                type="text"
                required
                value={smartName}
                onChange={e => setSmartName(e.target.value)}
                placeholder="Nombre (ej. Gym > 120 BPM)"
                className="px-3 py-2 text-xs rounded-xl border outline-none"
                style={{
                  backgroundColor: 'var(--theme-bg)',
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-text)'
                }}
              />
              <input
                type="text"
                value={smartDesc}
                onChange={e => setSmartDesc(e.target.value)}
                placeholder="Descripción..."
                className="px-3 py-2 text-xs rounded-xl border outline-none"
                style={{
                  backgroundColor: 'var(--theme-bg)',
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-text)'
                }}
              />
              <select
                value={smartMatchMode}
                onChange={e => setSmartMatchMode(e.target.value as 'all' | 'any')}
                className="px-3 py-2 text-xs rounded-xl border outline-none"
                style={{
                  backgroundColor: 'var(--theme-bg)',
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-text)'
                }}
              >
                <option value="all" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                  Cumplir TODAS (AND)
                </option>
                <option value="any" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                  Cumplir CUALQUIERA (OR)
                </option>
              </select>
            </div>

            <div className="flex flex-col gap-2">
              {smartRules.map((rule, idx) => (
                <div key={rule.id} className="flex flex-wrap items-center gap-2">
                  <select
                    value={rule.field}
                    onChange={e => {
                      const field = e.target.value as SmartRuleField;
                      setSmartRules(prev =>
                        prev.map((r, i) =>
                          i === idx
                            ? {
                                ...r,
                                field,
                                operator:
                                  field === 'genre'
                                    ? 'contains'
                                    : field === 'isFavorite'
                                      ? 'equals'
                                      : 'gte',
                                value:
                                  field === 'isFavorite'
                                    ? true
                                    : field === 'genre'
                                      ? 'Synth'
                                      : 120
                              }
                            : r
                        )
                      );
                    }}
                    className="px-2.5 py-1.5 text-xs rounded-lg border"
                    style={{
                      backgroundColor: 'var(--theme-bg)',
                      borderColor: 'var(--theme-border)',
                      color: 'var(--theme-text)'
                    }}
                  >
                    <option value="bpm" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                      Tempo (BPM)
                    </option>
                    <option
                      value="playCount"
                      style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    >
                      Reproducciones
                    </option>
                    <option value="year" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                      Año
                    </option>
                    <option value="genre" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                      Género
                    </option>
                    <option
                      value="isFavorite"
                      style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    >
                      Favorito
                    </option>
                  </select>

                  <select
                    value={rule.operator}
                    onChange={e => {
                      const op = e.target.value as SmartRuleOperator;
                      setSmartRules(prev =>
                        prev.map((r, i) => (i === idx ? { ...r, operator: op } : r))
                      );
                    }}
                    className="px-2.5 py-1.5 text-xs rounded-lg border"
                    style={{
                      backgroundColor: 'var(--theme-bg)',
                      borderColor: 'var(--theme-border)',
                      color: 'var(--theme-text)'
                    }}
                  >
                    <option value="gte" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                      Mayor o igual (≥)
                    </option>
                    <option value="lte" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                      Menor o igual (≤)
                    </option>
                    <option value="equals" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                      Igual (=)
                    </option>
                    <option
                      value="contains"
                      style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    >
                      Contiene
                    </option>
                  </select>

                  {rule.field === 'isFavorite' ? (
                    <select
                      value={String(rule.value)}
                      onChange={e =>
                        setSmartRules(prev =>
                          prev.map((r, i) =>
                            i === idx ? { ...r, value: e.target.value === 'true' } : r
                          )
                        )
                      }
                      className="px-2.5 py-1.5 text-xs rounded-lg border"
                      style={{
                        backgroundColor: 'var(--theme-bg)',
                        borderColor: 'var(--theme-border)',
                        color: 'var(--theme-text)'
                      }}
                    >
                      <option value="true" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                        Sí
                      </option>
                      <option value="false" style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}>
                        No
                      </option>
                    </select>
                  ) : (
                    <input
                      type={rule.field === 'genre' ? 'text' : 'number'}
                      value={String(rule.value)}
                      onChange={e =>
                        setSmartRules(prev =>
                          prev.map((r, i) =>
                            i === idx
                              ? {
                                  ...r,
                                  value:
                                    rule.field === 'genre'
                                      ? e.target.value
                                      : Number(e.target.value)
                                }
                              : r
                          )
                        )
                      }
                      className="px-2.5 py-1.5 text-xs rounded-lg border w-28"
                      style={{
                        backgroundColor: 'var(--theme-bg)',
                        borderColor: 'var(--theme-border)',
                        color: 'var(--theme-text)'
                      }}
                    />
                  )}
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() =>
                  setSmartRules(prev => [
                    ...prev,
                    { id: `r-${Date.now()}`, field: 'playCount', operator: 'gte', value: 10 }
                  ])
                }
                className="text-xs font-medium underline cursor-pointer"
                style={{ color: 'var(--theme-accent)' }}
              >
                + Añadir condición
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl text-xs font-semibold cursor-pointer"
                style={{
                  backgroundColor: 'var(--theme-accent)',
                  color: 'var(--theme-accent-fg)'
                }}
              >
                Activar Lista
              </button>
            </div>
          </form>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {smartPlaylists.map(sp => {
            const matched = evaluateSmartPlaylist(sp, tracks);
            const isSelected = sp.id === activeSmartPlaylist?.id;
            return (
              <button
                key={sp.id}
                onClick={() => onSelectSmartPlaylist(sp.id)}
                className="p-4 rounded-2xl border text-left transition-colors flex flex-col justify-between gap-2 cursor-pointer"
                style={{
                  backgroundColor: isSelected
                    ? 'var(--theme-accent-soft)'
                    : 'var(--theme-surface)',
                  borderColor: isSelected ? 'var(--theme-accent)' : 'var(--theme-border)'
                }}
              >
                <div>
                  <h3 className="text-sm font-bold truncate">{sp.name}</h3>
                  <p
                    className="text-xs line-clamp-2 mt-1"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    {sp.description}
                  </p>
                </div>
                <div
                  className="flex items-center gap-1.5 text-xs font-mono-tabular pt-1"
                  style={{ color: 'var(--theme-muted)' }}
                >
                  <span>{matched.length} pistas</span>
                  <span aria-hidden="true">·</span>
                  <span>{sp.rules.length} regla(s)</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <div
        className="flex items-center justify-between gap-4 border-b pb-3"
        style={{ borderColor: 'var(--theme-border)' }}
      >
        <div>
          <h1 className="text-xl sm:text-2xl font-bold font-display tracking-tight">
            Listas de Reproducción
          </h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--theme-muted)' }}>
            Reordena canciones, fusiona listas, duplica o exporta en JSON.
          </p>
        </div>

        <button
          onClick={() => setShowCreatePlaylistForm(!showCreatePlaylistForm)}
          className="min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          style={{
            backgroundColor: 'var(--theme-accent)',
            color: 'var(--theme-accent-fg)'
          }}
        >
          <Plus className="w-4 h-4" />
          Nueva Lista
        </button>
      </div>

      {showCreatePlaylistForm && (
        <form
          onSubmit={onCreatePlaylist}
          className="p-4 rounded-2xl border flex flex-col gap-3"
          style={{
            backgroundColor: 'var(--theme-surface)',
            borderColor: 'var(--theme-border)'
          }}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Crear Lista Personalizada</h2>
            <button
              type="button"
              onClick={() => setShowCreatePlaylistForm(false)}
              className="p-1 cursor-pointer"
              style={{ color: 'var(--theme-muted)' }}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              required
              value={newPlaylistName}
              onChange={e => setNewPlaylistName(e.target.value)}
              placeholder="Nombre de la lista..."
              className="w-full px-3.5 py-2 text-sm rounded-xl border outline-none"
              style={{
                backgroundColor: 'var(--theme-bg)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            />
            <input
              type="text"
              value={newPlaylistDesc}
              onChange={e => setNewPlaylistDesc(e.target.value)}
              placeholder="Descripción opcional..."
              className="w-full px-3.5 py-2 text-sm rounded-xl border outline-none"
              style={{
                backgroundColor: 'var(--theme-bg)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            />
          </div>
          <div className="flex items-center justify-end gap-2">
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer"
              style={{
                backgroundColor: 'var(--theme-accent)',
                color: 'var(--theme-accent-fg)'
              }}
            >
              Guardar Lista
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {playlists.map(pl => {
          const isSelected = pl.id === activePlaylist?.id;
          const totalSec = pl.trackIds.reduce((acc, id) => {
            const t = visibleTracks.find(item => item.id === id);
            return acc + (t ? t.duration : 0);
          }, 0);

          return (
            <button
              key={pl.id}
              onClick={() => onSelectPlaylist(pl.id)}
              className="p-4 rounded-2xl border text-left transition-colors flex flex-col justify-between gap-2 cursor-pointer"
              style={{
                backgroundColor: isSelected
                  ? 'var(--theme-accent-soft)'
                  : 'var(--theme-surface)',
                borderColor: isSelected ? 'var(--theme-accent)' : 'var(--theme-border)'
              }}
            >
              <div>
                <h3 className="text-sm font-bold truncate">{pl.name}</h3>
                <p className="text-xs line-clamp-2 mt-1" style={{ color: 'var(--theme-muted)' }}>
                  {pl.description}
                </p>
              </div>
              <div
                className="flex items-center gap-1.5 text-xs font-mono-tabular pt-1"
                style={{ color: 'var(--theme-muted)' }}
              >
                <span>{pl.trackIds.length} pistas</span>
                <span aria-hidden="true">·</span>
                <span>{Math.round(totalSec / 60)} min</span>
              </div>
            </button>
          );
        })}
      </div>

      {activePlaylist && (
        <div
          className="rounded-2xl border p-4 sm:p-5 flex flex-col gap-4"
          style={{
            backgroundColor: 'var(--theme-surface)',
            borderColor: 'var(--theme-border)'
          }}
        >
          <div
            className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3"
            style={{ borderColor: 'var(--theme-border)' }}
          >
            <div>
              <h2 className="text-lg font-bold font-display">{activePlaylist.name}</h2>
              <p className="text-xs" style={{ color: 'var(--theme-muted)' }}>
                {activePlaylist.description}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => {
                  if (activePlaylistTracks.length > 0) {
                    onPlayTrack(
                      activePlaylistTracks[0],
                      activePlaylistTracks.map(t => t.id),
                      true
                    );
                  }
                }}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                style={{
                  backgroundColor: 'var(--theme-accent)',
                  color: 'var(--theme-accent-fg)'
                }}
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                Reproducir
              </button>

              <button
                onClick={onDuplicatePlaylist}
                className="px-3 py-2 rounded-xl text-xs font-medium border flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                style={{ borderColor: 'var(--theme-border)' }}
              >
                <Copy className="w-3.5 h-3.5" />
                Duplicar
              </button>

              <button
                onClick={onExportPlaylistJson}
                className="px-3 py-2 rounded-xl text-xs font-medium border flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                style={{ borderColor: 'var(--theme-border)' }}
              >
                <Download className="w-3.5 h-3.5" />
                JSON
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="flex items-center gap-2">
              <select
                value={mergeTargetId}
                onChange={e => setMergeTargetId(e.target.value)}
                className="flex-1 px-3 py-2 rounded-xl text-xs border outline-none"
                style={{
                  backgroundColor: 'var(--theme-bg)',
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-text)'
                }}
              >
                <option value="">Fusionar con otra lista...</option>
                {playlists
                  .filter(p => p.id !== activePlaylist.id)
                  .map(p => (
                    <option
                      key={p.id}
                      value={p.id}
                      style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                    >
                      {p.name} ({p.trackIds.length} pistas)
                    </option>
                  ))}
              </select>
              <button
                onClick={onMergePlaylists}
                disabled={!mergeTargetId}
                className="px-3 py-2 rounded-xl text-xs font-medium border flex items-center gap-1 whitespace-nowrap shrink-0 disabled:opacity-40 cursor-pointer"
                style={{ borderColor: 'var(--theme-border)' }}
              >
                <GitMerge className="w-3.5 h-3.5" />
                Fusionar
              </button>
            </div>

            <select
              onChange={e => {
                const tId = e.target.value;
                if (!tId) return;
                setPlaylists(prev =>
                  prev.map(p =>
                    p.id === activePlaylist.id && !p.trackIds.includes(tId)
                      ? { ...p, trackIds: [...p.trackIds, tId] }
                      : p
                  )
                );
                e.target.value = '';
                showToast('Pista añadida a la lista');
              }}
              defaultValue=""
              className="w-full px-3 py-2 rounded-xl text-xs border outline-none"
              style={{
                backgroundColor: 'var(--theme-bg)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            >
              <option value="" disabled>
                + Añadir canción a esta lista...
              </option>
              {visibleTracks.map(t => (
                <option
                  key={t.id}
                  value={t.id}
                  style={{ backgroundColor: '#0f172a', color: '#f8fafc' }}
                >
                  {t.title} — {t.artist}
                </option>
              ))}
            </select>
          </div>

          <div className="divide-y border-t" style={{ borderColor: 'var(--theme-border)' }}>
            {activePlaylistTracks.map((track, idx) => (
              <div key={track.id} className="py-2.5 flex items-center justify-between gap-2">
                <div
                  onClick={() =>
                    onPlayTrack(
                      track,
                      activePlaylistTracks.map(t => t.id),
                      true
                    )
                  }
                  className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                >
                  <span
                    className="text-xs font-mono-tabular w-5"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    {(idx + 1).toString().padStart(2, '0')}
                  </span>
                  <CoverArt
                    src={track.coverUrl}
                    alt={track.title}
                    dominantColor={track.dominantColor}
                    shape={coverShape}
                    sizeClass="w-10 h-10"
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold truncate">{track.title}</p>
                    <p className="text-xs truncate" style={{ color: 'var(--theme-muted)' }}>
                      {track.artist} ·{' '}
                      <span className="font-mono-tabular">{formatDuration(track.duration)}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-0.5 shrink-0">
                  <button
                    onClick={() => onMovePlaylistTrack(idx, -1)}
                    disabled={idx === 0}
                    aria-label="Subir"
                    className="p-2 rounded-lg disabled:opacity-30 cursor-pointer"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onMovePlaylistTrack(idx, 1)}
                    disabled={idx === activePlaylistTracks.length - 1}
                    aria-label="Bajar"
                    className="p-2 rounded-lg disabled:opacity-30 cursor-pointer"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onRemoveFromPlaylist(track.id)}
                    aria-label="Quitar"
                    className="p-2 rounded-lg cursor-pointer"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
