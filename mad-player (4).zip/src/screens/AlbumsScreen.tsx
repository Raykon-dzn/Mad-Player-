import React from 'react';
import { Track } from '../types/music';
import { CoverArt } from '../components/CoverArt';

interface AlbumsScreenProps {
  groupedAlbums: [string, Track[]][];
  onPlayTrack: (track: Track, queueIds: string[], fromUserSelection: boolean) => void;
}

export const AlbumsScreen: React.FC<AlbumsScreenProps> = ({ groupedAlbums, onPlayTrack }) => {
  return (
    <div className="flex flex-col gap-4">
      <div className="border-b pb-3" style={{ borderColor: 'var(--theme-border)' }}>
        <h1 className="text-xl font-bold font-display">Álbumes ({groupedAlbums.length})</h1>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
        {groupedAlbums.map(([albumName, albumTracks]) => {
          const first = albumTracks[0];
          return (
            <div
              key={albumName}
              onClick={() =>
                onPlayTrack(
                  first,
                  albumTracks.map(t => t.id),
                  true
                )
              }
              className="p-3 rounded-2xl border flex flex-col gap-2.5 cursor-pointer"
              style={{
                backgroundColor: 'var(--theme-surface)',
                borderColor: 'var(--theme-border)'
              }}
            >
              <CoverArt
                src={first.coverUrl}
                alt={albumName}
                dominantColor={first.dominantColor}
                secondaryColor={first.secondaryColor}
                shape="rounded"
                sizeClass="w-full aspect-square"
              />
              <div className="min-w-0">
                <h3 className="text-sm font-bold truncate">{albumName}</h3>
                <p className="text-xs truncate" style={{ color: 'var(--theme-muted)' }}>
                  {first.artist} · {albumTracks.length} pista(s)
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
