import React from 'react';
import { FolderSearch, MoreVertical, Music2, Upload } from 'lucide-react';
import { Track } from '../types/music';
import { formatDaysAgo } from '../utils/formatters';

interface SuggestedScreenProps {
  recentlyPlayedTracks: Track[];
  mostPlayedTracks: Track[];
  favoriteTracks: Track[];
  recentlyAddedTracks: Track[];
  isScanningFolder: boolean;
  onTriggerImportFiles: () => void;
  onTriggerScanFolder: () => void;
  onPlayTrack: (track: Track, queueIds: string[], fromUserSelection: boolean) => void;
  onNavigateToLibrary: (options?: { sortBy?: 'playCount'; onlyFavorites?: boolean }) => void;
  onOpenTrackMenu: (trackId: string) => void;
}

export const SuggestedScreen: React.FC<SuggestedScreenProps> = ({
  recentlyPlayedTracks,
  mostPlayedTracks,
  favoriteTracks,
  recentlyAddedTracks,
  isScanningFolder,
  onTriggerImportFiles,
  onTriggerScanFolder,
  onPlayTrack,
  onNavigateToLibrary,
  onOpenTrackMenu
}) => {
  return (
    <div className="flex flex-col gap-7">
      {/* Quick Import Audio & Folder Scan Banner */}
      <div
        className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl border"
        style={{
          backgroundColor: 'var(--theme-surface)',
          borderColor: 'var(--theme-border)'
        }}
      >
        <div className="min-w-0">
          <p className="text-xs font-extrabold truncate" style={{ color: 'var(--theme-text)' }}>
            Escanea carpetas o importa música de tu dispositivo
          </p>
          <p className="text-[11px] truncate" style={{ color: 'var(--theme-muted)' }}>
            Reconoce subcarpetas completas y portadas ID3/M4A/FLAC incrustadas
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onTriggerScanFolder}
            disabled={isScanningFolder}
            className="px-3.5 py-2 rounded-xl text-xs font-extrabold bg-[#1cc8ee] text-slate-950 flex items-center gap-1.5 shrink-0 cursor-pointer disabled:opacity-50"
          >
            <FolderSearch className="w-3.5 h-3.5" />
            {isScanningFolder ? 'Importando...' : 'Importar carpeta'}
          </button>
          <button
            onClick={onTriggerImportFiles}
            className="px-3 py-2 rounded-xl text-xs font-extrabold border flex items-center gap-1.5 shrink-0 cursor-pointer"
            style={{
              borderColor: 'var(--theme-border)',
              color: 'var(--theme-text)'
            }}
          >
            <Upload className="w-3.5 h-3.5" />
            Archivos
          </button>
        </div>
      </div>

      {/* 1. REPRODUCIDAS RECIENTEMENTE */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2
            className="text-lg font-extrabold font-display tracking-tight"
            style={{ color: 'var(--theme-text)' }}
          >
            Reproducidas recientemente
          </h2>
          <button
            onClick={() => onNavigateToLibrary()}
            className="text-xs font-extrabold uppercase tracking-wider hover:opacity-80 cursor-pointer"
            style={{ color: 'var(--theme-muted)' }}
          >
            VER TODOS
          </button>
        </div>

        <div className="flex items-start gap-3.5 overflow-x-auto pb-1 no-scrollbar">
          {recentlyPlayedTracks.map(track => (
            <div
              key={`rec-${track.id}`}
              onClick={() =>
                onPlayTrack(
                  track,
                  recentlyPlayedTracks.map(t => t.id),
                  true
                )
              }
              className="w-36 sm:w-40 shrink-0 flex flex-col gap-2 cursor-pointer group"
            >
              <div className="w-full aspect-square rounded-xl overflow-hidden bg-[#3b4d5e] relative shadow-md">
                {track.coverUrl ? (
                  <img
                    src={track.coverUrl}
                    alt={track.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-[#3b4d5e] text-[#132230]">
                    <Music2 className="w-14 h-14 stroke-[2.2]" />
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-extrabold truncate" style={{ color: 'var(--theme-text)' }}>
                  {track.title}
                </p>
                <p
                  className="text-xs font-semibold truncate mt-0.5"
                  style={{ color: 'var(--theme-muted)' }}
                >
                  {track.artist}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. MÁS REPRODUCIDAS */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2
            className="text-lg font-extrabold font-display tracking-tight"
            style={{ color: 'var(--theme-text)' }}
          >
            Más reproducidas
          </h2>
          <button
            onClick={() => onNavigateToLibrary({ sortBy: 'playCount' })}
            className="text-xs font-extrabold uppercase tracking-wider hover:opacity-80 cursor-pointer"
            style={{ color: 'var(--theme-muted)' }}
          >
            VER TODOS
          </button>
        </div>

        <div className="flex items-start gap-3.5 overflow-x-auto pb-1 no-scrollbar">
          {mostPlayedTracks.map(track => (
            <div
              key={`most-${track.id}`}
              onClick={() =>
                onPlayTrack(
                  track,
                  mostPlayedTracks.map(t => t.id),
                  true
                )
              }
              className="w-36 sm:w-40 shrink-0 flex flex-col gap-2 cursor-pointer group"
            >
              <div className="w-full aspect-square rounded-xl overflow-hidden bg-[#3b4d5e] relative shadow-md">
                {track.coverUrl ? (
                  <img
                    src={track.coverUrl}
                    alt={track.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-[#3b4d5e] text-[#132230]">
                    <Music2 className="w-14 h-14 stroke-[2.2]" />
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-extrabold truncate" style={{ color: 'var(--theme-text)' }}>
                  {track.title}
                </p>
                <p
                  className="text-xs font-semibold truncate mt-0.5"
                  style={{ color: 'var(--theme-muted)' }}
                >
                  {track.artist}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. FAVORITOS */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2
            className="text-lg font-extrabold font-display tracking-tight"
            style={{ color: 'var(--theme-text)' }}
          >
            Favoritos
          </h2>
          <button
            onClick={() => onNavigateToLibrary({ onlyFavorites: true })}
            className="text-xs font-extrabold uppercase tracking-wider hover:opacity-80 cursor-pointer"
            style={{ color: 'var(--theme-muted)' }}
          >
            VER TODOS
          </button>
        </div>

        {favoriteTracks.length === 0 ? (
          <p className="text-xs py-2" style={{ color: 'var(--theme-muted)' }}>
            Aún no tienes canciones en Favoritos. Haz doble toque debajo de la portada en el
            reproductor para marcar tu canción favorita.
          </p>
        ) : (
          <div className="flex items-start gap-3.5 overflow-x-auto pb-1 no-scrollbar">
            {favoriteTracks.map(track => (
              <div
                key={`fav-${track.id}`}
                onClick={() =>
                  onPlayTrack(
                    track,
                    favoriteTracks.map(t => t.id),
                    true
                  )
                }
                className="w-36 sm:w-40 shrink-0 flex flex-col gap-2 cursor-pointer group"
              >
                <div className="w-full aspect-square rounded-xl overflow-hidden bg-[#3b4d5e] relative shadow-md">
                  {track.coverUrl ? (
                    <img
                      src={track.coverUrl}
                      alt={track.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-[#3b4d5e] text-[#132230]">
                      <Music2 className="w-14 h-14 stroke-[2.2]" />
                    </div>
                  )}
                </div>
                <div className="min-w-0">
                  <p
                    className="text-sm font-extrabold truncate"
                    style={{ color: 'var(--theme-text)' }}
                  >
                    {track.title}
                  </p>
                  <p
                    className="text-xs font-semibold truncate mt-0.5"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    {track.artist}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4. ÚLTIMO AGREGADO */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2
            className="text-lg font-extrabold font-display tracking-tight"
            style={{ color: 'var(--theme-text)' }}
          >
            Último agregado
          </h2>
          <button
            onClick={() => onNavigateToLibrary()}
            className="text-xs font-extrabold uppercase tracking-wider hover:opacity-80 cursor-pointer"
            style={{ color: 'var(--theme-muted)' }}
          >
            VER TODOS
          </button>
        </div>

        <div className="flex flex-col gap-3">
          {recentlyAddedTracks.map(track => (
            <div
              key={`added-${track.id}`}
              onClick={() =>
                onPlayTrack(
                  track,
                  recentlyAddedTracks.map(t => t.id),
                  true
                )
              }
              className="flex items-center justify-between gap-3 py-1 cursor-pointer group"
            >
              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                <div className="w-13 h-13 rounded-xl overflow-hidden shrink-0 bg-[#3b4d5e] flex items-center justify-center">
                  {track.coverUrl ? (
                    <img
                      src={track.coverUrl}
                      alt={track.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Music2 className="w-7 h-7 text-[#132230] stroke-[2.2]" />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <p
                    className="text-base font-extrabold truncate"
                    style={{ color: 'var(--theme-text)' }}
                  >
                    {track.title}
                  </p>
                  <p
                    className="text-xs font-bold truncate mt-0.5"
                    style={{ color: 'var(--theme-muted)' }}
                  >
                    {formatDaysAgo(track.addedAt)} • {track.artist}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={e => {
                  e.stopPropagation();
                  onOpenTrackMenu(track.id);
                }}
                aria-label="Opciones de canción"
                className="w-9 h-9 rounded-full flex items-center justify-center hover:opacity-80 shrink-0 cursor-pointer"
                style={{ color: 'var(--theme-muted)' }}
              >
                <MoreVertical className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
