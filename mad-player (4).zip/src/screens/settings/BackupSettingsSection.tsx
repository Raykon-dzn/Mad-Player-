import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { BackupSelectionState, SettingsDialogType } from '../../hooks/useSettings';
import { formatBackupSubtitle } from './SettingsToggle';

interface BackupSettingsSectionProps {
  onGoBack: () => void;
  setActiveDialog: React.Dispatch<React.SetStateAction<SettingsDialogType>>;
  cloudEmail: string;
  onOpenCloudEmailDialog: () => void;
  cloudSelection: BackupSelectionState;
  localSelection: BackupSelectionState;
  onCloudBackup: () => void;
  onCloudRestore: () => void;
  onLocalBackupDownload: () => void;
  onTriggerLocalRestoreFile: () => void;
}

export const BackupSettingsSection: React.FC<BackupSettingsSectionProps> = ({
  onGoBack,
  setActiveDialog,
  cloudEmail,
  onOpenCloudEmailDialog,
  cloudSelection,
  localSelection,
  onCloudBackup,
  onCloudRestore,
  onLocalBackupDownload,
  onTriggerLocalRestoreFile
}) => {
  return (
    <>
      <div className="sticky top-0 z-20 flex items-center gap-5 px-4 py-4 bg-[#061928]/95 backdrop-blur-md">
        <button
          onClick={onGoBack}
          aria-label="Volver"
          className="w-10 h-10 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-extrabold font-display tracking-tight text-white">
          Respaldar
        </h1>
      </div>

      <div className="max-w-xl w-full mx-auto px-4 pb-16 flex flex-col gap-8 pt-2">
        {/* SECTION 1: NUBE */}
        <div className="flex flex-col gap-5">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            NUBE
          </span>

          <button
            onClick={onOpenCloudEmailDialog}
            className="flex flex-col gap-1 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Copia de seguridad en</span>
            <span className="text-sm font-extrabold text-[#6e8499]">{cloudEmail}</span>
          </button>

          <button
            onClick={() => setActiveDialog('cloud-backup-items')}
            className="flex flex-col gap-1.5 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white leading-snug">
              Seleccione elementos para respaldar o restaurar
            </span>
            <span className="text-sm font-extrabold text-[#6e8499] leading-relaxed">
              {formatBackupSubtitle(cloudSelection)}
            </span>
          </button>

          <button
            onClick={onCloudBackup}
            className="py-1 text-left text-base font-extrabold text-white hover:text-[#1cc8ee] transition-colors cursor-pointer"
          >
            Respaldar
          </button>

          <button
            onClick={onCloudRestore}
            className="py-1 text-left text-base font-extrabold text-white hover:text-[#1cc8ee] transition-colors cursor-pointer"
          >
            Restaurar
          </button>
        </div>

        {/* SECTION 2: LOCAL */}
        <div className="flex flex-col gap-5">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            LOCAL
          </span>

          <button
            onClick={() => setActiveDialog('local-backup-items')}
            className="flex flex-col gap-1.5 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white leading-snug">
              Seleccione elementos para respaldar o restaurar
            </span>
            <span className="text-sm font-extrabold text-[#6e8499] leading-relaxed">
              {formatBackupSubtitle(localSelection)}
            </span>
          </button>

          <button
            onClick={onLocalBackupDownload}
            className="py-1 text-left text-base font-extrabold text-white hover:text-[#1cc8ee] transition-colors cursor-pointer"
          >
            Respaldar
          </button>

          <button
            onClick={onTriggerLocalRestoreFile}
            className="py-1 text-left text-base font-extrabold text-white hover:text-[#1cc8ee] transition-colors cursor-pointer"
          >
            Restaurar
          </button>
        </div>
      </div>
    </>
  );
};
