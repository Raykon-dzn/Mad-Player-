import React from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ChevronRight,
  CloudUpload,
  Disc3,
  FolderX,
  Headphones,
  Info,
  MessageSquareWarning,
  Music2,
  Radar,
  Share2,
  Smartphone
} from 'lucide-react';
import { EqualizerState, Track } from '../../types/music';
import { SettingsSubPage, useSettingsContext } from '../../hooks/useSettings';
import { requestPersistentStorage, StorageUsageEstimate } from '../../services/mediaStorageDb';
import { formatStorageBytes } from './SettingsToggle';

interface MainSettingsSectionProps {
  onClose: () => void;
  navigateToSubPage: (nextPage: SettingsSubPage) => void;
  tracks: Track[];
  visibleTracks: Track[];
  hiddenTracks: Track[];
  currentTrack?: Track;
  eqState: EqualizerState;
  totalHoursDisplay: number;
  storageEstimate: StorageUsageEstimate;
  folderBackupStats: { count: number; totalBytes: number };
  refreshStorageUsage: (tryPersist?: boolean) => Promise<void>;
  onTriggerScanMedia: () => void;
  onShareText: (text: string) => void;
  showToast: (msg: string) => void;
}

export const MainSettingsSection: React.FC<MainSettingsSectionProps> = ({
  onClose,
  navigateToSubPage,
  tracks,
  visibleTracks,
  hiddenTracks,
  currentTrack,
  eqState,
  totalHoursDisplay,
  storageEstimate,
  folderBackupStats,
  refreshStorageUsage,
  onTriggerScanMedia,
  onShareText,
  showToast
}) => {
  const { userProfileName, userProfileAvatar } = useSettingsContext();

  return (
    <>
      <div className="sticky top-0 z-20 flex items-center gap-5 px-4 py-4 bg-[#061928]/95 backdrop-blur-md">
        <button
          onClick={onClose}
          aria-label="Volver"
          className="w-10 h-10 rounded-full flex items-center justify-center text-slate-200 hover:bg-white/10 cursor-pointer"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-extrabold font-display tracking-tight text-white">
          Ajustes
        </h1>
      </div>

      <div className="max-w-xl w-full mx-auto px-4 pb-16 flex flex-col gap-6">
        {/* Top Profile & Listening Hours Card -> Tapping opens Profile Screen */}
        <div
          className="rounded-2xl p-4 flex flex-col gap-4 shadow-lg"
          style={{ backgroundColor: '#132838' }}
        >
          <div
            onClick={() => navigateToSubPage('profile')}
            className="flex items-center justify-between gap-4 cursor-pointer group"
          >
            <div className="flex items-center gap-4 min-w-0">
              <div className="w-16 h-16 rounded-full overflow-hidden shrink-0 border border-white/15 bg-gradient-to-br from-amber-200 via-amber-300 to-sky-700 flex items-center justify-center">
                {userProfileAvatar || currentTrack?.coverUrl ? (
                  <img
                    src={userProfileAvatar || currentTrack?.coverUrl}
                    alt={userProfileName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Music2 className="w-8 h-8 text-slate-900" />
                )}
              </div>
              <div className="min-w-0">
                <h2 className="text-lg font-extrabold text-white truncate">
                  {userProfileName}
                </h2>
                <p className="text-sm text-[#899eb2] font-bold flex items-center gap-1.5 mt-1">
                  <Headphones className="w-4 h-4" />
                  <span>{totalHoursDisplay} hrs</span>
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8] group-hover:translate-x-0.5 transition-transform shrink-0" />
          </div>

          <div className="border-t border-white/10" />

          <button
            onClick={() =>
              onShareText(
                `Escucho mi música en Mad Player (${totalHoursDisplay} hrs reproducidas).`
              )
            }
            className="flex items-center justify-between py-1 text-left cursor-pointer group"
          >
            <div className="flex items-center gap-4">
              <Share2 className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">Compartir App</span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8] group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* SECTION: GENERAL */}
        <div className="flex flex-col gap-1">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee] px-1 mb-2">
            GENERAL
          </span>

          <button
            onClick={() => navigateToSubPage('app')}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <Smartphone className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">App</span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>

          <button
            onClick={() => navigateToSubPage('elegir-tema')}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <Smartphone className="w-5 h-5 text-[#1cc8ee]" />
              <div className="text-left">
                <span className="text-base font-extrabold text-white block">Tema</span>
                <span className="text-xs font-bold text-[#6e8499]">
                  Elegir tema (Imagen, Colores, Degradado y Color Énfasis)
                </span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>

          <button
            onClick={() => navigateToSubPage('audio')}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <Disc3 className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">Audio</span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>
        </div>

        {/* SECTION: MULTIMEDIA */}
        <div className="flex flex-col gap-1">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee] px-1 mb-2">
            MULTIMEDIA
          </span>

          <button
            onClick={onTriggerScanMedia}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <Radar className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">Escanear medios</span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>

          <button
            onClick={() => navigateToSubPage('hidden-files')}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <FolderX className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">Hidden Files</span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>

          <button
            onClick={() => navigateToSubPage('backup')}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <CloudUpload className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">Respaldar</span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>

          {/* Uso de almacenamiento IndexedDB (navigator.storage.estimate + persist) */}
          <div className="mt-2 rounded-2xl p-3.5 bg-[#132838] border border-white/10 flex flex-col gap-2.5">
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-extrabold text-white">
                  Uso de almacenamiento local (IndexedDB)
                </p>
                <p className="text-xs font-bold text-[#6e8499] mt-0.5">
                  {storageEstimate.supported
                    ? `${formatStorageBytes(storageEstimate.usageBytes)} usados de ${formatStorageBytes(storageEstimate.quotaBytes)} (${
                        storageEstimate.quotaBytes > 0
                          ? Math.min(
                              100,
                              (storageEstimate.usageBytes / storageEstimate.quotaBytes) * 100
                            ).toFixed(2)
                          : '0.00'
                      }%)`
                    : 'Estimación de almacenamiento no disponible en este navegador'}
                </p>
              </div>
              <button
                type="button"
                onClick={async () => {
                  const granted = await requestPersistentStorage();
                  await refreshStorageUsage(false);
                  showToast(
                    granted
                      ? 'Almacenamiento persistente activado (navigator.storage.persist)'
                      : 'Uso de almacenamiento actualizado'
                  );
                }}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold shrink-0 cursor-pointer transition-colors ${
                  storageEstimate.persisted
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-[#1cc8ee]/15 text-[#1cc8ee] border border-[#1cc8ee]/30 hover:bg-[#1cc8ee]/25'
                }`}
              >
                {storageEstimate.persisted ? 'Persistente activo' : 'Persistir datos'}
              </button>
            </div>

            {storageEstimate.supported && storageEstimate.quotaBytes > 0 && (
              <div className="w-full h-1.5 rounded-full bg-[#091824] overflow-hidden">
                <div
                  className="h-full rounded-full bg-[#1cc8ee] transition-all duration-300"
                  style={{
                    width: `${Math.max(
                      2,
                      Math.min(
                        100,
                        (storageEstimate.usageBytes / storageEstimate.quotaBytes) * 100
                      )
                    )}%`
                  }}
                />
              </div>
            )}

            {folderBackupStats.count > 0 && (
              <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="min-w-0 text-[11px] font-bold text-amber-200 leading-relaxed">
                  <span>
                    Aviso: Se guardó copia de respaldo de audio en IndexedDB para{' '}
                    {folderBackupStats.count} pista(s) de carpeta (espacio usado:{' '}
                    {formatStorageBytes(
                      folderBackupStats.totalBytes > 0
                        ? folderBackupStats.totalBytes
                        : storageEstimate.usageBytes
                    )}
                    ) porque{' '}
                  </span>
                  <span className="font-extrabold text-amber-100">
                    este navegador no permite reabrir carpetas
                  </span>
                  <span> (sin FileSystemFileHandle).</span>
                </div>
              </div>
            )}

            <p className="text-[11px] font-bold text-[#7c93a8]">
              Solo se omite el audioBlob cuando existe FileSystemFileHandle; si no hay
              fileHandle, se guarda el audioBlob como respaldo.
            </p>
          </div>
        </div>

        {/* SECTION: MÁS */}
        <div className="flex flex-col gap-1">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee] px-1 mb-2">
            MÁS
          </span>

          <button
            onClick={() => {
              onShareText(
                `Mad Player Log Report v7.8.5 — Pistas: ${tracks.length}, Visibles: ${visibleTracks.length}, Ocultas: ${hiddenTracks.length}, Velocidad: ${eqState.playbackRate}x, Tono: ${eqState.pitchRate}`
              );
            }}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <MessageSquareWarning className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">
                Compartir registros de aplicación
              </span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>

          <button
            onClick={() => navigateToSubPage('about')}
            className="flex items-center justify-between py-3.5 px-1 hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-5">
              <Info className="w-5 h-5 text-[#7c93a8]" />
              <span className="text-base font-extrabold text-white">Acerca de</span>
            </div>
            <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
          </button>
        </div>
      </div>
    </>
  );
};
