import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  Lock,
  PlusCircle,
  Upload,
  X
} from 'lucide-react';
import {
  EqualizerState,
  PlayerSkin,
  ThemeBaseId,
  ThemeConfig,
  Track
} from '../../types/music';
import { EQ_PRESETS } from '../../data/initialLibrary';
import {
  BackupSelectionState,
  SettingsDialogType,
  useSettingsContext
} from '../../hooks/useSettings';
import { saveCloudEmailToDb } from '../../services/mediaStorageDb';
import { formatDuration, SettingsToggle } from './SettingsToggle';

interface SettingsDialogsModalProps {
  activeDialog: SettingsDialogType;
  setActiveDialog: React.Dispatch<React.SetStateAction<SettingsDialogType>>;
  onCloseSettings: () => void;
  draftProfileName: string;
  setDraftProfileName: React.Dispatch<React.SetStateAction<string>>;
  onTriggerAvatarUpload: () => void;
  tracks: Track[];
  visibleTracks: Track[];
  lastAddedInterval: string;
  onChangeLastAddedInterval: (val: string) => void;
  duplicatePlaylistPolicy: 'ask' | 'allow' | 'skip';
  onChangeDuplicatePlaylistPolicy: (val: 'ask' | 'allow' | 'skip') => void;
  minDurationFilterSeconds: number;
  onChangeMinDurationFilter: (sec: number) => void;
  minSizeFilterKB: number;
  onChangeMinSizeFilter: (kb: number) => void;
  onAddHiddenFolder: (name: string, path: string) => void;
  onHideTrack: (trackId: string) => void;
  themeConfig: ThemeConfig;
  onUpdateThemeConfig: React.Dispatch<React.SetStateAction<ThemeConfig>>;
  eqState: EqualizerState;
  onUpdateEqState: React.Dispatch<React.SetStateAction<EqualizerState>>;
  onOpenEqualizerTab: () => void;
  onOpenLockscreenPreview: () => void;
  draftCloudEmail: string;
  setDraftCloudEmail: React.Dispatch<React.SetStateAction<string>>;
  setCloudEmail: React.Dispatch<React.SetStateAction<string>>;
  cloudSelection: BackupSelectionState;
  setCloudSelection: React.Dispatch<React.SetStateAction<BackupSelectionState>>;
  localSelection: BackupSelectionState;
  setLocalSelection: React.Dispatch<React.SetStateAction<BackupSelectionState>>;
  showToast: (msg: string) => void;
}

export const SettingsDialogsModal: React.FC<SettingsDialogsModalProps> = ({
  activeDialog,
  setActiveDialog,
  onCloseSettings,
  draftProfileName,
  setDraftProfileName,
  onTriggerAvatarUpload,
  tracks,
  visibleTracks,
  lastAddedInterval,
  onChangeLastAddedInterval,
  duplicatePlaylistPolicy,
  onChangeDuplicatePlaylistPolicy,
  minDurationFilterSeconds,
  onChangeMinDurationFilter,
  minSizeFilterKB,
  onChangeMinSizeFilter,
  onAddHiddenFolder,
  onHideTrack,
  themeConfig,
  onUpdateThemeConfig,
  eqState,
  onUpdateEqState,
  onOpenEqualizerTab,
  onOpenLockscreenPreview,
  draftCloudEmail,
  setDraftCloudEmail,
  setCloudEmail,
  cloudSelection,
  setCloudSelection,
  localSelection,
  setLocalSelection,
  showToast
}) => {
  const {
    userProfileAvatar,
    updateUserProfile,
    navTabsConfig,
    setNavTabsConfig,
    playPauseFadeEnabled,
    playPauseFadeMs,
    updatePlayPauseFade,
    crossfadeEnabled,
    crossfadeSeconds,
    updateCrossfade,
    muzioLockscreenBg,
    setMuzioLockscreenBg,
    systemLockscreenBg,
    setSystemLockscreenBg,
    replayGainMode,
    setReplayGainMode
  } = useSettingsContext();

  const [newFolderName, setNewFolderName] = useState('');
  const [newFolderPath, setNewFolderPath] = useState('/storage/emulated/0/Music/');

  if (!activeDialog) return null;

  return (
    <div
      onClick={() => setActiveDialog(null)}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl p-6 shadow-2xl border border-white/10 flex flex-col gap-4 max-h-[85vh] overflow-y-auto"
        style={{ backgroundColor: '#132838', color: '#f8fafc' }}
      >
        {/* 1. Edit Profile Modal */}
        {activeDialog === 'edit-profile' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Editar Perfil</h3>
            <div className="flex flex-col gap-3">
              <label className="text-xs font-bold text-[#899eb2]">Nombre de usuario</label>
              <input
                type="text"
                value={draftProfileName}
                onChange={e => setDraftProfileName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#061928] border border-white/15 text-sm text-white outline-none"
              />
              <button
                type="button"
                onClick={onTriggerAvatarUpload}
                className="px-4 py-2.5 rounded-xl bg-white/10 text-xs font-extrabold text-white flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                Cambiar foto de avatar
              </button>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveDialog(null)}
                className="px-4 py-2 rounded-xl text-xs font-extrabold text-[#899eb2] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (draftProfileName.trim()) {
                    updateUserProfile(draftProfileName.trim(), userProfileAvatar);
                    showToast('Perfil actualizado');
                  }
                  setActiveDialog(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-extrabold bg-[#1cc8ee] text-slate-950 cursor-pointer"
              >
                Guardar
              </button>
            </div>
          </>
        )}

        {/* 2. Editar pestañas de inicio */}
        {activeDialog === 'edit-tabs' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white">Editar pestañas de inicio</h3>
              <button
                onClick={() => setActiveDialog(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs font-bold text-[#899eb2]">
              Activa, desactiva o cambia el orden de las pestañas de la ventana principal.
            </p>
            <div className="flex flex-col divide-y divide-white/10">
              {navTabsConfig.map((item, idx) => (
                <div
                  key={item.id}
                  className="py-2.5 flex items-center justify-between gap-3"
                >
                  <label className="flex items-center gap-3 cursor-pointer flex-1">
                    <input
                      type="checkbox"
                      checked={item.enabled}
                      onChange={() => {
                        const enabledCount = navTabsConfig.filter(t => t.enabled).length;
                        if (item.enabled && enabledCount <= 1) {
                          showToast('Debe quedar al menos una pestaña activa');
                          return;
                        }
                        setNavTabsConfig(
                          navTabsConfig.map((t, i) =>
                            i === idx ? { ...t, enabled: !t.enabled } : t
                          )
                        );
                      }}
                      className="w-4 h-4 accent-[#1cc8ee]"
                    />
                    <span className="text-sm font-extrabold text-white">{item.label}</span>
                  </label>
                  <div className="flex items-center gap-1">
                    <button
                      disabled={idx === 0}
                      onClick={() => {
                        const copy = [...navTabsConfig];
                        const [moved] = copy.splice(idx, 1);
                        copy.splice(idx - 1, 0, moved);
                        setNavTabsConfig(copy);
                      }}
                      className="p-1.5 rounded-lg text-slate-300 disabled:opacity-30 hover:bg-white/10 cursor-pointer"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button
                      disabled={idx === navTabsConfig.length - 1}
                      onClick={() => {
                        const copy = [...navTabsConfig];
                        const [moved] = copy.splice(idx, 1);
                        copy.splice(idx + 1, 0, moved);
                        setNavTabsConfig(copy);
                      }}
                      className="p-1.5 rounded-lg text-slate-300 disabled:opacity-30 hover:bg-white/10 cursor-pointer"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={() => setActiveDialog(null)}
              className="mt-2 py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Listo
            </button>
          </>
        )}

        {/* 3. Último intervalo agregado de lista */}
        {activeDialog === 'last-added-interval' && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              Último intervalo agregado de lista
            </h3>
            <div className="flex flex-col gap-1">
              {['Por siempre', 'Última semana', 'Último mes', 'Últimos 3 meses', 'Último año'].map(
                option => (
                  <button
                    key={option}
                    onClick={() => {
                      onChangeLastAddedInterval(option);
                      setActiveDialog(null);
                      showToast(`Intervalo actualizado: ${option}`);
                    }}
                    className="flex items-center justify-between py-3 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
                  >
                    <span className="text-sm font-extrabold text-white">{option}</span>
                    {lastAddedInterval === option && (
                      <Check className="w-5 h-5 text-[#1cc8ee]" />
                    )}
                  </button>
                )
              )}
            </div>
          </>
        )}

        {/* 4. Canción duplicada en la lista */}
        {activeDialog === 'duplicate-policy' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Canción duplicada en la lista</h3>
            <div className="flex flex-col gap-1">
              {(
                [
                  { id: 'ask', label: 'Preguntar siempre' },
                  { id: 'skip', label: 'Omitir duplicados' },
                  { id: 'allow', label: 'Permitir siempre' }
                ] as const
              ).map(opt => (
                <button
                  key={opt.id}
                  onClick={() => {
                    onChangeDuplicatePlaylistPolicy(opt.id);
                    setActiveDialog(null);
                    showToast(`Política de duplicados: ${opt.label}`);
                  }}
                  className="flex items-center justify-between py-3 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
                >
                  <span className="text-sm font-extrabold text-white">{opt.label}</span>
                  {duplicatePlaylistPolicy === opt.id && (
                    <Check className="w-5 h-5 text-[#1cc8ee]" />
                  )}
                </button>
              ))}
            </div>
          </>
        )}

        {/* 5. ¿Guardar etiquetas en archivos? */}
        {activeDialog === 'save-tags-to-files' && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              ¿Guardar etiquetas en archivos?
            </h3>
            <p className="text-sm font-bold text-[#899eb2] leading-relaxed">
              Se sincronizarán y exportarán las etiquetas ID3 editadas (título, artista, álbum,
              género, letra y carátula) de tus {tracks.length} canción(es).
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveDialog(null)}
                className="px-4 py-2 rounded-xl text-xs font-extrabold text-[#899eb2] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  localStorage.setItem('mad_player_saved_tags_v1', JSON.stringify(tracks));
                  showToast('Etiquetas guardadas y sincronizadas con los archivos');
                  setActiveDialog(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-extrabold bg-[#1cc8ee] text-slate-950 cursor-pointer"
              >
                Guardar ahora
              </button>
            </div>
          </>
        )}

        {/* 6. Tema del reproductor */}
        {activeDialog === 'player-theme' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Tema del reproductor</h3>
            <div className="flex flex-col gap-2.5">
              {(
                [
                  {
                    id: 'muzio-classic',
                    title: 'Mad Player Borde a Borde (Original)',
                    desc: 'Portada cuadrada con gestos ±10s, swipe lateral y fondo pastel adaptativo.'
                  },
                  {
                    id: 'studio-console',
                    title: 'Consola Studio con Visualizador FFT',
                    desc: 'Vinilo/carátula con analizador de espectro en tiempo real y bucle A-B.'
                  }
                ] as { id: PlayerSkin; title: string; desc: string }[]
              ).map(skin => (
                <button
                  key={skin.id}
                  onClick={() => {
                    onUpdateThemeConfig(prev => ({ ...prev, playerSkin: skin.id }));
                    showToast(`Tema del reproductor: ${skin.title}`);
                    setActiveDialog(null);
                  }}
                  className={`p-3.5 rounded-xl border text-left flex flex-col gap-1 cursor-pointer ${
                    themeConfig.playerSkin === skin.id
                      ? 'border-[#1cc8ee] bg-[#1cc8ee]/10'
                      : 'border-white/10 bg-[#061928]'
                  }`}
                >
                  <span className="text-sm font-extrabold text-white">{skin.title}</span>
                  <span className="text-xs font-bold text-[#899eb2]">{skin.desc}</span>
                </button>
              ))}
            </div>

            <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee] pt-2">
              Paleta de color de la app
            </span>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { id: 'nordic-slate', name: 'Mad Navy', color: '#1cc8ee' },
                  { id: 'dynamic-cover', name: 'Camaleón', color: '#38bdf8' },
                  { id: 'obsidian-studio', name: 'Obsidiana', color: '#f59e0b' },
                  { id: 'velvet-crimson', name: 'Terciopelo', color: '#f43f5e' }
                ] as { id: ThemeBaseId; name: string; color: string }[]
              ).map(p => (
                <button
                  key={p.id}
                  onClick={() => {
                    onUpdateThemeConfig(prev => ({
                      ...prev,
                      baseId: p.id,
                      adaptToCoverArt: p.id === 'dynamic-cover'
                    }));
                    showToast(`Paleta: ${p.name}`);
                  }}
                  className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer ${
                    themeConfig.baseId === p.id
                      ? 'border-[#1cc8ee] bg-[#1cc8ee]/10'
                      : 'border-white/10 bg-[#061928]'
                  }`}
                >
                  <span
                    className="w-4 h-4 rounded-full shrink-0"
                    style={{ backgroundColor: p.color }}
                  />
                  <span className="text-xs font-extrabold text-white truncate">{p.name}</span>
                </button>
              ))}
            </div>
          </>
        )}

        {/* 7. Equalizador predeterminado */}
        {activeDialog === 'default-eq' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Equalizador predeterminado</h3>
            <div className="flex flex-col gap-1">
              {Object.entries(EQ_PRESETS).map(([name, gains]) => {
                const displayLabel =
                  name === 'Plana (Studio)' ? 'Mad Player (Predeterminado)' : name;
                return (
                  <button
                    key={name}
                    onClick={() => {
                      onUpdateEqState(prev => ({
                        ...prev,
                        enabled: true,
                        presetName: name,
                        bands: prev.bands.map((b, i) => ({ ...b, gain: gains[i] }))
                      }));
                      showToast(`Ecualizador predeterminado: ${displayLabel}`);
                      setActiveDialog(null);
                    }}
                    className="flex items-center justify-between py-2.5 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
                  >
                    <span className="text-sm font-extrabold text-white">{displayLabel}</span>
                    {eqState.presetName === name && (
                      <Check className="w-5 h-5 text-[#1cc8ee]" />
                    )}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => {
                setActiveDialog(null);
                onCloseSettings();
                onOpenEqualizerTab();
              }}
              className="mt-1 py-2.5 rounded-xl bg-white/10 text-xs font-extrabold text-[#1cc8ee] cursor-pointer"
            >
              Abrir Ecualizador de 5 Bandas
            </button>
          </>
        )}

        {/* 8. Reproducir/Pausar Desvanecimiento */}
        {activeDialog === 'play-pause-fade' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-white">
                Reproducir/Pausar Desvanecimiento
              </h3>
              <SettingsToggle
                checked={playPauseFadeEnabled}
                onChange={() => updatePlayPauseFade(!playPauseFadeEnabled, playPauseFadeMs)}
              />
            </div>
            <p className="text-sm font-extrabold text-[#1cc8ee]">
              {playPauseFadeEnabled ? `${playPauseFadeMs} milisegundos` : 'Apagado'}
            </p>
            <input
              type="range"
              min={100}
              max={1500}
              step={5}
              value={playPauseFadeMs}
              onChange={e => updatePlayPauseFade(true, Number(e.target.value))}
              className="w-full accent-[#1cc8ee] cursor-pointer"
            />
            <div className="flex justify-between text-xs font-bold text-[#899eb2]">
              <span>100 ms</span>
              <span>505 ms</span>
              <span>1500 ms</span>
            </div>
            <button
              onClick={() => setActiveDialog(null)}
              className="mt-2 py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Aceptar
            </button>
          </>
        )}

        {/* 9. Desvanecer (Crossfade) */}
        {activeDialog === 'crossfade' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-white">Desvanecer entre canciones</h3>
              <SettingsToggle
                checked={crossfadeEnabled}
                onChange={() => updateCrossfade(!crossfadeEnabled, crossfadeSeconds)}
              />
            </div>
            <p className="text-sm font-extrabold text-[#1cc8ee]">
              {crossfadeEnabled ? `${crossfadeSeconds} segundos` : 'apagado'}
            </p>
            <input
              type="range"
              min={1}
              max={12}
              step={1}
              value={crossfadeSeconds}
              onChange={e => updateCrossfade(true, Number(e.target.value))}
              className="w-full accent-[#1cc8ee] cursor-pointer"
            />
            <div className="flex justify-between text-xs font-bold text-[#899eb2]">
              <span>1 s</span>
              <span>6 s</span>
              <span>12 s</span>
            </div>
            <button
              onClick={() => setActiveDialog(null)}
              className="mt-2 py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Aceptar
            </button>
          </>
        )}

        {/* 10. ¿La música deja de sonar? */}
        {activeDialog === 'background-play-help' && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              Reproducción de fondo ininterrumpida
            </h3>
            <p className="text-sm font-bold text-[#899eb2] leading-relaxed">
              Mad Player mantiene activa la sesión de audio Web Audio a 48 kHz y sincroniza los
              controles con la pantalla de bloqueo del sistema para evitar interrupciones.
            </p>
            <button
              onClick={() => {
                showToast('Protección de audio en segundo plano activada');
                setActiveDialog(null);
              }}
              className="py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Activar optimización de fondo
            </button>
          </>
        )}

        {/* 11. Mad Player Lockscreen Background */}
        {activeDialog === 'muzio-lockscreen-bg' && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              Lockscreen background (Mad Player)
            </h3>
            {['Diseño', 'Portada del álbum', 'Portada desenfocada', 'Color sólido'].map(opt => (
              <button
                key={opt}
                onClick={() => {
                  setMuzioLockscreenBg(opt);
                  setActiveDialog(null);
                  showToast(`Fondo de bloqueo Mad Player: ${opt}`);
                }}
                className="flex items-center justify-between py-2.5 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
              >
                <span className="text-sm font-extrabold text-white">{opt}</span>
                {muzioLockscreenBg === opt && <Check className="w-5 h-5 text-[#1cc8ee]" />}
              </button>
            ))}
            <button
              onClick={() => {
                setActiveDialog(null);
                onCloseSettings();
                onOpenLockscreenPreview();
              }}
              className="mt-1 py-2.5 rounded-xl bg-white/10 text-xs font-extrabold text-[#1cc8ee] flex items-center justify-center gap-2 cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              Probar reproductor de pantalla de bloqueo
            </button>
          </>
        )}

        {/* 12. System Lockscreen Background */}
        {activeDialog === 'system-lockscreen-bg' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Lockscreen background</h3>
            {['Portada del álbum', 'Portada desenfocada', 'Ninguna'].map(opt => (
              <button
                key={opt}
                onClick={() => {
                  setSystemLockscreenBg(opt);
                  setActiveDialog(null);
                  showToast(`Fondo de pantalla de bloqueo: ${opt}`);
                }}
                className="flex items-center justify-between py-2.5 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
              >
                <span className="text-sm font-extrabold text-white">{opt}</span>
                {systemLockscreenBg === opt && <Check className="w-5 h-5 text-[#1cc8ee]" />}
              </button>
            ))}
          </>
        )}

        {/* 13. ReplayGain Source Mode */}
        {activeDialog === 'replaygain' && (
          <>
            <h3 className="text-lg font-extrabold text-white">ReplayGain — Source mode</h3>
            {['Ninguna', 'Pista (Track)', 'Álbum', 'Normalización inteligente'].map(opt => (
              <button
                key={opt}
                onClick={() => {
                  setReplayGainMode(opt);
                  setActiveDialog(null);
                  showToast(`ReplayGain: ${opt}`);
                }}
                className="flex items-center justify-between py-2.5 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
              >
                <span className="text-sm font-extrabold text-white">{opt}</span>
                {replayGainMode === opt && <Check className="w-5 h-5 text-[#1cc8ee]" />}
              </button>
            ))}
          </>
        )}

        {/* 14. Hidden Files: Song duration less than */}
        {activeDialog === 'filter-duration' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Song duration less than</h3>
            <div className="flex flex-col gap-1">
              {[0, 5, 10, 15, 30, 60].map(sec => (
                <button
                  key={sec}
                  onClick={() => {
                    onChangeMinDurationFilter(sec);
                    setActiveDialog(null);
                    showToast(`Ocultando canciones menores a ${sec} segundos`);
                  }}
                  className="flex items-center justify-between py-2.5 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
                >
                  <span className="text-sm font-extrabold text-white">{sec} segundos</span>
                  {minDurationFilterSeconds === sec && (
                    <Check className="w-5 h-5 text-[#1cc8ee]" />
                  )}
                </button>
              ))}
            </div>
          </>
        )}

        {/* 15. Hidden Files: Song size less than */}
        {activeDialog === 'filter-size' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Song size less than</h3>
            <div className="flex flex-col gap-1">
              {[0, 5, 25, 50, 100, 500].map(kb => (
                <button
                  key={kb}
                  onClick={() => {
                    onChangeMinSizeFilter(kb);
                    setActiveDialog(null);
                    showToast(`Ocultando archivos menores a ${kb} KB`);
                  }}
                  className="flex items-center justify-between py-2.5 px-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
                >
                  <span className="text-sm font-extrabold text-white">{kb} KB</span>
                  {minSizeFilterKB === kb && <Check className="w-5 h-5 text-[#1cc8ee]" />}
                </button>
              ))}
            </div>
          </>
        )}

        {/* 16. Hidden Files: Add Hidden Folder (+) */}
        {activeDialog === 'add-hidden-folder' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Ocultar carpeta</h3>
            <div className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-bold text-[#899eb2]">Nombre de carpeta</label>
                <input
                  type="text"
                  placeholder="Ej. WhatsApp Audio"
                  value={newFolderName}
                  onChange={e => {
                    setNewFolderName(e.target.value);
                    setNewFolderPath(`/storage/emulated/0/${e.target.value}`);
                  }}
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-[#061928] border border-white/15 text-sm text-white outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-[#899eb2]">Ruta del directorio</label>
                <input
                  type="text"
                  value={newFolderPath}
                  onChange={e => setNewFolderPath(e.target.value)}
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-[#061928] border border-white/15 text-sm text-white outline-none"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveDialog(null)}
                className="px-4 py-2 rounded-xl text-xs font-extrabold text-[#899eb2] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (newFolderName.trim()) {
                    onAddHiddenFolder(newFolderName.trim(), newFolderPath.trim());
                    setNewFolderName('');
                    setActiveDialog(null);
                  }
                }}
                className="px-4 py-2 rounded-xl text-xs font-extrabold bg-[#1cc8ee] text-slate-950 cursor-pointer"
              >
                Ocultar carpeta
              </button>
            </div>
          </>
        )}

        {/* 17. Hidden Files: Add Hidden Song (+) */}
        {activeDialog === 'add-hidden-song' && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              Seleccionar canción para ocultar
            </h3>
            {visibleTracks.length === 0 ? (
              <p className="text-xs font-bold text-[#899eb2]">
                Todas las canciones ya están ocultas.
              </p>
            ) : (
              <div className="flex flex-col gap-2 max-h-64 overflow-y-auto">
                {visibleTracks.map(t => (
                  <button
                    key={t.id}
                    onClick={() => {
                      onHideTrack(t.id);
                      setActiveDialog(null);
                    }}
                    className="flex items-center justify-between gap-3 p-2 rounded-xl hover:bg-white/10 text-left cursor-pointer"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-extrabold text-white truncate">{t.title}</p>
                      <p className="text-xs font-bold text-[#899eb2] truncate">
                        {t.artist} • {formatDuration(t.duration)}
                      </p>
                    </div>
                    <PlusCircle className="w-5 h-5 text-[#1cc8ee] shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {/* 18. Cloud Email Account */}
        {activeDialog === 'cloud-email' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Cuenta de copia en la nube</h3>
            <input
              type="email"
              value={draftCloudEmail}
              onChange={e => setDraftCloudEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#061928] border border-white/15 text-sm text-white outline-none"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveDialog(null)}
                className="px-4 py-2 rounded-xl text-xs font-extrabold text-[#899eb2] cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (draftCloudEmail.trim()) {
                    setCloudEmail(draftCloudEmail.trim());
                    saveCloudEmailToDb(draftCloudEmail.trim());
                    showToast(`Cuenta vinculada: ${draftCloudEmail.trim()}`);
                  }
                  setActiveDialog(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-extrabold bg-[#1cc8ee] text-slate-950 cursor-pointer"
              >
                Guardar
              </button>
            </div>
          </>
        )}

        {/* 19. Cloud / Local Backup Items Checklist */}
        {(activeDialog === 'cloud-backup-items' || activeDialog === 'local-backup-items') && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              Seleccione elementos para respaldar o restaurar
            </h3>
            <div className="flex flex-col gap-2.5">
              {(
                [
                  { key: 'covers', label: 'Audio: Carátulas' },
                  { key: 'tags', label: 'Audio: Etiquetas ID3' },
                  { key: 'lyrics', label: 'Audio: Letra sincronizada' },
                  { key: 'playlists', label: 'Audio: Lista de Reproducción' },
                  { key: 'hiddenFiles', label: 'Audio: Hidden Files' }
                ] as { key: keyof BackupSelectionState; label: string }[]
              ).map(item => {
                const isCloud = activeDialog === 'cloud-backup-items';
                const currentSel = isCloud ? cloudSelection : localSelection;
                return (
                  <label
                    key={item.key}
                    className="flex items-center justify-between py-2 px-2 rounded-xl hover:bg-white/5 cursor-pointer"
                  >
                    <span className="text-sm font-extrabold text-white">{item.label}</span>
                    <input
                      type="checkbox"
                      checked={currentSel[item.key]}
                      onChange={() => {
                        if (isCloud) {
                          setCloudSelection(prev => ({
                            ...prev,
                            [item.key]: !prev[item.key]
                          }));
                        } else {
                          setLocalSelection(prev => ({
                            ...prev,
                            [item.key]: !prev[item.key]
                          }));
                        }
                      }}
                      className="w-4 h-4 accent-[#1cc8ee]"
                    />
                  </label>
                );
              })}
            </div>
            <button
              onClick={() => setActiveDialog(null)}
              className="mt-2 py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Confirmar selección
            </button>
          </>
        )}

        {/* 20. About Dialogs */}
        {activeDialog === 'about-intro' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Introducción</h3>
            <p className="text-sm font-bold text-[#899eb2] leading-relaxed">
              Mad Player es un reproductor de audio móvil de alta fidelidad con motor
              Web Audio a 48 kHz, cambio independiente de velocidad y tono en tiempo real,
              reconocimiento de portadas incrustadas ID3/M4A/FLAC, temas dinámicos camaleón y
              gestión avanzada de listas.
            </p>
            <button
              onClick={() => setActiveDialog(null)}
              className="py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Cerrar
            </button>
          </>
        )}

        {activeDialog === 'about-changelog' && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              Registro de cambios — v7.8.5
            </h3>
            <ul className="text-xs font-bold text-[#899eb2] flex flex-col gap-2 list-disc pl-4">
              <li>Pestañas separadas Sugirió y Canciones con acceso rápido.</li>
              <li>
                Controles de Velocidad (1.0x) y Tono (1.0) alineados con procesamiento granular
                a 48 kHz en tiempo real.
              </li>
              <li>
                Gestos en portada: deslizar a los costados (anterior/siguiente), doble toque
                lateral (±10s) y doble toque inferior con animación de corazón para Favoritos.
              </li>
              <li>
                Nuevos apartados completos de Perfil y Estadísticas, Audio, Hidden Files,
                Respaldar (Nube y Local) y Acerca de.
              </li>
            </ul>
            <button
              onClick={() => setActiveDialog(null)}
              className="py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Cerrar
            </button>
          </>
        )}

        {activeDialog === 'about-faq' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Preguntas frecuentes</h3>
            <div className="flex flex-col gap-3 text-xs font-bold text-[#899eb2]">
              <div>
                <p className="text-white font-extrabold">
                  ¿Cómo reconoce la portada de mis canciones?
                </p>
                <p>
                  Al importar un archivo MP3, M4A o FLAC, el lector binario extrae la imagen
                  APIC/covr incrustada automáticamente.
                </p>
              </div>
              <div>
                <p className="text-white font-extrabold">
                  ¿Cómo funcionan los gestos en el reproductor?
                </p>
                <p>
                  Desliza la portada a izquierda/derecha para cambiar de pista, toca dos veces a
                  los lados para avanzar o retroceder 10s, y toca dos veces debajo de la portada
                  para marcar Favorito.
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveDialog(null)}
              className="py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Entendido
            </button>
          </>
        )}

        {activeDialog === 'about-translate' && (
          <>
            <h3 className="text-lg font-extrabold text-white">Traducir aplicación</h3>
            <p className="text-sm font-bold text-[#899eb2]">
              Idioma activo: Español (Latinoamérica / España) — 100% completado.
            </p>
            <button
              onClick={() => {
                showToast('¡Gracias por tu interés en colaborar con las traducciones!');
                setActiveDialog(null);
              }}
              className="py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Unirse al equipo de traducción
            </button>
          </>
        )}

        {(activeDialog === 'about-web' ||
          activeDialog === 'about-privacy' ||
          activeDialog === 'about-licenses') && (
          <>
            <h3 className="text-lg font-extrabold text-white">
              {activeDialog === 'about-web'
                ? 'Sitio Web Oficial'
                : activeDialog === 'about-privacy'
                  ? 'Política de Privacidad'
                  : 'Licencias de Código Abierto'}
            </h3>
            <p className="text-xs font-bold text-[#899eb2] leading-relaxed">
              {activeDialog === 'about-web' &&
                'Mad Player — Reproductor de audio móvil con procesamiento local Web Audio API.'}
              {activeDialog === 'about-privacy' &&
                'Toda tu biblioteca musical, portadas, etiquetas ID3 y copias de seguridad locales se procesan directamente en tu dispositivo sin subir tus audios a servidores externos.'}
              {activeDialog === 'about-licenses' &&
                'Desarrollado con React 19, TypeScript, Tailwind CSS, Lucide Icons y Web Audio API (Apache 2.0 / MIT).'}
            </p>
            <button
              onClick={() => setActiveDialog(null)}
              className="py-2.5 rounded-xl bg-[#1cc8ee] text-slate-950 text-xs font-extrabold cursor-pointer"
            >
              Cerrar
            </button>
          </>
        )}
      </div>
    </div>
  );
};
