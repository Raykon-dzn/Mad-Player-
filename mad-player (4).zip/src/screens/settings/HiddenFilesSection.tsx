import React, { useState } from 'react';
import {
  ArrowLeft,
  ChevronRight,
  Folder,
  MinusCircle,
  Music2,
  PlusCircle,
  Radar,
  Search
} from 'lucide-react';
import { Track } from '../../types/music';
import { HiddenFolderItem, SettingsDialogType } from '../../hooks/useSettings';
import { formatDuration } from './SettingsToggle';

interface HiddenFilesSectionProps {
  onGoBack: () => void;
  setActiveDialog: React.Dispatch<React.SetStateAction<SettingsDialogType>>;
  hiddenFolders: HiddenFolderItem[];
  onRemoveHiddenFolder: (id: string) => void;
  hiddenTracks: Track[];
  onRestoreHiddenTrack: (trackId: string) => void;
  minDurationFilterSeconds: number;
  minSizeFilterKB: number;
  showToast: (msg: string) => void;
}

export const HiddenFilesSection: React.FC<HiddenFilesSectionProps> = ({
  onGoBack,
  setActiveDialog,
  hiddenFolders,
  onRemoveHiddenFolder,
  hiddenTracks,
  onRestoreHiddenTrack,
  minDurationFilterSeconds,
  minSizeFilterKB,
  showToast
}) => {
  const [showHiddenSearch, setShowHiddenSearch] = useState(false);
  const [hiddenSearchQuery, setHiddenSearchQuery] = useState('');

  const filteredHiddenFolders = hiddenFolders.filter(f => {
    if (!hiddenSearchQuery.trim()) return true;
    const q = hiddenSearchQuery.toLowerCase();
    return f.name.toLowerCase().includes(q) || f.path.toLowerCase().includes(q);
  });

  const filteredHiddenTracks = hiddenTracks.filter(t => {
    if (!hiddenSearchQuery.trim()) return true;
    const q = hiddenSearchQuery.toLowerCase();
    return t.title.toLowerCase().includes(q) || t.artist.toLowerCase().includes(q);
  });

  return (
    <>
      <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-4 bg-[#061928]/95 backdrop-blur-md">
        <div className="flex items-center gap-5">
          <button
            onClick={onGoBack}
            aria-label="Volver"
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-extrabold font-display tracking-tight text-white">
            Hidden Files
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowHiddenSearch(prev => !prev)}
            aria-label="Buscar en archivos ocultos"
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#7c93a8] hover:text-white hover:bg-white/10 cursor-pointer"
          >
            <Search className="w-5 h-5" />
          </button>
          <button
            onClick={() => {
              showToast(
                `Filtro aplicado: ocultando audios < ${minDurationFilterSeconds}s o < ${minSizeFilterKB} KB`
              );
            }}
            aria-label="Escanear filtros"
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#7c93a8] hover:text-white hover:bg-white/10 cursor-pointer"
          >
            <Radar className="w-5 h-5" />
          </button>
        </div>
      </div>

      {showHiddenSearch && (
        <div className="max-w-xl w-full mx-auto px-4 pb-3">
          <input
            type="text"
            autoFocus
            value={hiddenSearchQuery}
            onChange={e => setHiddenSearchQuery(e.target.value)}
            placeholder="Filtrar carpetas o canciones ocultas..."
            className="w-full px-3.5 py-2.5 rounded-xl bg-[#132838] text-sm text-white border border-white/10 outline-none"
          />
        </div>
      )}

      <div className="max-w-xl w-full mx-auto px-4 pb-16 flex flex-col gap-7">
        {/* FILTERS SECTION */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#6e8499]">
            FILTERS
          </span>

          <button
            onClick={() => setActiveDialog('filter-duration')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Song duration less than</span>
            <div className="flex items-center gap-1.5 text-base font-extrabold text-[#6e8499] shrink-0">
              <span>{minDurationFilterSeconds} segundos</span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          <button
            onClick={() => setActiveDialog('filter-size')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Song size less than</span>
            <div className="flex items-center gap-1.5 text-base font-extrabold text-[#6e8499] shrink-0">
              <span>{minSizeFilterKB} KB</span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>
        </div>

        {/* CARPETAS (N) SECTION */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#6e8499]">
              CARPETAS ({filteredHiddenFolders.length})
            </span>
            <button
              onClick={() => setActiveDialog('add-hidden-folder')}
              aria-label="Ocultar carpeta"
              className="text-[#7c93a8] hover:text-white cursor-pointer"
            >
              <PlusCircle className="w-6 h-6" />
            </button>
          </div>

          <div className="flex flex-col gap-4">
            {filteredHiddenFolders.map(folder => (
              <div
                key={folder.id}
                className="flex items-center justify-between gap-3.5"
              >
                <div className="flex items-center gap-4 min-w-0 flex-1">
                  <div className="w-13 h-13 rounded-full bg-[#243746] border border-white/10 flex items-center justify-center shrink-0">
                    <Folder className="w-6 h-6 text-[#7c93a8] fill-[#7c93a8]" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-base font-extrabold text-white truncate">
                      {folder.name}
                    </p>
                    <p className="text-xs font-extrabold text-[#6e8499] truncate mt-0.5">
                      {folder.path}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onRemoveHiddenFolder(folder.id)}
                  aria-label={`Restaurar carpeta ${folder.name}`}
                  className="text-[#7c93a8] hover:text-rose-400 p-1 shrink-0 cursor-pointer"
                >
                  <MinusCircle className="w-6 h-6" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* CANCIONES (N) SECTION */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#6e8499]">
              CANCIONES ({filteredHiddenTracks.length})
            </span>
            <button
              onClick={() => setActiveDialog('add-hidden-song')}
              aria-label="Ocultar canción"
              className="text-[#7c93a8] hover:text-white cursor-pointer"
            >
              <PlusCircle className="w-6 h-6" />
            </button>
          </div>

          {filteredHiddenTracks.length === 0 ? (
            <p className="text-xs font-bold text-[#6e8499] py-2">
              No hay canciones ocultas. Pulsa + para ocultar una canción de la biblioteca.
            </p>
          ) : (
            <div className="flex flex-col gap-3.5">
              {filteredHiddenTracks.map(track => (
                <div
                  key={`hid-${track.id}`}
                  className="flex items-center justify-between gap-3.5"
                >
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div className="w-13 h-13 rounded-xl overflow-hidden bg-[#3b4d5e] shrink-0 flex items-center justify-center">
                      {track.coverUrl ? (
                        <img
                          src={track.coverUrl}
                          alt={track.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Music2 className="w-6 h-6 text-[#132230]" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-base font-extrabold text-white truncate">
                        {track.title}
                      </p>
                      <p className="text-xs font-extrabold text-[#6e8499] truncate mt-0.5">
                        {track.artist} • {formatDuration(track.duration)}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => onRestoreHiddenTrack(track.id)}
                    aria-label={`Restaurar canción ${track.title}`}
                    className="text-[#7c93a8] hover:text-emerald-400 p-1 shrink-0 cursor-pointer"
                  >
                    <MinusCircle className="w-6 h-6" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
};
