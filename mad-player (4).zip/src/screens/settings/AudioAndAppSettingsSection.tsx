import React from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';
import { EqualizerState, ThemeConfig } from '../../types/music';
import {
  SettingsDialogType,
  SettingsSubPage,
  useSettingsContext
} from '../../hooks/useSettings';
import { SettingsToggle } from './SettingsToggle';

interface AudioAndAppSettingsSectionProps {
  subPage: 'audio' | 'app';
  onGoBack: () => void;
  navigateToSubPage: (nextPage: SettingsSubPage) => void;
  setActiveDialog: React.Dispatch<React.SetStateAction<SettingsDialogType>>;
  themeConfig: ThemeConfig;
  onUpdateThemeConfig: React.Dispatch<React.SetStateAction<ThemeConfig>>;
  eqState: EqualizerState;
  lastAddedInterval: string;
  duplicatePlaylistPolicy: 'ask' | 'allow' | 'skip';
  onToggleAlwaysShuffle: () => void;
}

export const AudioAndAppSettingsSection: React.FC<AudioAndAppSettingsSectionProps> = ({
  subPage,
  onGoBack,
  navigateToSubPage,
  setActiveDialog,
  themeConfig,
  onUpdateThemeConfig,
  eqState,
  lastAddedInterval,
  duplicatePlaylistPolicy,
  onToggleAlwaysShuffle
}) => {
  const {
    hdCoverEnabled,
    toggleHdCover,
    syncDeviceTags,
    toggleSyncDeviceTags,
    updateDeviceTags,
    toggleUpdateDeviceTags,
    openPlayerOnPlay,
    toggleOpenPlayerOnPlay,
    volumeGestureEnabled,
    toggleVolumeGesture,
    mediaSessionEnabled,
    toggleMediaSession,
    playPauseFadeEnabled,
    playPauseFadeMs,
    crossfadeEnabled,
    crossfadeSeconds,
    gaplessEnabled,
    toggleGapless,
    shakeToSkipEnabled,
    toggleShakeToSkip,
    alwaysShuffleEnabled,
    parallelPlayEnabled,
    toggleParallelPlay,
    lockscreenPlayerEnabled,
    toggleLockscreenPlayer,
    use24HourFormat,
    toggle24HourFormat,
    muzioLockscreenBg,
    systemLockscreenBg,
    replayGainMode
  } = useSettingsContext();

  const duplicatePolicyLabel =
    duplicatePlaylistPolicy === 'ask'
      ? 'Preguntar siempre'
      : duplicatePlaylistPolicy === 'skip'
        ? 'Omitir duplicados'
        : 'Permitir siempre';

  return (
    <>
      <div className="sticky top-0 z-20 flex items-center gap-5 px-4 py-4 bg-[#061928]/95 backdrop-blur-md">
        <button
          onClick={onGoBack}
          aria-label="Volver"
          className="w-10 h-10 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-extrabold font-display tracking-tight text-white">
          {subPage === 'app' ? 'App' : 'Audio'}
        </h1>
      </div>

      <div className="max-w-xl w-full mx-auto px-4 pb-16 flex flex-col gap-7">
        {/* SECTION 0: GENERAL -> TEMA */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            GENERAL
          </span>

          <button
            onClick={() => navigateToSubPage('elegir-tema')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">Tema</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Elegir tema, imagen con alpha/blur, colores, degradado y color énfasis
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>
        </div>

        {/* SECTION 1: PANTALLA */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            PANTALLA
          </span>

          <button
            onClick={() => setActiveDialog('edit-tabs')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">Editar pestañas de inicio</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Seleccionar y organizar pestañas de inicio
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>

          <button
            onClick={() => setActiveDialog('last-added-interval')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">
                Último intervalo agregado de lista
              </p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">{lastAddedInterval}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>

          <button
            onClick={() => setActiveDialog('duplicate-policy')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">
                Canción duplicada en la lista
              </p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">{duplicatePolicyLabel}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>

          <div
            onClick={toggleHdCover}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">Carátula HD</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Podría ralentizar la aplicación
              </p>
            </div>
            <SettingsToggle checked={hdCoverEnabled} onChange={toggleHdCover} />
          </div>

          <div
            onClick={toggleSyncDeviceTags}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">
                Sincronizar etiquetas de dispositivo
              </p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Sustituye las etiquetas editadas en Mad Player
              </p>
            </div>
            <SettingsToggle checked={syncDeviceTags} onChange={toggleSyncDeviceTags} />
          </div>

          <div
            onClick={toggleUpdateDeviceTags}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">
                Actualizar etiqueta de dispositivo
              </p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Necesita permiso de actualización de canción en edición de etiquetas
              </p>
            </div>
            <SettingsToggle checked={updateDeviceTags} onChange={toggleUpdateDeviceTags} />
          </div>

          <button
            onClick={() => setActiveDialog('save-tags-to-files')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">
                ¿Guardar etiquetas en archivos?
              </p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Guardar etiquetas editadas anteriormente en archivos
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>
        </div>

        {/* SECTION 2: JUGADOR */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            JUGADOR
          </span>

          <button
            onClick={() => navigateToSubPage('player-skins')}
            className="flex items-center justify-between gap-4 py-2 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Tema del reproductor</span>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>

          <div
            onClick={toggleOpenPlayerOnPlay}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Abrir jugador en juego</span>
            <SettingsToggle checked={openPlayerOnPlay} onChange={toggleOpenPlayerOnPlay} />
          </div>

          <div
            onClick={() =>
              onUpdateThemeConfig(prev => ({
                ...prev,
                adaptToCoverArt: !prev.adaptToCoverArt
              }))
            }
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">Icono adaptativo</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Color del icono basado en la imagen del álbum
              </p>
            </div>
            <SettingsToggle
              checked={themeConfig.adaptToCoverArt}
              onChange={() =>
                onUpdateThemeConfig(prev => ({
                  ...prev,
                  adaptToCoverArt: !prev.adaptToCoverArt
                }))
              }
            />
          </div>

          <div
            onClick={toggleVolumeGesture}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">
              Enable player volume gesture
            </span>
            <SettingsToggle checked={volumeGestureEnabled} onChange={toggleVolumeGesture} />
          </div>

          <div
            onClick={toggleMediaSession}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">
                Controles en notificación y Bluetooth
              </p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Integrar carátula y botones en barra de sistema / auriculares
              </p>
            </div>
            <SettingsToggle checked={mediaSessionEnabled} onChange={toggleMediaSession} />
          </div>
        </div>

        {/* SECTION 3: REPRODUCCIÓN */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            REPRODUCCIÓN
          </span>

          <button
            onClick={() => setActiveDialog('default-eq')}
            className="flex items-center justify-between gap-4 py-2 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">
              Equalizador predeterminado
            </span>
            <div className="flex items-center gap-1.5 text-sm font-extrabold text-[#6e8499] shrink-0">
              <span>
                {eqState.presetName === 'Plana (Studio)' ? 'Mad Player' : eqState.presetName}
              </span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          <button
            onClick={() => setActiveDialog('play-pause-fade')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white leading-snug">
              Reproducir/Pausar
              <br />
              Desvanecimiento
            </span>
            <div className="flex items-center gap-1.5 text-sm font-extrabold text-[#6e8499] shrink-0">
              <span>
                {playPauseFadeEnabled ? `${playPauseFadeMs} milisegundos` : 'apagado'}
              </span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          <button
            onClick={() => setActiveDialog('crossfade')}
            className="flex items-center justify-between gap-4 py-2 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Desvanecer</span>
            <div className="flex items-center gap-1.5 text-sm font-extrabold text-[#6e8499] shrink-0">
              <span>{crossfadeEnabled ? `${crossfadeSeconds} segundos` : 'apagado'}</span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          <div
            onClick={toggleGapless}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Reproducción sin pausas</span>
            <SettingsToggle checked={gaplessEnabled} onChange={toggleGapless} />
          </div>

          <div
            onClick={toggleShakeToSkip}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">
              Agitar para cambiar de canción
            </span>
            <SettingsToggle checked={shakeToSkipEnabled} onChange={toggleShakeToSkip} />
          </div>

          <div
            onClick={onToggleAlwaysShuffle}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">
              Activar siempre el aleatorio
            </span>
            <SettingsToggle checked={alwaysShuffleEnabled} onChange={onToggleAlwaysShuffle} />
          </div>

          <div
            onClick={toggleParallelPlay}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">Enable parallel play</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Play alongside other apps.
              </p>
            </div>
            <SettingsToggle checked={parallelPlayEnabled} onChange={toggleParallelPlay} />
          </div>

          <button
            onClick={() => setActiveDialog('background-play-help')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">¿La música deja de sonar?</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">
                Activar reproducción de fondo ininterrumpida
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>
        </div>

        {/* SECTION 4: PANTALLA DE BLOQUEO MAD PLAYER */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            PANTALLA DE BLOQUEO MAD PLAYER
          </span>

          <div
            onClick={toggleLockscreenPlayer}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <div className="min-w-0">
              <span className="text-base font-extrabold text-white">
                Reproductor de pantalla de bloqueo
              </span>
            </div>
            <SettingsToggle
              checked={lockscreenPlayerEnabled}
              onChange={toggleLockscreenPlayer}
            />
          </div>

          <div
            onClick={toggle24HourFormat}
            className="flex items-center justify-between gap-4 py-1.5 cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">24 hour time format</span>
            <SettingsToggle checked={use24HourFormat} onChange={toggle24HourFormat} />
          </div>

          <button
            onClick={() => setActiveDialog('muzio-lockscreen-bg')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">Lockscreen background</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">{muzioLockscreenBg}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>
        </div>

        {/* SECTION 5: PANTALLA DE BLOQUEO */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            PANTALLA DE BLOQUEO
          </span>

          <button
            onClick={() => setActiveDialog('system-lockscreen-bg')}
            className="flex items-center justify-between gap-4 py-1.5 text-left cursor-pointer"
          >
            <div className="min-w-0">
              <p className="text-base font-extrabold text-white">Lockscreen background</p>
              <p className="text-sm font-bold text-[#6e8499] mt-0.5">{systemLockscreenBg}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6e8499] shrink-0" />
          </button>
        </div>

        {/* SECTION 6: REPLAYGAIN */}
        <div className="flex flex-col gap-4">
          <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee]">
            REPLAYGAIN
          </span>

          <button
            onClick={() => setActiveDialog('replaygain')}
            className="flex items-center justify-between gap-4 py-2 text-left cursor-pointer"
          >
            <span className="text-base font-extrabold text-white">Source mode</span>
            <div className="flex items-center gap-1.5 text-sm font-extrabold text-[#6e8499] shrink-0">
              <span>{replayGainMode}</span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>
        </div>
      </div>
    </>
  );
};
