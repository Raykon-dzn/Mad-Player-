import React from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ChevronRight,
  HelpCircle,
  Info,
  Languages,
  MessageSquareWarning,
  Music2
} from 'lucide-react';
import { Track } from '../../types/music';
import { SettingsDialogType } from '../../hooks/useSettings';

interface AboutSettingsSectionProps {
  onGoBack: () => void;
  setActiveDialog: React.Dispatch<React.SetStateAction<SettingsDialogType>>;
  tracks: Track[];
  hiddenTracks: Track[];
  onShareText: (text: string) => void;
}

export const AboutSettingsSection: React.FC<AboutSettingsSectionProps> = ({
  onGoBack,
  setActiveDialog,
  tracks,
  hiddenTracks,
  onShareText
}) => {
  return (
    <>
      <div className="sticky top-0 z-20 flex items-center gap-5 px-4 py-4 bg-[#061928]/95 backdrop-blur-md">
        <button
          onClick={onGoBack}
          aria-label="Volver"
          className="w-10 h-10 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-extrabold font-display tracking-tight text-white">
          Acerca de
        </h1>
      </div>

      <div className="max-w-xl w-full mx-auto px-4 pb-16 flex flex-col justify-between flex-1 gap-8">
        <div className="flex flex-col gap-7">
          {/* Top App Logo Banner */}
          <div className="flex items-center justify-center gap-4 py-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-400 via-pink-500 to-purple-600 flex items-center justify-center shadow-xl">
              <Music2 className="w-9 h-9 text-white stroke-[2.5]" />
            </div>
            <span className="text-3xl font-black font-display tracking-tight text-white">
              Mad Player
            </span>
          </div>

          {/* SECTION: ACERCA DE */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee] mb-1">
              ACERCA DE
            </span>

            <button
              onClick={() => setActiveDialog('about-intro')}
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <Info className="w-5 h-5 text-[#7c93a8]" />
                <span className="text-base font-extrabold text-white">Introducción</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>

            <button
              onClick={() => setActiveDialog('about-changelog')}
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <AlertTriangle className="w-5 h-5 text-[#7c93a8]" />
                <span className="text-base font-extrabold text-white">Registro de cambios</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>

            <button
              onClick={() => setActiveDialog('about-faq')}
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <HelpCircle className="w-5 h-5 text-[#7c93a8]" />
                <span className="text-base font-extrabold text-white">
                  Preguntas frecuentes
                </span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>

            <button
              onClick={() => setActiveDialog('about-translate')}
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <Languages className="w-5 h-5 text-[#7c93a8]" />
                <span className="text-base font-extrabold text-white">Traducir</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>

            <button
              onClick={() =>
                onShareText(
                  `Mad Player v7.8.5 Logs — AudioContext 48kHz, Tracks: ${tracks.length}, Hidden: ${hiddenTracks.length}`
                )
              }
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <MessageSquareWarning className="w-5 h-5 text-[#7c93a8]" />
                <span className="text-base font-extrabold text-white">
                  Compartir registros de aplicación
                </span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>
          </div>

          {/* SECTION: SÍGUENOS */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#1cc8ee] mb-1">
              SÍGUENOS
            </span>

            <button
              onClick={() => onShareText('https://discord.gg/madplayer')}
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <div className="w-7 h-7 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-xs font-black">
                  D
                </div>
                <span className="text-base font-extrabold text-white">Discord</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>

            <button
              onClick={() => onShareText('https://facebook.com/madplayer')}
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <div className="w-7 h-7 rounded-full bg-[#1877F2] flex items-center justify-center text-white text-sm font-black">
                  f
                </div>
                <span className="text-base font-extrabold text-white">Facebook</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>

            <button
              onClick={() => onShareText('https://instagram.com/madplayer')}
              className="flex items-center justify-between py-3 text-left cursor-pointer hover:bg-white/5 rounded-xl px-1"
            >
              <div className="flex items-center gap-5">
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-amber-400 via-rose-500 to-purple-600 flex items-center justify-center text-white text-xs font-black">
                  IG
                </div>
                <span className="text-base font-extrabold text-white">Instagram</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#7c93a8]" />
            </button>
          </div>
        </div>

        {/* Footer Links & Version */}
        <div className="flex flex-col items-center gap-4 pt-4">
          <div className="flex items-center justify-center gap-4 text-xs font-extrabold text-[#6e8499]">
            <button
              onClick={() => setActiveDialog('about-web')}
              className="underline hover:text-white cursor-pointer"
            >
              Sitio Web
            </button>
            <span>|</span>
            <button
              onClick={() => setActiveDialog('about-privacy')}
              className="underline hover:text-white cursor-pointer"
            >
              Política de privacidad
            </button>
            <span>|</span>
            <button
              onClick={() => setActiveDialog('about-licenses')}
              className="underline hover:text-white cursor-pointer"
            >
              Licencias
            </button>
          </div>

          <p className="text-xs font-extrabold text-[#6e8499]">7.8.5 (1070080500)</p>
        </div>
      </div>
    </>
  );
};
