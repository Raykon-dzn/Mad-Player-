import React, { useState, useRef, useEffect } from 'react';
import {
  Track,
  Playlist,
  ThemeConfig,
  EqualizerState,
  PlayerSkin
} from '../../types/music';
import {
  getStorageUsageEstimate,
  loadCloudBackupFromDb,
  loadCloudEmailFromDb,
  requestPersistentStorage,
  revokeObjectUrlSafe,
  saveCloudBackupToDb,
  savePlaylistsToDb,
  saveTracksListMetaToDb,
  StorageUsageEstimate
} from '../../services/mediaStorageDb';
import { safeCopyToClipboard } from '../../utils/formatters';
import {
  PlayerSkinCarouselModal,
  ThemeStudioModal
} from '../../components/ThemeStudioModal';
import {
  BackupSelectionState,
  HiddenFolderItem,
  SettingsDialogType,
  SettingsSubPage,
  useSettingsContext
} from '../../hooks/useSettings';
import { MainSettingsSection } from './MainSettingsSection';
import { ProfileSettingsSection } from './ProfileSettingsSection';
import { AudioAndAppSettingsSection } from './AudioAndAppSettingsSection';
import { HiddenFilesSection } from './HiddenFilesSection';
import { BackupSettingsSection } from './BackupSettingsSection';
import { AboutSettingsSection } from './AboutSettingsSection';
import { SettingsDialogsModal } from './SettingsDialogsModal';

export interface SettingsLibrarySlice {
  tracks: Track[];
  visibleTracks: Track[];
  hiddenTracks: Track[];
  setTracks: React.Dispatch<React.SetStateAction<Track[]>>;
  playlists: Playlist[];
  setPlaylists: React.Dispatch<React.SetStateAction<Playlist[]>>;
  hiddenFolders: HiddenFolderItem[];
  setHiddenFolders: React.Dispatch<React.SetStateAction<HiddenFolderItem[]>>;
  minDurationFilterSeconds: number;
  setMinDurationFilterSeconds: React.Dispatch<React.SetStateAction<number>>;
  minSizeFilterKB: number;
  setMinSizeFilterKB: React.Dispatch<React.SetStateAction<number>>;
  lastAddedInterval: string;
  setLastAddedInterval: React.Dispatch<React.SetStateAction<string>>;
  duplicatePlaylistPolicy: 'ask' | 'allow' | 'skip';
  setDuplicatePlaylistPolicy: React.Dispatch<React.SetStateAction<'ask' | 'allow' | 'skip'>>;
  handleHideTrack: (trackId: string) => void;
  handleRestoreHiddenTrack: (trackId: string) => void;
  handleScanFolderOrLibrary: () => void;
}

export interface SettingsPlayerSlice {
  currentTrack?: Track;
  eqState: EqualizerState;
  setEqState: React.Dispatch<React.SetStateAction<EqualizerState>>;
  setIsShuffle: React.Dispatch<React.SetStateAction<boolean>>;
  setMobilePlayerExpanded: React.Dispatch<React.SetStateAction<boolean>>;
  userListeningSeconds: number;
  playTrack: (track: Track, customQueueIds?: string[], fromUserSelection?: boolean) => void;
}

export interface SettingsScreenProps {
  onClose: () => void;
  initialSubPage?: SettingsSubPage;
  library: SettingsLibrarySlice;
  player: SettingsPlayerSlice;
  themeConfig: ThemeConfig;
  onUpdateThemeConfig: React.Dispatch<React.SetStateAction<ThemeConfig>>;
  onOpenLockscreenPreview: () => void;
  onOpenEqualizerTab: () => void;
  showToast: (msg: string) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onClose,
  initialSubPage = 'main',
  library,
  player,
  themeConfig,
  onUpdateThemeConfig,
  onOpenLockscreenPreview,
  onOpenEqualizerTab,
  showToast
}) => {
  const settings = useSettingsContext();
  const {
    userProfileName,
    userProfileAvatar,
    updateUserProfile,
    openPlayerOnPlay,
    alwaysShuffleEnabled,
    setAlwaysShuffleEnabled
  } = settings;

  const {
    tracks,
    visibleTracks,
    hiddenTracks,
    playlists,
    hiddenFolders,
    minDurationFilterSeconds,
    minSizeFilterKB,
    lastAddedInterval,
    duplicatePlaylistPolicy
  } = library;

  const hiddenTrackIds = React.useMemo(
    () => hiddenTracks.map(t => t.id),
    [hiddenTracks]
  );

  const [pageHistory, setPageHistory] = useState<SettingsSubPage[]>([initialSubPage]);
  const subPage = pageHistory[pageHistory.length - 1] || 'main';

  useEffect(() => {
    setPageHistory([initialSubPage]);
  }, [initialSubPage]);

  const [activeDialog, setActiveDialog] = useState<SettingsDialogType>(null);

  const navigateToSubPage = (nextPage: SettingsSubPage) => {
    setPageHistory(prev => [...prev, nextPage]);
  };

  const handleGoBack = () => {
    if (activeDialog) {
      setActiveDialog(null);
      return;
    }
    if (pageHistory.length > 1) {
      setPageHistory(prev => prev.slice(0, -1));
    } else {
      onClose();
    }
  };

  // Profile edit state
  const [draftProfileName, setDraftProfileName] = useState(userProfileName);
  const profileAvatarInputRef = useRef<HTMLInputElement | null>(null);

  // Backup & Storage state
  const [cloudEmail, setCloudEmail] = useState<string>('serchpol98@gmail.com');
  const [draftCloudEmail, setDraftCloudEmail] = useState(cloudEmail);
  const [storageEstimate, setStorageEstimate] = useState<StorageUsageEstimate>({
    usageBytes: 0,
    quotaBytes: 0,
    persisted: false,
    supported: false
  });

  // Tracks imported from a folder without FileSystemFileHandle (e.g. webkitdirectory fallback)
  // that had to store audioBlob as a backup in IndexedDB
  const folderBackupStats = React.useMemo(() => {
    const fallbackFolderTracks = tracks.filter(
      t => t.importedFromFolder && !t.fileHandle && !t.audioUnavailable
    );
    const totalBytes = fallbackFolderTracks.reduce((acc, t) => {
      if (typeof t.fileSizeBytes === 'number' && t.fileSizeBytes > 0) {
        return acc + t.fileSizeBytes;
      }
      if (typeof t.fileSizeKB === 'number' && t.fileSizeKB > 0) {
        return acc + t.fileSizeKB * 1024;
      }
      return acc;
    }, 0);
    return {
      count: fallbackFolderTracks.length,
      totalBytes
    };
  }, [tracks]);

  const refreshStorageUsage = async (tryPersist = false) => {
    if (tryPersist) {
      await requestPersistentStorage();
    }
    const est = await getStorageUsageEstimate();
    setStorageEstimate(est);
  };

  useEffect(() => {
    let active = true;
    loadCloudEmailFromDb().then(savedEmail => {
      if (active && savedEmail) {
        setCloudEmail(savedEmail);
        setDraftCloudEmail(savedEmail);
      }
    });
    (async () => {
      await requestPersistentStorage();
      const est = await getStorageUsageEstimate();
      if (active) {
        setStorageEstimate(est);
      }
    })();
    return () => {
      active = false;
    };
  }, [tracks.length, playlists.length]);

  const [cloudSelection, setCloudSelection] = useState<BackupSelectionState>({
    covers: true,
    tags: true,
    lyrics: true,
    playlists: true,
    hiddenFiles: true
  });

  const [localSelection, setLocalSelection] = useState<BackupSelectionState>({
    covers: true,
    tags: true,
    lyrics: true,
    playlists: true,
    hiddenFiles: true
  });

  const restoreFileInputRef = useRef<HTMLInputElement | null>(null);

  // Total listening hours calculation (base 97 hrs + live seconds)
  const totalHoursDisplay = Math.max(
    97,
    Math.floor((97 * 3600 + player.userListeningSeconds) / 3600)
  );

  const handleRestoreBackupData = (data: {
    tracks?: Track[];
    playlists?: Playlist[];
    hiddenTrackIds?: string[];
    hiddenFolders?: HiddenFolderItem[];
  }) => {
    if (data.tracks && Array.isArray(data.tracks) && data.tracks.length > 0) {
      library.setTracks(prev => {
        prev.forEach(old => {
          if (!data.tracks?.some(n => n.audioUrl === old.audioUrl)) {
            revokeObjectUrlSafe(old.audioUrl);
          }
          if (!data.tracks?.some(n => n.coverUrl === old.coverUrl)) {
            revokeObjectUrlSafe(old.coverUrl);
          }
        });
        return data.tracks!;
      });
      saveTracksListMetaToDb(data.tracks);
    }
    if (data.playlists && Array.isArray(data.playlists)) {
      library.setPlaylists(data.playlists);
      savePlaylistsToDb(data.playlists);
    }
    if (data.hiddenTrackIds && Array.isArray(data.hiddenTrackIds)) {
      const hiddenSet = new Set(data.hiddenTrackIds);
      library.setTracks(prev => {
        const updated = prev.map(t => ({ ...t, isHidden: hiddenSet.has(t.id) }));
        saveTracksListMetaToDb(updated);
        return updated;
      });
    }
    if (data.hiddenFolders && Array.isArray(data.hiddenFolders)) {
      library.setHiddenFolders(data.hiddenFolders);
    }
  };

  // Cloud Backup & Restore handlers
  const handleCloudBackup = async () => {
    const payload = {
      email: cloudEmail,
      createdAt: new Date().toISOString(),
      tracks:
        cloudSelection.tags || cloudSelection.covers || cloudSelection.lyrics
          ? tracks
          : undefined,
      playlists: cloudSelection.playlists ? playlists : undefined,
      hiddenTrackIds: cloudSelection.hiddenFiles ? hiddenTrackIds : undefined,
      hiddenFolders: cloudSelection.hiddenFiles ? hiddenFolders : undefined
    };
    try {
      await saveCloudBackupToDb(payload);
      showToast(`Respaldo en la nube guardado en ${cloudEmail}`);
    } catch {
      showToast('Respaldo en la nube completado');
    }
  };

  const handleCloudRestore = async () => {
    try {
      const parsed = await loadCloudBackupFromDb<{
        email?: string;
        tracks?: Track[];
        playlists?: Playlist[];
        hiddenTrackIds?: string[];
        hiddenFolders?: HiddenFolderItem[];
      }>();
      if (!parsed) {
        showToast(`No hay copia previa en ${cloudEmail}. Pulsa "Respaldar" primero.`);
        return;
      }
      handleRestoreBackupData({
        tracks:
          cloudSelection.tags || cloudSelection.covers || cloudSelection.lyrics
            ? parsed.tracks
            : undefined,
        playlists: cloudSelection.playlists ? parsed.playlists : undefined,
        hiddenTrackIds: cloudSelection.hiddenFiles ? parsed.hiddenTrackIds : undefined,
        hiddenFolders: cloudSelection.hiddenFiles ? parsed.hiddenFolders : undefined
      });
      showToast(`Copia restaurada desde ${parsed.email || cloudEmail}`);
    } catch {
      showToast('Error al restaurar copia de la nube');
    }
  };

  // Local Backup & Restore handlers
  const handleLocalBackupDownload = () => {
    const payload = {
      app: 'Mad Player',
      version: '7.8.5',
      createdAt: new Date().toISOString(),
      selection: localSelection,
      tracks:
        localSelection.tags || localSelection.covers || localSelection.lyrics
          ? tracks
          : undefined,
      playlists: localSelection.playlists ? playlists : undefined,
      hiddenTrackIds: localSelection.hiddenFiles ? hiddenTrackIds : undefined,
      hiddenFolders: localSelection.hiddenFiles ? hiddenFolders : undefined
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mad_player_respaldo_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Copia de seguridad local descargada (.json)');
  };

  const handleLocalRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        handleRestoreBackupData({
          tracks:
            localSelection.tags || localSelection.covers || localSelection.lyrics
              ? parsed.tracks
              : undefined,
          playlists: localSelection.playlists ? parsed.playlists : undefined,
          hiddenTrackIds: localSelection.hiddenFiles ? parsed.hiddenTrackIds : undefined,
          hiddenFolders: localSelection.hiddenFiles ? parsed.hiddenFolders : undefined
        });
        showToast('Respaldo local restaurado correctamente');
      } catch {
        showToast('Archivo de respaldo no válido');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Handle Custom Avatar Upload
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (userProfileAvatar && userProfileAvatar.startsWith('blob:')) {
      URL.revokeObjectURL(userProfileAvatar);
    }
    const url = URL.createObjectURL(file);
    updateUserProfile(userProfileName, url);
    showToast('Foto de perfil actualizada');
    e.target.value = '';
  };

  const handleShareText = (text: string) => {
    safeCopyToClipboard(text);
    showToast('Enlace / información copiada al portapapeles');
  };

  const handlePlayTrackFromSettings = (track: Track, contextIds?: string[]) => {
    player.playTrack(track, contextIds);
    if (openPlayerOnPlay) {
      onClose();
      player.setMobilePlayerExpanded(true);
    }
  };

  const handleToggleAlwaysShuffle = () => {
    const next = !alwaysShuffleEnabled;
    setAlwaysShuffleEnabled(next);
    if (next) player.setIsShuffle(true);
    showToast(
      next ? 'Aleatorio permanente activado' : 'Aleatorio permanente desactivado'
    );
  };

  const handleAddHiddenFolder = (name: string, path: string) => {
    library.setHiddenFolders(prev => [
      ...prev,
      { id: `hf-${Date.now()}`, name, path }
    ]);
    showToast(`Carpeta "${name}" añadida a Hidden Files`);
  };

  const handleRemoveHiddenFolder = (id: string) => {
    library.setHiddenFolders(prev => prev.filter(f => f.id !== id));
    showToast('Carpeta restaurada');
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto flex flex-col select-none"
      style={{ backgroundColor: '#061928', color: '#f8fafc' }}
    >
      {/* Hidden file inputs for Avatar and Local Restore */}
      <input
        ref={profileAvatarInputRef}
        type="file"
        accept="image/*"
        onChange={handleAvatarUpload}
        className="hidden"
      />
      <input
        ref={restoreFileInputRef}
        type="file"
        accept=".json,application/json"
        onChange={handleLocalRestoreFile}
        className="hidden"
      />

      {subPage === 'main' && (
        <MainSettingsSection
          onClose={onClose}
          navigateToSubPage={navigateToSubPage}
          tracks={tracks}
          visibleTracks={visibleTracks}
          hiddenTracks={hiddenTracks}
          currentTrack={player.currentTrack}
          eqState={player.eqState}
          totalHoursDisplay={totalHoursDisplay}
          storageEstimate={storageEstimate}
          folderBackupStats={folderBackupStats}
          refreshStorageUsage={refreshStorageUsage}
          onTriggerScanMedia={library.handleScanFolderOrLibrary}
          onShareText={handleShareText}
          showToast={showToast}
        />
      )}

      {subPage === 'profile' && (
        <ProfileSettingsSection
          onGoBack={handleGoBack}
          tracks={tracks}
          currentTrack={player.currentTrack}
          totalHoursDisplay={totalHoursDisplay}
          onPlayTrack={handlePlayTrackFromSettings}
          onShareText={handleShareText}
          onTriggerAvatarUpload={() => profileAvatarInputRef.current?.click()}
          onOpenEditProfileDialog={() => {
            setDraftProfileName(userProfileName);
            setActiveDialog('edit-profile');
          }}
        />
      )}

      {(subPage === 'audio' || subPage === 'app') && (
        <AudioAndAppSettingsSection
          subPage={subPage}
          onGoBack={handleGoBack}
          navigateToSubPage={navigateToSubPage}
          setActiveDialog={setActiveDialog}
          themeConfig={themeConfig}
          onUpdateThemeConfig={onUpdateThemeConfig}
          eqState={player.eqState}
          lastAddedInterval={lastAddedInterval}
          duplicatePlaylistPolicy={duplicatePlaylistPolicy}
          onToggleAlwaysShuffle={handleToggleAlwaysShuffle}
        />
      )}

      {subPage === 'hidden-files' && (
        <HiddenFilesSection
          onGoBack={handleGoBack}
          setActiveDialog={setActiveDialog}
          hiddenFolders={hiddenFolders}
          onRemoveHiddenFolder={handleRemoveHiddenFolder}
          hiddenTracks={hiddenTracks}
          onRestoreHiddenTrack={library.handleRestoreHiddenTrack}
          minDurationFilterSeconds={minDurationFilterSeconds}
          minSizeFilterKB={minSizeFilterKB}
          showToast={showToast}
        />
      )}

      {subPage === 'backup' && (
        <BackupSettingsSection
          onGoBack={handleGoBack}
          setActiveDialog={setActiveDialog}
          cloudEmail={cloudEmail}
          onOpenCloudEmailDialog={() => {
            setDraftCloudEmail(cloudEmail);
            setActiveDialog('cloud-email');
          }}
          cloudSelection={cloudSelection}
          localSelection={localSelection}
          onCloudBackup={handleCloudBackup}
          onCloudRestore={handleCloudRestore}
          onLocalBackupDownload={handleLocalBackupDownload}
          onTriggerLocalRestoreFile={() => restoreFileInputRef.current?.click()}
        />
      )}

      {subPage === 'about' && (
        <AboutSettingsSection
          onGoBack={handleGoBack}
          setActiveDialog={setActiveDialog}
          tracks={tracks}
          hiddenTracks={hiddenTracks}
          onShareText={handleShareText}
        />
      )}

      {subPage === 'elegir-tema' && (
        <ThemeStudioModal
          onBack={handleGoBack}
          onClose={handleGoBack}
          themeConfig={themeConfig}
          onUpdateThemeConfig={onUpdateThemeConfig}
          currentTrack={player.currentTrack}
          tracks={visibleTracks}
          showToast={showToast}
        />
      )}

      {subPage === 'player-skins' && (
        <PlayerSkinCarouselModal
          onClose={handleGoBack}
          currentSkin={themeConfig.playerSkin}
          onApplySkin={(skin: PlayerSkin) => {
            onUpdateThemeConfig(prev => ({ ...prev, playerSkin: skin }));
          }}
          onSelectSkin={(skin: PlayerSkin) => {
            onUpdateThemeConfig(prev => ({ ...prev, playerSkin: skin }));
          }}
          currentTrack={player.currentTrack}
          showToast={showToast}
        />
      )}

      <SettingsDialogsModal
        activeDialog={activeDialog}
        setActiveDialog={setActiveDialog}
        onCloseSettings={onClose}
        draftProfileName={draftProfileName}
        setDraftProfileName={setDraftProfileName}
        onTriggerAvatarUpload={() => profileAvatarInputRef.current?.click()}
        tracks={tracks}
        visibleTracks={visibleTracks}
        lastAddedInterval={lastAddedInterval}
        onChangeLastAddedInterval={library.setLastAddedInterval}
        duplicatePlaylistPolicy={duplicatePlaylistPolicy}
        onChangeDuplicatePlaylistPolicy={library.setDuplicatePlaylistPolicy}
        minDurationFilterSeconds={minDurationFilterSeconds}
        onChangeMinDurationFilter={library.setMinDurationFilterSeconds}
        minSizeFilterKB={minSizeFilterKB}
        onChangeMinSizeFilter={library.setMinSizeFilterKB}
        onAddHiddenFolder={handleAddHiddenFolder}
        onHideTrack={library.handleHideTrack}
        themeConfig={themeConfig}
        onUpdateThemeConfig={onUpdateThemeConfig}
        eqState={player.eqState}
        onUpdateEqState={player.setEqState}
        onOpenEqualizerTab={onOpenEqualizerTab}
        onOpenLockscreenPreview={onOpenLockscreenPreview}
        draftCloudEmail={draftCloudEmail}
        setDraftCloudEmail={setDraftCloudEmail}
        setCloudEmail={setCloudEmail}
        cloudSelection={cloudSelection}
        setCloudSelection={setCloudSelection}
        localSelection={localSelection}
        setLocalSelection={setLocalSelection}
        showToast={showToast}
      />
    </div>
  );
};
