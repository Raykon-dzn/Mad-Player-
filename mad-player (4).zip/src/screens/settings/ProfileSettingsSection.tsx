import React from 'react';
import {
  ArrowLeft,
  Headphones,
  Music2,
  Pencil,
  Share2
} from 'lucide-react';
import { Track } from '../../types/music';
import { SettingsDialogType, useSettingsContext } from '../../hooks/useSettings';

interface ProfileSettingsSectionProps {
  onGoBack: () => void;
  tracks: Track[];
  currentTrack?: Track;
  totalHoursDisplay: number;
  onPlayTrack: (track: Track, contextIds?: string[]) => void;
  onShareText: (text: string) => void;
  onTriggerAvatarUpload: () => void;
  onOpenEditProfileDialog: () => void;
  setActiveDialog?: React.Dispatch<React.SetStateAction<SettingsDialogType>>;
}

export const ProfileSettingsSection: React.FC<ProfileSettingsSectionProps> = ({
  onGoBack,
  tracks,
  currentTrack,
  totalHoursDisplay,
  onPlayTrack,
  onShareText,
  onTriggerAvatarUpload,
  onOpenEditProfileDialog
}) => {
  const { userProfileName, userProfileAvatar } = useSettingsContext();

  const topTracks = React.useMemo(
    () => [...tracks].sort((a, b) => b.playCount - a.playCount),
    [tracks]
  );

  const topArtists = React.useMemo(() => {
    const map = new Map<
      string,
      { artist: string; coverUrl: string; totalPlays: number; tracks: Track[] }
    >();
    tracks.forEach(t => {
      const existing = map.get(t.artist);
      if (existing) {
        existing.totalPlays += t.playCount;
        existing.tracks.push(t);
        if (!existing.coverUrl && t.coverUrl) existing.coverUrl = t.coverUrl;
      } else {
        map.set(t.artist, {
          artist: t.artist,
          coverUrl: t.coverUrl,
          totalPlays: t.playCount,
          tracks: [t]
        });
      }
    });
    return Array.from(map.values()).sort((a, b) => b.totalPlays - a.totalPlays);
  }, [tracks]);

  const topAlbums = React.useMemo(() => {
    const map = new Map<
      string,
      { album: string; artist: string; coverUrl: string; totalPlays: number; tracks: Track[] }
    >();
    tracks.forEach(t => {
      const existing = map.get(t.album);
      if (existing) {
        existing.totalPlays += t.playCount;
        existing.tracks.push(t);
        if (!existing.coverUrl && t.coverUrl) existing.coverUrl = t.coverUrl;
      } else {
        map.set(t.album, {
          album: t.album,
          artist: t.artist,
          coverUrl: t.coverUrl,
          totalPlays: t.playCount,
          tracks: [t]
        });
      }
    });
    return Array.from(map.values()).sort((a, b) => b.totalPlays - a.totalPlays);
  }, [tracks]);

  return (
    <>
      <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-4 bg-[#061928]/95 backdrop-blur-md">
        <button
          onClick={onGoBack}
          aria-label="Volver"
          className="w-10 h-10 rounded-full flex items-center justify-center text-slate-300 hover:bg-white/10 cursor-pointer"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenEditProfileDialog}
            aria-label="Editar perfil"
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#7c93a8] hover:text-white hover:bg-white/10 cursor-pointer"
          >
            <Pencil className="w-5 h-5" />
          </button>
          <button
            onClick={() =>
              onShareText(
                `Perfil de ${userProfileName} en Mad Player — ${totalHoursDisplay} hrs de música escuchadas. Canción top: ${topTracks[0]?.title || 'N/A'}`
              )
            }
            aria-label="Compartir estadísticas"
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#7c93a8] hover:text-white hover:bg-white/10 cursor-pointer"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="max-w-xl w-full mx-auto px-4 pb-16 flex flex-col gap-7">
        {/* Avatar & Username */}
        <div className="flex flex-col items-center gap-3 pt-1">
          <div
            onClick={onTriggerAvatarUpload}
            className="w-28 h-28 rounded-full overflow-hidden border-2 border-white/15 shadow-2xl bg-gradient-to-b from-yellow-200 via-amber-200 to-amber-500 flex items-center justify-center cursor-pointer relative group"
          >
            {userProfileAvatar || currentTrack?.coverUrl ? (
              <img
                src={userProfileAvatar || currentTrack?.coverUrl}
                alt={userProfileName}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-center p-2 text-slate-900">
                <span className="text-[9px] font-mono uppercase tracking-widest opacity-75">
                  ONE DAY I&apos;LL BE SOMEBODY
                </span>
                <Headphones className="w-9 h-9 mt-1 stroke-[1.8]" />
              </div>
            )}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
              <Pencil className="w-6 h-6 text-white" />
            </div>
          </div>

          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            {userProfileName}
          </h2>
        </div>

        {/* Stats Row (Total & Audio ONLY) */}
        <div className="grid grid-cols-2 divide-x divide-white/10 py-1 text-center">
          <div className="flex flex-col items-center gap-1">
            <span className="text-xs font-extrabold text-[#6e8499]">Total</span>
            <p className="text-white font-extrabold">
              <span className="text-2xl">{totalHoursDisplay}</span>{' '}
              <span className="text-base">hrs</span>
            </p>
          </div>
          <div className="flex flex-col items-center gap-1">
            <span className="text-xs font-extrabold text-[#6e8499]">Audio</span>
            <p className="text-white font-extrabold">
              <span className="text-2xl">{totalHoursDisplay}</span>{' '}
              <span className="text-base">hrs</span>
            </p>
          </div>
        </div>

        {/* 1. Canciones más escuchadas */}
        <div className="flex flex-col gap-3.5">
          <h3 className="text-lg font-extrabold text-white tracking-tight">
            Canciones más escuchadas
          </h3>
          <div className="flex items-start gap-3.5 overflow-x-auto pb-2 no-scrollbar">
            {topTracks.map(track => (
              <div
                key={`prof-track-${track.id}`}
                onClick={() => onPlayTrack(track, topTracks.map(t => t.id))}
                className="w-36 sm:w-40 shrink-0 flex flex-col gap-2 cursor-pointer group"
              >
                <div className="w-full aspect-square rounded-xl overflow-hidden bg-[#3b4d5e] shadow-md">
                  {track.coverUrl ? (
                    <img
                      src={track.coverUrl}
                      alt={track.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[#132230]">
                      <Music2 className="w-14 h-14 stroke-[2]" />
                    </div>
                  )}
                </div>
                <div className="min-w-0">
                  <p className="text-base font-extrabold text-white truncate">{track.title}</p>
                  <p className="text-xs font-extrabold text-[#6e8499] truncate mt-0.5">
                    {track.artist}
                  </p>
                  <p className="text-xs font-extrabold text-[#6e8499] truncate mt-0.5">
                    {track.playCount} Tiempo
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Artistas más escuchados (Circular Avatars) */}
        <div className="flex flex-col gap-3.5">
          <h3 className="text-lg font-extrabold text-white tracking-tight">
            Artistas más escuchados
          </h3>
          <div className="flex items-start gap-4 overflow-x-auto pb-2 no-scrollbar">
            {topArtists.map(item => (
              <div
                key={`prof-artist-${item.artist}`}
                onClick={() =>
                  onPlayTrack(
                    item.tracks[0],
                    item.tracks.map(t => t.id)
                  )
                }
                className="w-36 sm:w-40 shrink-0 flex flex-col gap-2.5 cursor-pointer group"
              >
                <div className="w-full aspect-square rounded-full overflow-hidden bg-[#3b4d5e] shadow-md">
                  {item.coverUrl ? (
                    <img
                      src={item.coverUrl}
                      alt={item.artist}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[#132230]">
                      <Music2 className="w-14 h-14 stroke-[2]" />
                    </div>
                  )}
                </div>
                <div className="min-w-0">
                  <p className="text-base font-extrabold text-white truncate">{item.artist}</p>
                  <p className="text-xs font-extrabold text-[#6e8499] truncate mt-0.5">
                    {item.totalPlays} Tiempo
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3. Álbumes más escuchados */}
        <div className="flex flex-col gap-3.5">
          <h3 className="text-lg font-extrabold text-white tracking-tight">
            Álbumes más escuchados
          </h3>
          <div className="flex items-start gap-3.5 overflow-x-auto pb-2 no-scrollbar">
            {topAlbums.map(item => (
              <div
                key={`prof-album-${item.album}`}
                onClick={() =>
                  onPlayTrack(
                    item.tracks[0],
                    item.tracks.map(t => t.id)
                  )
                }
                className="w-36 sm:w-40 shrink-0 flex flex-col gap-2 cursor-pointer group"
              >
                <div className="w-full aspect-square rounded-xl overflow-hidden bg-[#3b4d5e] shadow-md">
                  {item.coverUrl ? (
                    <img
                      src={item.coverUrl}
                      alt={item.album}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[#132230]">
                      <Music2 className="w-14 h-14 stroke-[2]" />
                    </div>
                  )}
                </div>
                <div className="min-w-0">
                  <p className="text-base font-extrabold text-white truncate">{item.album}</p>
                  <p className="text-xs font-extrabold text-[#6e8499] truncate mt-0.5">
                    {item.artist}
                  </p>
                  <p className="text-xs font-extrabold text-[#6e8499] truncate mt-0.5">
                    {item.totalPlays} Tiempo
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer User Since Date */}
        <div className="pt-4 pb-2 text-center">
          <p className="text-sm font-extrabold text-[#6e8499]">Usuario desde 16 feb, 2026</p>
        </div>
      </div>
    </>
  );
};
