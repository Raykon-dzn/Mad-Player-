import React from 'react';
import { BackupSelectionState } from '../../hooks/useSettings';

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function formatStorageBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 MB';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const idx = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const val = bytes / Math.pow(1024, idx);
  return `${val >= 100 || idx === 0 ? Math.round(val) : val.toFixed(1)} ${units[idx]}`;
}

export function formatBackupSubtitle(sel: BackupSelectionState): string {
  const items: string[] = [];
  if (sel.covers) items.push('Carátulas');
  if (sel.tags) items.push('Etiquetas');
  if (sel.lyrics) items.push('Letra');
  if (sel.playlists) items.push('Lista de Reproducción');
  if (sel.hiddenFiles) items.push('Hidden Files');
  return items.length > 0 ? `Audio: ${items.join(', ')}` : 'Ningún elemento seleccionado';
}

export const SettingsToggle: React.FC<{
  checked: boolean;
  onChange: () => void;
  label?: string;
}> = ({ checked, onChange, label }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    aria-label={label || 'Alternar opción'}
    onClick={e => {
      e.stopPropagation();
      onChange();
    }}
    className={`w-12 h-7 rounded-full p-0.5 transition-colors flex items-center shrink-0 cursor-pointer ${
      checked ? 'bg-[#1cc8ee]' : 'bg-[#6b7c8c]'
    }`}
  >
    <div
      className={`w-6 h-6 rounded-full bg-white shadow-md transition-transform ${
        checked ? 'translate-x-5' : 'translate-x-0'
      }`}
    />
  </button>
);
