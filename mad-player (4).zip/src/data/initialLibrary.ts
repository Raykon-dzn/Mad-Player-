import { Track, Playlist, SmartPlaylist, EqualizerBand } from '../types/music';

export const INITIAL_TRACKS: Track[] = [];

export const INITIAL_PLAYLISTS: Playlist[] = [];

export const INITIAL_SMART_PLAYLISTS: SmartPlaylist[] = [
  {
    id: 'smart-favorites-2026',
    name: 'Favoritos',
    description: 'Pistas marcadas como favoritas.',
    matchMode: 'all',
    rules: [
      { id: 'r-1', field: 'isFavorite', operator: 'equals', value: true }
    ],
    sortBy: 'playCount',
    sortOrder: 'desc'
  }
];

export const DEFAULT_EQ_BANDS: EqualizerBand[] = [
  { frequency: 60, label: '60 Hz', gain: 2 },
  { frequency: 230, label: '230 Hz', gain: 1 },
  { frequency: 910, label: '910 Hz', gain: 0 },
  { frequency: 3600, label: '3.6 kHz', gain: 1.5 },
  { frequency: 14000, label: '14 kHz', gain: 2.5 }
];

export const EQ_PRESETS: Record<string, number[]> = {
  'Estudio Cálido': [2, 1, 0, 1.5, 2.5],
  'Plano (Referencia)': [0, 0, 0, 0, 0],
  'Bajos Profundos': [6, 4.5, 0, -1, 1.5],
  'Claridad Vocal': [-1.5, 0, 3.5, 4, 1.5],
  'Electrónica & Synth': [4.5, 2, -1.5, 2.5, 5],
  'Acústico Natural': [1.5, 1, 0.5, 2, 3]
};
