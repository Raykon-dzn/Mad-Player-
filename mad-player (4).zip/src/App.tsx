import React, { useState, useEffect } from 'react';
import {
  Check,
  FolderSearch,
  Menu,
  Moon,
  MoreVertical,
  Search,
  X
} from 'lucide-react';
import {
  PlayerSkin,
  Track
} from './types/music';
import {
  formatDuration
} from './utils/formatters';
import { audioEngine } from './services/audioEngine';
import { useLibrary } from './hooks/useLibrary';
import { usePlayer } from './hooks/usePlayer';
import { useTheme } from './hooks/useTheme';
import { useEqualizer } from './hooks/useEqualizer';
import {
  SettingsProvider,
  SettingsSubPage,
  useSettings
} from './hooks/useSettings';
import { SuggestedScreen } from './screens/SuggestedScreen';
import { SongsScreen } from './screens/SongsScreen';
import { AlbumsScreen } from './screens/AlbumsScreen';
import { ArtistsScreen } from './screens/ArtistsScreen';
import { FoldersScreen } from './screens/FoldersScreen';
import { GenresScreen } from './screens/GenresScreen';
import { PlaylistsScreen } from './screens/PlaylistsScreen';
import { ThemesAndEqualizerScreen } from './screens/ThemesAndEqualizerScreen';
import { SettingsScreen } from './screens/settings';
import { FullPlayer } from './components/player/FullPlayer';
import { MiniPlayer } from './components/player/MiniPlayer';
import { PlayerModals, ActiveModal } from './components/PlayerModals';
import { PlayerSkinCarouselModal } from './components/ThemeStudioModal';

type NavTab =
  | 'suggested'
  | 'library'
  | 'albums'
  | 'artists'
  | 'playlists'
  | 'folders'
  | 'genres'
  | 'smart-lists'
  | 'themes'
  | 'equalizer';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('suggested');
  const [showHeaderMenu, setShowHeaderMenu] = useState<boolean>(false);
  const [showFullSettingsScreen, setShowFullSettingsScreen] = useState<boolean>(false);
  const [settingsInitialSubPage, setSettingsInitialSubPage] = useState<SettingsSubPage>('main');
  const [showMobileSearch, setShowMobileSearch] = useState<boolean>(false);

  // Active 3-dots Action Sheet / Modals
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [showQuickPlayerSkinsModal, setShowQuickPlayerSkinsModal] = useState<boolean>(false);
  const [showEqualizerModal, setShowEqualizerModal] = useState<boolean>(false);

  // Toast Notification
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setStatusMessage(msg);
    window.setTimeout(() => {
      setStatusMessage(prev => (prev === msg ? null : prev));
    }, 3000);
  };

  // 0. Settings Hook (UI, lockscreen, profile, tabs & audio transition preferences)
  const settings = useSettings({ showToast });

  // 1. Theme Hook
  const {
    themeConfig,
    setThemeConfig,
    extractedTrackColor,
    activePalette,
    syncTrackDominantColor
  } = useTheme();

  // 2. Equalizer Hook
  const {
    eqState,
    setEqState,
    handleInstantSpeedAndPitchChange
  } = useEqualizer();

  // 3. Library Hook (tracks, playlists, smartPlaylists, folders, search, filters, file & folder scanning)
  const library = useLibrary({
    activeAccentColor: activePalette.accent,
    showToast,
    onTracksImported: (importedTracks: Track[]) => {
      player.setQueueIds(prev => [...importedTracks.map(t => t.id), ...prev]);
      if (!player.currentTrackId) {
        player.setCurrentTrackId(importedTracks[0].id);
        player.setDuration(importedTracks[0].duration || 0);
        audioEngine.loadTrack(importedTracks[0], false);
      } else {
        player.playTrack(importedTracks[0], [
          ...importedTracks.map(t => t.id),
          ...player.queueIds
        ]);
      }
    },
    onTracksRestored: (restoredTracks: Track[]) => {
      player.setQueueIds(restoredTracks.map(t => t.id));
      player.setCurrentTrackId(restoredTracks[0].id);
      player.setDuration(restoredTracks[0].duration || 0);
      audioEngine.loadTrack(restoredTracks[0], false);
    },
    onTrackDeleted: (deletedId: string, remaining: Track[]) => {
      player.setQueueIds(prev => prev.filter(id => id !== deletedId));
      if (remaining.length === 0) {
        audioEngine.pause();
        player.setIsPlaying(false);
        player.setCurrentTrackId('');
        player.setCurrentTime(0);
        player.setDuration(0);
        player.setMobilePlayerExpanded(false);
      } else if (player.currentTrack?.id === deletedId) {
        player.playTrack(
          remaining[0],
          remaining.map(t => t.id)
        );
      }
    }
  });

  // 4. Player Hook (Tone.js playback, queue, transitions, sleep timer)
  const player = usePlayer({
    tracks: library.tracks,
    visibleTracks: library.visibleTracks,
    setTracks: library.setTracks,
    eqState,
    setEqState,
    handleInstantSpeedAndPitchChange,
    settings,
    showToast
  });

  // Extract dominant color from active track's cover art
  useEffect(() => {
    return syncTrackDominantColor(player.currentTrack);
  }, [player.currentTrack, syncTrackDominantColor]);

  const handleBatchAddToQueue = () => {
    if (library.selectedTrackIds.length === 0) return;
    player.setQueueIds(prev => Array.from(new Set([...prev, ...library.selectedTrackIds])));
    showToast(`${library.selectedTrackIds.length} pistas añadidas a la cola`);
    library.setSelectedTrackIds([]);
  };

  return (
    <SettingsProvider value={settings}>
      <div
        className="min-h-screen flex flex-col selection:bg-sky-500/20 relative"
        style={{
          backgroundColor: 'var(--theme-bg)',
          backgroundImage:
            themeConfig.appBgMode === 'gradient' && themeConfig.bgGradientCss
              ? themeConfig.bgGradientCss
              : undefined,
          color: 'var(--theme-text)'
        }}
      >
      {/* Dynamic Custom Wallpaper Background Layer with Alpha & Blur */}
      {themeConfig.appBgMode === 'image' &&
        (themeConfig.bgImageUrl || themeConfig.bgGradientCss) && (
          <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
            {themeConfig.bgImageUrl ? (
              <img
                src={themeConfig.bgImageUrl}
                alt=""
                className="w-full h-full object-cover scale-105"
                style={{
                  opacity:
                    (themeConfig.bgImageAlpha ?? 0.65) > 1
                      ? (themeConfig.bgImageAlpha ?? 65) / 100
                      : (themeConfig.bgImageAlpha ?? 0.65),
                  filter: `blur(${themeConfig.bgImageBlur ?? 6}px)`
                }}
              />
            ) : (
              <div
                className="w-full h-full scale-105"
                style={{
                  background: themeConfig.bgGradientCss,
                  opacity:
                    (themeConfig.bgImageAlpha ?? 0.65) > 1
                      ? (themeConfig.bgImageAlpha ?? 65) / 100
                      : (themeConfig.bgImageAlpha ?? 0.65),
                  filter: `blur(${themeConfig.bgImageBlur ?? 6}px)`
                }}
              />
            )}
            <div className="absolute inset-0 bg-black/35" />
          </div>
        )}

      {/* Hidden Local Audio File Input */}
      <input
        ref={library.fileInputRef}
        type="file"
        accept="audio/*,.mp3,.m4a,.flac,.wav,.ogg,.aac,.opus"
        multiple
        onChange={library.handleImportAudioFiles}
        className="hidden"
      />

      {/* Hidden Directory / Folder Scanner Input (webkitdirectory) */}
      <input
        ref={library.folderInputRef}
        type="file"
        {...({ webkitdirectory: '', directory: '' } as React.InputHTMLAttributes<HTMLInputElement>)}
        multiple
        onChange={library.handleImportFolderFiles}
        className="hidden"
      />

      {/* Hidden Custom Cover Art Image Input */}
      <input
        ref={library.coverInputRef}
        type="file"
        accept="image/*"
        onChange={e => library.handleCustomCoverChange(e, player.currentTrack?.id)}
        className="hidden"
      />

      {/* FULL-SCREEN AJUSTES & ALL SUB-SCREENS */}
      {showFullSettingsScreen && (
        <SettingsScreen
          onClose={() => {
            setShowFullSettingsScreen(false);
            setSettingsInitialSubPage('main');
          }}
          initialSubPage={settingsInitialSubPage}
          library={library}
          player={player}
          themeConfig={themeConfig}
          onUpdateThemeConfig={setThemeConfig}
          onOpenLockscreenPreview={() => setActiveModal('lock-screen')}
          onOpenEqualizerTab={() => setShowEqualizerModal(true)}
          showToast={showToast}
        />
      )}

      {/* TOP BAR CONTRACT: ☰ Mad Player | 🔍 ⋮ */}
      {!player.mobilePlayerExpanded && (
        <header
          className="sticky top-0 z-30 flex items-center justify-between gap-4 px-4 sm:px-6 py-3.5 backdrop-blur-md"
          style={{
            backgroundColor:
              themeConfig.appBgMode === 'image' || themeConfig.appBgMode === 'gradient'
                ? 'rgba(6, 25, 40, 0.78)'
                : 'var(--theme-bg)'
          }}
        >
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowFullSettingsScreen(true)}
              aria-label="Abrir menú lateral y ajustes"
              className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-white/10 cursor-pointer"
              style={{ color: 'var(--theme-text)' }}
            >
              <Menu className="w-6 h-6" />
            </button>

            <a
              href="#top"
              onClick={e => {
                e.preventDefault();
                setActiveTab('suggested');
              }}
              className="text-xl font-extrabold tracking-tight font-display whitespace-nowrap shrink-0"
              style={{ color: 'var(--theme-text)' }}
            >
              Mad Player
            </a>
          </div>

          <div className="flex items-center gap-2 relative">
            {(player.sleepSecondsRemaining !== null || player.sleepEndOfTrack) && (
              <div
                className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono-tabular font-extrabold border"
                style={{
                  backgroundColor: 'var(--theme-surface)',
                  borderColor: 'var(--theme-accent)',
                  color: 'var(--theme-accent)'
                }}
              >
                <button
                  type="button"
                  onClick={() => setActiveModal('sleep-timer')}
                  className="flex items-center gap-1 cursor-pointer"
                >
                  <Moon className="w-3.5 h-3.5" />
                  <span>
                    {player.sleepEndOfTrack
                      ? `Fin · ${formatDuration(player.sleepSecondsRemaining ?? 0)}`
                      : `${formatDuration(player.sleepSecondsRemaining ?? 0)}${
                          player.isSleepTimerFading ? ' (Fade)' : ''
                        }`}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => player.cancelSleepTimer()}
                  aria-label="Cancelar temporizador"
                  className="p-0.5 rounded-full hover:bg-rose-500/20 text-rose-400 cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}

            <button
              onClick={() => setShowMobileSearch(prev => !prev)}
              aria-label="Buscar canciones"
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors cursor-pointer"
              style={{ color: 'var(--theme-text)' }}
            >
              <Search className="w-5 h-5" />
            </button>

            <button
              onClick={() => setShowHeaderMenu(prev => !prev)}
              aria-label="Más opciones"
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors cursor-pointer"
              style={{ color: 'var(--theme-text)' }}
            >
              <MoreVertical className="w-5 h-5" />
            </button>

            {showHeaderMenu && (
              <>
                <div
                  onClick={() => setShowHeaderMenu(false)}
                  className="fixed inset-0 z-40"
                />
                <div
                  className="absolute right-0 top-11 z-50 w-56 rounded-xl py-2 shadow-2xl flex flex-col select-none"
                  style={{
                    backgroundColor: '#222629',
                    color: '#ffffff',
                    border: '1px solid rgba(255,255,255,0.08)'
                  }}
                >
                  <button
                    onClick={() => {
                      setShowHeaderMenu(false);
                      const allIds = library.visibleTracks.map(t => t.id);
                      if (allIds.length > 0) {
                        player.setIsShuffle(true);
                        const rand =
                          library.visibleTracks[
                            Math.floor(Math.random() * library.visibleTracks.length)
                          ];
                        player.playTrack(rand, allIds, true);
                        showToast('Mezclando todas las canciones');
                      }
                    }}
                    className="px-5 py-3.5 text-left text-base font-extrabold hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    Mezclar todo
                  </button>

                  <button
                    onClick={() => {
                      setShowHeaderMenu(false);
                      library.handleScanFolderOrLibrary();
                    }}
                    className="px-5 py-3.5 text-left text-base font-extrabold hover:bg-white/10 transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <FolderSearch className="w-4 h-4 text-[#1cc8ee]" />
                    Importar carpeta
                  </button>

                  <button
                    onClick={() => {
                      setShowHeaderMenu(false);
                      setActiveModal('sleep-timer');
                    }}
                    className="px-5 py-3.5 text-left text-base font-extrabold hover:bg-white/10 transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Moon className="w-4 h-4 text-[#1cc8ee]" />
                    Temporizador de apagado
                  </button>

                  <button
                    onClick={() => {
                      setShowHeaderMenu(false);
                      setShowFullSettingsScreen(true);
                    }}
                    className="px-5 py-3.5 text-left text-base font-extrabold hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    Ajustes
                  </button>
                </div>
              </>
            )}
          </div>
        </header>
      )}

      {/* MUZIO HORIZONTAL TABS */}
      {!player.mobilePlayerExpanded && (
        <div
          className="relative z-20 flex items-center gap-2 border-b px-3 overflow-x-auto no-scrollbar select-none backdrop-blur-md"
          style={{
            backgroundColor:
              themeConfig.appBgMode === 'image' || themeConfig.appBgMode === 'gradient'
                ? 'rgba(6, 25, 40, 0.72)'
                : 'var(--theme-bg)',
            borderColor: 'var(--theme-border)'
          }}
        >
          {settings.navTabsConfig
            .filter(t => t.enabled)
            .map(tab => {
              const active = activeTab === (tab.id as NavTab);
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as NavTab)}
                  className="min-h-[44px] px-3 flex items-center justify-center text-sm font-extrabold tracking-tight whitespace-nowrap shrink-0 border-b-[3px] transition-colors cursor-pointer"
                  style={{
                    color: active ? 'var(--theme-text)' : 'var(--theme-muted)',
                    borderColor: active ? 'var(--theme-accent)' : 'transparent'
                  }}
                >
                  {tab.label}
                </button>
              );
            })}
        </div>
      )}

      {/* Collapsible Search Bar */}
      {showMobileSearch && !player.mobilePlayerExpanded && (
        <div className="relative z-20 max-w-[1440px] w-full mx-auto px-4 pt-3">
          <div className="relative">
            <Search
              className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              style={{ color: 'var(--theme-muted)' }}
            />
            <input
              type="text"
              autoFocus
              value={library.searchQuery}
              onChange={e => {
                library.setSearchQuery(e.target.value);
                if (activeTab !== 'library') setActiveTab('library');
              }}
              placeholder="Buscar canción, artista o álbum..."
              className="w-full min-h-[42px] pl-10 pr-9 py-2 text-sm rounded-xl border outline-none"
              style={{
                backgroundColor: 'var(--theme-surface)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-text)'
              }}
            />
            {library.searchQuery && (
              <button
                onClick={() => library.setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 cursor-pointer"
                style={{ color: 'var(--theme-muted)' }}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Status Toast Banner */}
      {statusMessage && (
        <div
          className="fixed bottom-24 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl text-xs font-medium shadow-lg flex items-center gap-2 border max-w-[92vw]"
          style={{
            backgroundColor: 'var(--theme-surface)',
            borderColor: 'var(--theme-accent)',
            color: 'var(--theme-text)'
          }}
        >
          <Check className="w-4 h-4 shrink-0" style={{ color: 'var(--theme-accent)' }} />
          <span className="truncate">{statusMessage}</span>
        </div>
      )}

      {/* Folder Import Progress Bar with Cancel */}
      {library.importProgress.active && (
        <div className="relative z-30 max-w-[1440px] w-full mx-auto px-4 sm:px-6 pt-3">
          <div
            className="p-3.5 rounded-2xl border shadow-lg flex flex-col gap-2.5"
            style={{
              backgroundColor: 'var(--theme-surface)',
              borderColor: 'var(--theme-accent)',
              color: 'var(--theme-text)'
            }}
          >
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <FolderSearch
                    className="w-4 h-4 shrink-0 animate-pulse"
                    style={{ color: 'var(--theme-accent)' }}
                  />
                  <span className="text-xs font-extrabold truncate">
                    Importando carpeta ({library.importProgress.processed} /{' '}
                    {Math.max(1, library.importProgress.total)})
                  </span>
                </div>
                <p
                  className="text-[11px] font-mono-tabular truncate mt-0.5"
                  style={{ color: 'var(--theme-muted)' }}
                >
                  {library.importProgress.currentFileName || 'Leyendo etiquetas...'}
                  {library.importProgress.importedCount > 0 &&
                    ` · ${library.importProgress.importedCount} agregada(s)`}
                  {library.importProgress.duplicatesSkipped > 0 &&
                    ` · ${library.importProgress.duplicatesSkipped} duplicada(s)`}
                </p>
              </div>

              <button
                type="button"
                onClick={library.handleCancelImport}
                className="px-3 py-1.5 rounded-xl text-xs font-extrabold border flex items-center gap-1 shrink-0 hover:bg-rose-500/20 cursor-pointer"
                style={{
                  borderColor: 'var(--theme-border)',
                  color: '#fb7185'
                }}
              >
                <X className="w-3.5 h-3.5" />
                Cancelar
              </button>
            </div>

            <div className="w-full h-2 rounded-full overflow-hidden bg-black/30">
              <div
                className="h-full transition-all duration-150 rounded-full"
                style={{
                  width: `${
                    library.importProgress.total > 0
                      ? Math.min(
                          100,
                          Math.round(
                            (library.importProgress.processed / library.importProgress.total) * 100
                          )
                        )
                      : 0
                  }%`,
                  backgroundColor: 'var(--theme-accent)'
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* MAIN RESPONSIVE MOBILE-FIRST WORKSPACE */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-4 grid grid-cols-1 lg:grid-cols-12 gap-6 pb-28 lg:pb-8">
        <section className="relative z-10 lg:col-span-8 flex flex-col gap-6 min-w-0">
          {activeTab === 'suggested' && (
            <SuggestedScreen
              recentlyPlayedTracks={library.recentlyPlayedTracks}
              mostPlayedTracks={library.mostPlayedTracks}
              favoriteTracks={library.favoriteTracks}
              recentlyAddedTracks={library.recentlyAddedTracks}
              isScanningFolder={library.isScanningFolder}
              onTriggerImportFiles={() => library.fileInputRef.current?.click()}
              onTriggerScanFolder={library.handleScanFolderOrLibrary}
              onPlayTrack={player.playTrack}
              onNavigateToLibrary={opts => {
                if (opts?.sortBy) library.setSortBy(opts.sortBy);
                if (opts?.onlyFavorites) library.setOnlyFavorites(true);
                setActiveTab('library');
              }}
              onOpenTrackMenu={trackId => {
                player.setCurrentTrackId(trackId);
                setActiveModal('action-sheet');
              }}
            />
          )}

          {activeTab === 'library' && (
            <SongsScreen
              filteredTracks={library.filteredTracks}
              currentTrack={player.currentTrack}
              onlyFavorites={library.onlyFavorites}
              onClearOnlyFavorites={() => library.setOnlyFavorites(false)}
              onResetAllFilters={() => {
                library.setSearchQuery('');
                library.setSelectedGenre('all');
                library.setOnlyFavorites(false);
              }}
              sortBy={library.sortBy}
              onChangeSortBy={library.setSortBy}
              eqState={player.eqState}
              onOpenSpeedPicker={() => setActiveModal('speed-picker')}
              onTriggerImportFiles={() => library.fileInputRef.current?.click()}
              onTriggerScanFolder={library.handleScanFolderOrLibrary}
              selectedTrackIds={library.selectedTrackIds}
              onClearSelectedTracks={() => library.setSelectedTrackIds([])}
              playlists={library.playlists}
              onBatchAddToPlaylist={library.handleBatchAddToPlaylist}
              onBatchAddToQueue={handleBatchAddToQueue}
              onShufflePlayAll={() => {
                const allIds = library.filteredTracks.map(t => t.id);
                if (allIds.length > 0) {
                  player.setIsShuffle(true);
                  const randIdx = Math.floor(Math.random() * library.filteredTracks.length);
                  player.playTrack(library.filteredTracks[randIdx], allIds, true);
                }
              }}
              onPlayTrack={player.playTrack}
              onToggleFavorite={library.toggleFavorite}
              onOpenTrackMenu={trackId => {
                player.setCurrentTrackId(trackId);
                setActiveModal('action-sheet');
              }}
            />
          )}

          {activeTab === 'folders' && (
            <FoldersScreen
              groupedFolders={library.groupedFolders}
              isScanningFolder={library.isScanningFolder}
              onTriggerScanFolder={library.handleScanFolderOrLibrary}
              onTriggerImportFiles={() => library.fileInputRef.current?.click()}
              onPlayTrack={player.playTrack}
            />
          )}

          {activeTab === 'albums' && (
            <AlbumsScreen
              groupedAlbums={library.groupedAlbums}
              onPlayTrack={player.playTrack}
            />
          )}

          {activeTab === 'artists' && (
            <ArtistsScreen
              groupedArtists={library.groupedArtists}
              onPlayTrack={player.playTrack}
            />
          )}

          {activeTab === 'genres' && (
            <GenresScreen
              groupedGenres={library.groupedGenres}
              onSelectGenre={genreName => {
                library.setSelectedGenre(genreName);
                setActiveTab('library');
              }}
            />
          )}

          {(activeTab === 'playlists' || activeTab === 'smart-lists') && (
            <PlaylistsScreen
              mode={activeTab}
              tracks={library.tracks}
              visibleTracks={library.visibleTracks}
              playlists={library.playlists}
              setPlaylists={library.setPlaylists}
              activePlaylist={library.activePlaylist}
              activePlaylistTracks={library.activePlaylistTracks}
              onSelectPlaylist={library.setActivePlaylistId}
              showCreatePlaylistForm={library.showCreatePlaylistForm}
              setShowCreatePlaylistForm={library.setShowCreatePlaylistForm}
              newPlaylistName={library.newPlaylistName}
              setNewPlaylistName={library.setNewPlaylistName}
              newPlaylistDesc={library.newPlaylistDesc}
              setNewPlaylistDesc={library.setNewPlaylistDesc}
              onCreatePlaylist={library.handleCreatePlaylist}
              onDuplicatePlaylist={library.handleDuplicatePlaylist}
              onExportPlaylistJson={library.handleExportPlaylistJson}
              mergeTargetId={library.mergeTargetId}
              setMergeTargetId={library.setMergeTargetId}
              onMergePlaylists={library.handleMergePlaylists}
              onMovePlaylistTrack={library.handleMovePlaylistTrack}
              onRemoveFromPlaylist={library.handleRemoveFromPlaylist}
              smartPlaylists={library.smartPlaylists}
              activeSmartPlaylist={library.activeSmartPlaylist}
              onSelectSmartPlaylist={library.setActiveSmartId}
              showSmartBuilder={library.showSmartBuilder}
              setShowSmartBuilder={library.setShowSmartBuilder}
              smartName={library.smartName}
              setSmartName={library.setSmartName}
              smartDesc={library.smartDesc}
              setSmartDesc={library.setSmartDesc}
              smartMatchMode={library.smartMatchMode}
              setSmartMatchMode={library.setSmartMatchMode}
              smartRules={library.smartRules}
              setSmartRules={library.setSmartRules}
              onCreateSmartPlaylist={library.handleCreateSmartPlaylist}
              coverShape={themeConfig.coverShape}
              onPlayTrack={player.playTrack}
              showToast={showToast}
            />
          )}

          {(activeTab === 'themes' || activeTab === 'equalizer') && (
            <ThemesAndEqualizerScreen
              mode={activeTab}
              themeConfig={themeConfig}
              setThemeConfig={setThemeConfig}
              extractedTrackColor={extractedTrackColor}
              onOpenSettingsSubPage={subPage => {
                setSettingsInitialSubPage(subPage);
                setShowFullSettingsScreen(true);
              }}
              eqState={player.eqState}
              setEqState={player.setEqState}
              onInstantSpeedAndPitchChange={player.handleInstantSpeedAndPitchChange}
            />
          )}
        </section>

        {/* FULL PLAYER CONSOLE, QUICK EQUALIZER & TAG EDITOR */}
        <FullPlayer
          library={library}
          player={player}
          themeConfig={themeConfig}
          setThemeConfig={setThemeConfig}
          extractedTrackColor={extractedTrackColor}
          activeAccentColor={activePalette.accent}
          setActiveModal={setActiveModal}
          showEqualizerModal={showEqualizerModal}
          setShowEqualizerModal={setShowEqualizerModal}
          showToast={showToast}
        />

        {/* MOBILE MINI-PLAYER BAR */}
        <MiniPlayer
          currentTrack={player.currentTrack}
          mobilePlayerExpanded={player.mobilePlayerExpanded}
          isPlaying={player.isPlaying}
          currentTime={player.currentTime}
          duration={player.duration}
          onExpandPlayer={() => player.setMobilePlayerExpanded(true)}
          onOpenQueue={() => {
            player.setMobilePlayerExpanded(true);
            player.setPlayerPanelView('queue');
          }}
          onTogglePlayPause={player.togglePlayPause}
          onNextTrack={player.handleNextTrack}
          onPrevTrack={player.handlePrevTrack}
          showToast={showToast}
        />
      </main>

      {/* 3-DOTS ACTION SHEET & SPECIALIZED MODALS */}
      {player.currentTrack && (
        <PlayerModals
          activeModal={activeModal}
          onClose={() => setActiveModal(null)}
          onOpenModal={modal => setActiveModal(modal)}
          currentTrack={player.currentTrack}
          isPlaying={player.isPlaying}
          onTogglePlay={player.togglePlayPause}
          onPrev={player.handlePrevTrack}
          onNext={() => player.handleNextTrack(false)}
          onToggleFavorite={id => library.toggleFavorite(id)}
          currentTime={player.currentTime}
          duration={player.duration}
          onSeek={player.handleDirectSeek}
          volume={player.volume}
          isMuted={player.isMuted}
          onVolumeChange={player.handleDirectVolumeChange}
          onToggleMute={player.toggleMute}
          playbackRate={player.eqState.playbackRate}
          pitchRate={player.eqState.pitchRate}
          onSpeedAndPitchChange={player.handleInstantSpeedAndPitchChange}
          sleepTimerActive={player.sleepSecondsRemaining !== null || player.sleepEndOfTrack}
          sleepTimerMinutes={player.sleepTimerMinutes}
          sleepSecondsRemaining={player.sleepSecondsRemaining}
          sleepEndOfTrack={player.sleepEndOfTrack}
          isSleepTimerFading={player.isSleepTimerFading}
          onStartSleepTimer={mins => {
            player.startSleepTimer(mins);
            showToast(`Temporizador de apagado activado (${mins} min)`);
          }}
          onStartSleepEndOfTrack={() => {
            player.startSleepEndOfTrack();
            showToast('Temporizador: se pausará al acabar la canción actual');
          }}
          onCancelSleepTimer={() => {
            player.cancelSleepTimer();
          }}
          onToggleSleepTimer={() => {
            if (player.sleepSecondsRemaining !== null || player.sleepEndOfTrack) {
              player.cancelSleepTimer();
            } else {
              player.startSleepTimer(30);
              showToast('Temporizador de apagado activado (30 min)');
            }
          }}
          playPauseFadeEnabled={settings.playPauseFadeEnabled}
          playPauseFadeMs={settings.playPauseFadeMs}
          onTogglePlayPauseFade={settings.togglePlayPauseFade}
          onChangePlayPauseFadeMs={ms => settings.setPlayPauseFadeMs(ms)}
          crossfadeEnabled={settings.crossfadeEnabled}
          onToggleCrossfade={settings.toggleCrossfade}
          gaplessEnabled={settings.gaplessEnabled}
          onToggleGapless={settings.toggleGapless}
          playlists={library.playlists}
          onAddTrackToPlaylist={library.handleAddSingleTrackToPlaylist}
          onOpenTagEditor={() =>
            player.currentTrack && library.setEditingTrack({ ...player.currentTrack })
          }
          onOpenLyrics={() => player.setPlayerPanelView('lyrics')}
          onOpenEqualizer={() => setShowEqualizerModal(true)}
          onOpenThemes={() => setShowQuickPlayerSkinsModal(true)}
          onOpenFullSettings={() => {
            player.setMobilePlayerExpanded(false);
            setShowFullSettingsScreen(true);
          }}
          onHideTrack={library.handleHideTrack}
          onDeleteTrack={library.handleDeleteTrack}
          onShareTrack={player.handleShareTrack}
          onCreateTrimmedTrack={player.handleCreateTrimmedTrack}
          hiddenTracks={library.hiddenTracks}
          onRestoreHiddenTrack={library.handleRestoreHiddenTrack}
          onTriggerCoverUpload={() => library.coverInputRef.current?.click()}
          use24HourFormat={settings.use24HourFormat}
          muzioLockscreenBg={settings.muzioLockscreenBg}
        />
      )}

      {/* QUICK ACCESS "TEMA DEL REPRODUCTOR" 6-SKIN CAROUSEL MODAL */}
      {showQuickPlayerSkinsModal && (
        <PlayerSkinCarouselModal
          onClose={() => setShowQuickPlayerSkinsModal(false)}
          currentSkin={themeConfig.playerSkin}
          currentTrack={player.currentTrack}
          onApplySkin={(skin: PlayerSkin) => {
            setThemeConfig(prev => ({ ...prev, playerSkin: skin }));
          }}
          onSelectSkin={(skin: PlayerSkin) => {
            setThemeConfig(prev => ({ ...prev, playerSkin: skin }));
          }}
          onAfterApply={() => {
            setShowQuickPlayerSkinsModal(false);
            player.setPlayerPanelView('now-playing');
          }}
          showToast={showToast}
        />
      )}
      </div>
    </SettingsProvider>
  );
}
