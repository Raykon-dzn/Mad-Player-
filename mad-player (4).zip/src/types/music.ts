export interface WebSystemFileHandle {
  kind: 'file';
  name: string;
  getFile: () => Promise<File>;
  queryPermission?: (descriptor?: { mode?: 'read' | 'readwrite' }) => Promise<PermissionState>;
  requestPermission?: (descriptor?: { mode?: 'read' | 'readwrite' }) => Promise<PermissionState>;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  genre: string;
  year: number;
  duration: number; // in seconds
  bpm: number;
  coverUrl: string;
  dominantColor: string; // Hex fallback / seed for dynamic theme
  secondaryColor: string;
  isFavorite: boolean;
  playCount: number;
  addedAt: string; // ISO date
  lastPlayedAt?: number;
  lyrics?: string[];
  audioUrl?: string; // Present when user imports local audio file
  folderPath?: string; // Directory path from folder scan or device storage
  fileName?: string; // Original file name for duplicate detection
  fileSizeBytes?: number; // Exact file size in bytes for duplicate detection
  fileSizeKB?: number; // File size in KB for minimum size filtering
  importedFromFolder?: boolean; // True when imported from folder scan
  fileHandle?: WebSystemFileHandle; // Web File System Access API handle to reopen file after reload
  audioUnavailable?: boolean; // True when track in IndexedDB has neither audioBlob nor fileHandle
  isHidden?: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  trackIds: string[];
  createdAt: string;
  updatedAt: string;
  customAccent?: string;
}

export type SmartRuleField = 'genre' | 'bpm' | 'playCount' | 'isFavorite' | 'duration' | 'year';
export type SmartRuleOperator = 'equals' | 'gte' | 'lte' | 'contains';

export interface SmartRule {
  id: string;
  field: SmartRuleField;
  operator: SmartRuleOperator;
  value: string | number | boolean;
}

export interface SmartPlaylist {
  id: string;
  name: string;
  description: string;
  matchMode: 'all' | 'any';
  rules: SmartRule[];
  sortBy: 'playCount' | 'bpm' | 'title' | 'addedAt' | 'duration';
  sortOrder: 'asc' | 'desc';
  limit?: number;
}

export type ThemeBaseId =
  | 'dynamic-cover'
  | 'obsidian-studio'
  | 'nordic-slate'
  | 'velvet-crimson'
  | 'solar-concrete'
  | 'editorial-paper';

export type CoverShape = 'square' | 'rounded' | 'vinyl';
export type PlayerSkin =
  | 'muzio-classic'
  | 'stacked-cards'
  | 'vinyl-circle'
  | 'full-bleed-dark'
  | 'framed-card'
  | 'circle-cobalt'
  | 'studio-console'
  | 'minimal-wave';
export type VisualizerStyle = 'spectrum-bars' | 'oscilloscope-wave' | 'harmonic-pulse';

export interface ThemeConfig {
  baseId: ThemeBaseId;
  adaptToCoverArt: boolean;
  customAccentHex: string;
  useCustomAccent: boolean;
  coverShape: CoverShape;
  playerSkin: PlayerSkin;
  visualizerStyle: VisualizerStyle;
  compactDensity: boolean;
  // App-wide background customization ("Elegir Tema" — Screenshot 7)
  appBgMode?: 'image' | 'color' | 'gradient';
  bgImageId?: string;
  bgImageUrl?: string;
  bgImageAlpha?: number; // 0.1 to 1.0 (opacity of background image / overlay control)
  bgImageBlur?: number; // 0 to 30 px
  bgColorHex?: string;
  bgGradientCss?: string;
  customUserImages?: { id: string; url: string; alpha: number; blur: number }[];
  customUserAccents?: string[];
}

export interface EqualizerBand {
  frequency: number;
  label: string;
  gain: number; // -12 to +12 dB
}

export interface EqualizerState {
  enabled: boolean;
  presetName: string;
  bands: EqualizerBand[];
  bassBoost: number; // 0 to 12 dB
  stereoWidth: number; // -1 (left) to +1 (right) or 0 center
  playbackRate: number; // 0.5 to 2.0 (default 1.0)
  pitchRate: number; // 0.5 to 2.0 (default 1.0)
}
